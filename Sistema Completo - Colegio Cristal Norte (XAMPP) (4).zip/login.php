<?php
/**
 * COLÉGIO CRISTAL NORTE - Autenticação de Usuários
 * Portal Acadêmico e de Matrículas Escolares — Ano Letivo 2026
 */
require_once __DIR__ . '/config.php';

// Se já estiver logado, redireciona para o dashboard
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $perfil = trim($_POST['perfil'] ?? '');

    if (empty($email) || empty($senha) || empty($perfil)) {
        $erro = 'Por favor, preencha todos os campos para entrar.';
    } else {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND perfil = ? AND ativo = 1 LIMIT 1");
        $stmt->execute([$email, $perfil]);
        $usuario = $stmt->fetch();

        if ($usuario) {
            // Verificação segura com password_verify
            $senhaValida = password_verify($senha, $usuario['senha']);
            
            // Suporte de compatibilidade para senhas temporárias em texto plano
            if (!$senhaValida && strlen($usuario['senha']) < 60 && $senha === $usuario['senha']) {
                $senhaValida = true;
                // Atualiza automaticamente para hash seguro BCRYPT
                $novoHash = password_hash($senha, PASSWORD_DEFAULT);
                $updateStmt = $pdo->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
                $updateStmt->execute([$novoHash, $usuario['id']]);
            }

            if ($senhaValida) {
                // Registrar sessão
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_perfil'] = $usuario['perfil'];

                // Buscar ID específico do perfil para consultas rápidas
                $_SESSION['usuario_detalhe_id'] = null;
                if ($usuario['perfil'] === 'professor') {
                    $pStmt = $pdo->prepare("SELECT id FROM professores WHERE usuario_id = ?");
                    $pStmt->execute([$usuario['id']]);
                    $_SESSION['usuario_detalhe_id'] = $pStmt->fetchColumn();
                } elseif ($usuario['perfil'] === 'aluno') {
                    $aStmt = $pdo->prepare("SELECT id, turma_id FROM alunos WHERE usuario_id = ?");
                    $aStmt->execute([$usuario['id']]);
                    $alunoData = $aStmt->fetch();
                    if ($alunoData) {
                        $_SESSION['usuario_detalhe_id'] = $alunoData['id'];
                        $_SESSION['aluno_turma_id'] = $alunoData['turma_id'];
                    }
                } elseif ($usuario['perfil'] === 'responsavel') {
                    $rStmt = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
                    $rStmt->execute([$usuario['id']]);
                    $_SESSION['usuario_detalhe_id'] = $rStmt->fetchColumn();
                } elseif ($usuario['perfil'] === 'coordenador') {
                    $cStmt = $pdo->prepare("SELECT id FROM coordenadores WHERE usuario_id = ?");
                    $cStmt->execute([$usuario['id']]);
                    $_SESSION['usuario_detalhe_id'] = $cStmt->fetchColumn();
                }

                flash('success', 'Bem-vindo(a) de volta, ' . htmlspecialchars($usuario['nome']) . '!');
                header('Location: dashboard.php');
                exit;
            } else {
                $erro = 'Senha incorreta. Verifique os dados digitados.';
            }
        } else {
            $erro = 'Usuário não encontrado com o perfil selecionado ou conta inativa.';
        }
    }
}

$pageTitle = 'Acesso ao Portal - Login';
require_once __DIR__ . '/header.php';
?>

<div class="login-split-wrapper">
  <!-- Coluna Esquerda: 32% Card Bege (#FDF8EE) -->
  <div class="login-split-left">
    <div class="login-card-bege">
      <div style="text-align: center; margin-bottom: 18px;">
        <img src="<?= LOGO_URL ?>" alt="Colégio Cristal Norte" class="login-logo-img">
        <h2 style="color: #A81C1D; font-size: 1.35rem; font-weight: 800; margin: 10px 0 2px; letter-spacing: 0.5px;">COLÉGIO CRISTAL NORTE</h2>
        <p style="color: #64748B; font-size: 0.82rem; font-weight: 600; margin: 0 0 8px;">Educação & Inovação — Portal Cristal Connect</p>
        <span style="display: inline-block; background: rgba(168,28,29,0.08); color: #A81C1D; font-size: 0.72rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; border: 1px solid rgba(168,28,29,0.2);">ACESSO AO SISTEMA</span>
      </div>

      <?php if (!empty()): ?>
        <div class="alert alert-error" style="margin-bottom: 16px; font-size: 0.85rem; padding: 10px 12px;">
          <?= htmlspecialchars() ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="login.php">
        <div class="form-group" style="margin-bottom: 12px;">
          <label for="perfil" style="color: #334155; font-size: 0.78rem; font-weight: 700; text-transform: uppercase;">Tipo de Usuário *</label>
          <select name="perfil" id="perfil" class="form-control" required style="background: #FFFFFF; color: #1E293B; border: 1.5px solid #CBD5E1; font-size: 0.88rem; padding: 9px 12px;">
            <option value="">Selecione seu perfil...</option>
            <option value="diretor" <?= (isset(['perfil']) && ['perfil'] === 'diretor') ? 'selected' : '' ?>>Diretor Geral (Direção)</option>
            <option value="coordenador" <?= (isset(['perfil']) && ['perfil'] === 'coordenador') ? 'selected' : '' ?>>Coordenador Pedagógico</option>
            <option value="professor" <?= (isset(['perfil']) && ['perfil'] === 'professor') ? 'selected' : '' ?>>Professor</option>
            <option value="aluno" <?= (isset(['perfil']) && ['perfil'] === 'aluno') ? 'selected' : '' ?>>Aluno (Estudante)</option>
            <option value="responsavel" <?= (isset(['perfil']) && ['perfil'] === 'responsavel') ? 'selected' : '' ?>>Responsável Legal</option>
          </select>
        </div>

        <div class="form-group" style="margin-bottom: 12px;">
          <label for="email" style="color: #334155; font-size: 0.78rem; font-weight: 700; text-transform: uppercase;">E-mail de Acesso *</label>
          <input type="email" name="email" id="email" class="form-control" placeholder="seu.email@cristalnorte.com.br" value="<?= htmlspecialchars(['email'] ?? '') ?>" required style="background: #FFFFFF; color: #1E293B; border: 1.5px solid #CBD5E1; font-size: 0.88rem; padding: 9px 12px;">
        </div>

        <div class="form-group" style="margin-bottom: 12px;">
          <label for="senha" style="color: #334155; font-size: 0.78rem; font-weight: 700; text-transform: uppercase;">Senha de Acesso *</label>
          <input type="password" name="senha" id="senha" class="form-control" placeholder="Digite sua senha" required style="background: #FFFFFF; color: #1E293B; border: 1.5px solid #CBD5E1; font-size: 0.88rem; padding: 9px 12px;">
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <label style="font-size: 0.8rem; color: #64748B; display: flex; align-items: center; gap: 6px; cursor: pointer;">
            <input type="checkbox" id="lembrar" style="accent-color: #E65100;"> Lembrar-me
          </label>
          <a href="javascript:void(0)" onclick="abrirModal('modalEsqueciSenha')" style="font-size: 0.8rem; color: #E65100; font-weight: 600;">Esqueci minha senha</a>
        </div>

        <button type="submit" class="btn btn-primary btn-block" style="background: linear-gradient(135deg, #FF6F00 0%, #E65100 100%); border: none; padding: 11px 16px; font-weight: 700; font-size: 0.92rem; border-radius: 6px; box-shadow: 0 4px 12px rgba(230,81,0,0.25); cursor: pointer;">
          ENTRAR NO SISTEMA
        </button>
      </form>

      <!-- Guia Rápido com Contas de Demonstração -->
      <div style="margin-top: 16px; background: #F1ECE1; border: 1px solid #E2D9CC; padding: 10px 12px; border-radius: 8px; font-size: 0.75rem; color: #475569; line-height: 1.45;">
        <strong style="color: #1E293B; display:block; margin-bottom:4px;">🔑 Acesso Rápido de Teste (XAMPP):</strong>
        <div>• <strong>Diretor:</strong> diretor@cristalnorte.com.br (<code>admin123</code>)</div>
        <div>• <strong>Coordenador:</strong> coordenador@cristalnorte.com.br (<code>coord123</code>)</div>
        <div>• <strong>Professores:</strong> prof123 | <strong>Alunos:</strong> aluno123 | <strong>Responsáveis:</strong> resp123</div>
      </div>
    </div>
  </div>

  <!-- Coluna Direita: 68% Fundo Bordô Gradiente com Matrícula 2026 -->
  <div class="login-split-right">
    <div class="login-right-content">
      <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(30,165,83,0.2); border: 1px solid #1EA553; color: #4ADE80; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; margin-bottom: 16px;">
        <span style="width: 8px; height: 8px; border-radius: 50%; background: #4ADE80; box-shadow: 0 0 8px #4ADE80;"></span>
        MATRÍCULAS ABERTAS — ANO LETIVO 2026
      </div>

      <h1 style="color: #FFFFFF; font-size: 2rem; font-weight: 800; line-height: 1.25; margin: 0 0 12px;">
        Excelência em Educação do Ensino Fundamental ao Médio
      </h1>
      <p style="color: #F8FAFC; font-size: 0.95rem; opacity: 0.92; line-height: 1.6; margin: 0 0 24px;">
        Matricule seu filho no Colégio Cristal Norte com atendimento humanizado, controle acadêmico completo e infraestrutura de ponta.
      </p>

      <div style="background: rgba(255,255,255,0.08); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.18); border-radius: 14px; padding: 24px; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.12); padding-bottom: 10px;">
          <h3 style="color: #FFFFFF; font-size: 1.15rem; margin: 0; font-weight: 700;">Área de Matrícula e Novos Alunos</h3>
          <span style="background: #E65100; color: #fff; font-size: 0.72rem; font-weight: 700; padding: 3px 8px; border-radius: 12px;">2026</span>
        </div>
        <p style="color: #CBD5E1; font-size: 0.88rem; margin: 0 0 16px;">
          O processo de matrícula para novos alunos é 100% integrado. O sistema valida rigorosamente a faixa etária de 6 a 17 anos e gera o código oficial de registro <code>MAT-2026-XXXXX</code>.
        </p>
        <a href="matricula.php" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #FF6F00 0%, #E65100 100%); padding: 12px 24px; font-weight: 700; font-size: 0.95rem; border-radius: 8px; text-decoration: none; color: #fff; border: none;">
          Ir para Ficha de Matrícula Online &rarr;
        </a>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px;">
        <div style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 8px; padding: 12px; color: #fff;">
          <strong style="display: block; font-size: 0.88rem; margin-bottom: 2px;">🎓 17 Turmas</strong>
          <span style="font-size: 0.75rem; color: #CBD5E1;">Fundamental II e Ensino Médio</span>
        </div>
        <div style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 8px; padding: 12px; color: #fff;">
          <strong style="display: block; font-size: 0.88rem; margin-bottom: 2px;">📊 Cristal Connect</strong>
          <span style="font-size: 0.75rem; color: #CBD5E1;">Notas, diário e frequência real</span>
        </div>
        <div style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 8px; padding: 12px; color: #fff;">
          <strong style="display: block; font-size: 0.88rem; margin-bottom: 2px;">🛡️ Acesso Seguro</strong>
          <span style="font-size: 0.75rem; color: #CBD5E1;">Isolamento por perfil e salas</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Esqueci Minha Senha -->
<div class="modal-overlay" id="modalEsqueciSenha">
  <div class="modal-content" style="background: #FFFFFF; color: #1E293B;">
    <button class="modal-close" onclick="fecharModal('modalEsqueciSenha')">&times;</button>
    <h3 style="color: var(--primary-red); margin-bottom: 12px;">Recuperação de Acesso</h3>
    <p style="font-size: 0.95rem; color: #4B5563; margin-bottom: 16px;">
      Por questões de segurança da comunidade escolar, a redefinição de senhas de estudantes e responsáveis pode ser solicitada pelo formulário abaixo ou diretamente na secretaria acadêmica.
    </p>

    <form onsubmit="event.preventDefault(); alert('Instruções de redefinição foram enviadas para o e-mail cadastrado (em ambiente de teste, utilize as senhas padrões fornecidas).'); fecharModal('modalEsqueciSenha');">
      <div class="form-group">
        <label for="recupera_email">Informe seu e-mail cadastrado:</label>
        <input type="email" id="recupera_email" class="form-control" required placeholder="exemplo@cristalnorte.com.br">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Enviar Link de Recuperação</button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
