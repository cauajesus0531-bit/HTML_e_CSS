<?php
/**
 * COLÉGIO CRISTAL NORTE - Dashboard do Coordenador Pedagógico
 * Monitoramento de alunos com muitas faltas, baixo rendimento e gestão acadêmica
 */
require_once __DIR__ . '/config.php';
requireRole(['coordenador', 'diretor']);

$user = currentUser();
$pdo = getDB();

// 1. Contadores Gerais (KPIs)
$totalAlunos = (int)$pdo->query("SELECT COUNT(*) FROM alunos WHERE status = 'ativo'")->fetchColumn();
$totalTurmas = (int)$pdo->query("SELECT COUNT(*) FROM turmas WHERE ano_letivo = 2026")->fetchColumn();
$totalProfessores = (int)$pdo->query("SELECT COUNT(*) FROM professores")->fetchColumn();
$totalOcorrencias = (int)$pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE situacao != 'resolvida'")->fetchColumn();

// 2. Alunos com Muitas Faltas (Faltas acumuladas > 2 ou mais de 25% das aulas)
$stmtFaltas = $pdo->query("
    SELECT 
        a.id, 
        a.nome as aluno_nome, 
        a.matricula,
        t.nome as turma_nome,
        t.serie as turma_serie,
        COUNT(f.id) as total_aulas,
        SUM(CASE WHEN f.presente = 0 THEN 1 ELSE 0 END) as total_faltas
    FROM alunos a
    JOIN turmas t ON t.id = a.turma_id
    JOIN frequencias f ON f.aluno_id = a.id
    GROUP BY a.id, a.nome, a.matricula, t.nome, t.serie
    HAVING total_faltas >= 1
    ORDER BY total_faltas DESC
    LIMIT 6
");
$alunosMuitasFaltas = $stmtFaltas->fetchAll();

// 3. Alunos com Baixo Rendimento (Médias < 6.0)
$stmtBaixoRend = $pdo->query("
    SELECT 
        n.id,
        a.nome as aluno_nome,
        a.matricula,
        d.nome as disciplina_nome,
        t.nome as turma_nome,
        n.media_final,
        n.situacao
    FROM notas n
    JOIN alunos a ON a.id = n.aluno_id
    JOIN disciplinas d ON d.id = n.disciplina_id
    JOIN turmas t ON t.id = n.turma_id
    WHERE n.media_final IS NOT NULL AND n.media_final < 6.0
    ORDER BY n.media_final ASC
    LIMIT 6
");
$alunosBaixoRend = $stmtBaixoRend->fetchAll();

// 4. Ocorrências Recentes
$stmtOco = $pdo->query("
    SELECT o.*, a.nome as aluno_nome, u.nome as autor_nome, t.nome as turma_nome
    FROM ocorrencias o
    JOIN alunos a ON a.id = o.aluno_id
    JOIN turmas t ON t.id = a.turma_id
    JOIN usuarios u ON u.id = o.autor_id
    ORDER BY o.data_ocorrencia DESC
    LIMIT 5
");
$ocorrencias = $stmtOco->fetchAll();

// 5. Atividades recentes lançadas na escola
$stmtAtiv = $pdo->query("
    SELECT a.*, d.nome as disciplina_nome, p.nome as professor_nome, t.nome as turma_nome
    FROM atividades a
    JOIN disciplinas d ON d.id = a.disciplina_id
    JOIN professores p ON p.id = a.professor_id
    JOIN turmas t ON t.id = a.turma_id
    ORDER BY a.criada_em DESC
    LIMIT 5
");
$atividades = $stmtAtiv->fetchAll();

$pageTitle = 'Painel da Coordenação Pedagógica';
require_once __DIR__ . '/header.php';
?>

<!-- Boas-vindas da Coordenação -->
<div class="card" style="border-left: 6px solid var(--accent-yellow);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h2 style="margin:0; font-size:1.6rem; color:var(--text-dark);">
        Coordenação Pedagógica — Ano Letivo 2026
      </h2>
      <p style="color:var(--text-muted); margin:4px 0 0 0;">
        Monitoramento de rendimento escolar, assiduidade, ocorrências disciplinares e apoio pedagógico.
      </p>
    </div>
    <div style="display:flex; gap:10px;">
      <a href="comunicados.php?action=novo" class="btn btn-primary">📢 Novo Comunicado</a>
      <a href="ocorrencias.php?action=nova" class="btn btn-secondary">⚠️ Registrar Ocorrência</a>
    </div>
  </div>
</div>

<!-- KPIs da Coordenação -->
<div class="kpi-grid">
  <div class="kpi-card">
    <span class="kpi-title">Alunos Matriculados</span>
    <span class="kpi-value" style="color:var(--accent-blue);"><?= $totalAlunos ?></span>
    <span class="kpi-sub">Estudantes ativos</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Turmas em Andamento</span>
    <span class="kpi-value" style="color:var(--primary-orange);"><?= $totalTurmas ?></span>
    <span class="kpi-sub">Ano Letivo 2026</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Corpo Docente</span>
    <span class="kpi-value" style="color:var(--accent-green);"><?= $totalProfessores ?></span>
    <span class="kpi-sub">Professores especialistas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Ocorrências Pendentes</span>
    <span class="kpi-value" style="color:var(--primary-red);"><?= $totalOcorrencias ?></span>
    <span class="kpi-sub">Exigem acompanhamento</span>
  </div>
</div>

<!-- Alertas Pedagógicos: Alunos com Muitas Faltas e Baixo Rendimento -->
<div class="form-grid-2">
  <!-- Alunos com Muitas Faltas -->
  <div class="card" style="border-top: 4px solid var(--primary-red);">
    <div class="card-header">
      <h3 style="color:var(--primary-red);">⚠️ Alunos com Faltas Excessivas</h3>
      <span class="badge" style="background:#FEE2E2; color:#991B1B;">Atenção Imediata</span>
    </div>
    <?php if (empty($alunosMuitasFaltas)): ?>
      <p style="color:var(--accent-green);">✓ Nenhum aluno com número crítico de faltas registrado.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Estudante</th>
              <th>Turma</th>
              <th class="text-center">Faltas</th>
              <th class="text-center">Total Aulas</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($alunosMuitasFaltas as $af): ?>
              <tr>
                <td>
                  <strong><?= htmlspecialchars($af['aluno_nome']) ?></strong>
                  <br><small style="color:var(--text-muted);"><?= htmlspecialchars($af['matricula']) ?></small>
                </td>
                <td><?= htmlspecialchars($af['turma_serie']) ?> (<?= htmlspecialchars($af['turma_nome']) ?>)</td>
                <td class="text-center" style="font-weight:700; color:var(--primary-red); font-size:1.1rem;"><?= $af['total_faltas'] ?></td>
                <td class="text-center"><?= $af['total_aulas'] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <!-- Alunos com Baixo Rendimento (Média < 6.0) -->
  <div class="card" style="border-top: 4px solid var(--primary-orange);">
    <div class="card-header">
      <h3 style="color:var(--primary-orange);">📉 Alunos com Baixo Rendimento</h3>
      <span class="badge" style="background:#FEF3C7; color:#92400E;">Média &lt; 6.0</span>
    </div>
    <?php if (empty($alunosBaixoRend)): ?>
      <p style="color:var(--accent-green);">✓ Todos os alunos avaliados possuem média superior a 6.0.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Estudante</th>
              <th>Disciplina</th>
              <th class="text-center">Média</th>
              <th class="text-center">Situação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($alunosBaixoRend as $br): ?>
              <tr>
                <td>
                  <strong><?= htmlspecialchars($br['aluno_nome']) ?></strong>
                  <br><small style="color:var(--text-muted);"><?= htmlspecialchars($br['turma_nome']) ?></small>
                </td>
                <td><?= htmlspecialchars($br['disciplina_nome']) ?></td>
                <td class="text-center" style="font-weight:700; color:var(--primary-red);"><?= number_format($br['media_final'], 2, ',', '.') ?></td>
                <td class="text-center">
                  <span class="badge badge-recuperacao"><?= ucfirst($br['situacao']) ?></span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="form-grid-2">
  <!-- Ocorrências Disciplinares -->
  <div class="card">
    <div class="card-header">
      <h2>Ocorrências Disciplinares Recentes</h2>
      <a href="ocorrencias.php" class="btn btn-secondary btn-sm">Ver Todas</a>
    </div>
    <?php if (empty($ocorrencias)): ?>
      <p style="color:var(--text-muted);">Nenhuma ocorrência registrada no período.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($ocorrencias as $oco): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border-left:4px solid var(--primary-red);">
            <div style="display:flex; justify-content:space-between;">
              <strong><?= htmlspecialchars($oco['aluno_nome']) ?> (<?= htmlspecialchars($oco['turma_nome']) ?>)</strong>
              <span class="badge" style="background:#FEE2E2; color:#991B1B;"><?= ucfirst($oco['situacao']) ?></span>
            </div>
            <p style="font-size:0.85rem; color:#4B5563; margin:6px 0;"><?= htmlspecialchars($oco['descricao']) ?></p>
            <small style="color:#9CA3AF;">Registrado por <?= htmlspecialchars($oco['autor_nome']) ?> em <?= date('d/m/Y', strtotime($oco['data_ocorrencia'])) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Atividades Didáticas Recentes -->
  <div class="card">
    <div class="card-header">
      <h2>Atividades e Tarefas em Andamento</h2>
    </div>
    <?php if (empty($atividades)): ?>
      <p style="color:var(--text-muted);">Nenhuma atividade cadastrada recentemente.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($atividades as $a): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border:1px solid var(--border-color);">
            <div style="display:flex; justify-content:space-between;">
              <strong><?= htmlspecialchars($a['titulo']) ?></strong>
              <span class="badge" style="background:#E0F2FE; color:#0369A1;"><?= htmlspecialchars($a['disciplina_nome']) ?></span>
            </div>
            <p style="font-size:0.85rem; color:#4B5563; margin:4px 0;"><?= htmlspecialchars($a['descricao']) ?></p>
            <div style="font-size:0.8rem; color:#6B7280; display:flex; justify-content:space-between;">
              <span>Prof(a). <?= htmlspecialchars($a['professor_nome']) ?> • <?= htmlspecialchars($a['turma_nome']) ?></span>
              <span>Entrega: <?= date('d/m/Y', strtotime($a['data_entrega'])) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
