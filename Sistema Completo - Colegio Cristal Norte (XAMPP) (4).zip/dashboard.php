<?php
/**
 * COLÉGIO CRISTAL NORTE - Roteador Central de Dashboards
 * Redireciona ou carrega o painel de acordo com o perfil autenticado
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

switch ($user['perfil']) {
    case 'diretor':
        require_once __DIR__ . '/dashboard_diretor.php';
        break;
    case 'coordenador':
        require_once __DIR__ . '/dashboard_coordenador.php';
        break;
    case 'professor':
        require_once __DIR__ . '/dashboard_professor.php';
        break;
    case 'aluno':
        require_once __DIR__ . '/dashboard_aluno.php';
        break;
    case 'responsavel':
        require_once __DIR__ . '/dashboard_responsavel.php';
        break;
    default:
        flash('error', 'Perfil de usuário não reconhecido.');
        header('Location: login.php');
        exit;
}
