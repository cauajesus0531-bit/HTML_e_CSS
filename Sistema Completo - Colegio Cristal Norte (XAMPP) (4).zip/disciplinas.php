<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão de Disciplinas
 * Cadastro de matérias e atribuição docente rigorosa
 */
require_once __DIR__ . '/config.php';
requireRole('diretor');

$pdo = getDB();
$action = $_GET['action'] ?? 'listar';

// Cadastrar Nova Disciplina
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $codigo = trim($_POST['codigo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if (empty($nome) || empty($codigo)) {
        flash('error', 'Por favor, informe o nome e o código da disciplina.');
    } else {
        try {
            $stmtIns = $pdo->prepare("INSERT INTO disciplinas (nome, codigo, descricao) VALUES (?, ?, ?)");
            $stmtIns->execute([$nome, $codigo, $descricao]);
            flash('success', 'Disciplina curricular adicionada com sucesso!');
        } catch (Exception $e) {
            flash('error', 'Código de disciplina já existente ou erro ao salvar: ' . $e->getMessage());
        }
        header('Location: disciplinas.php');
        exit;
    }
}

// Listagem de Disciplinas com Professores e Turmas
$stmtDisc = $pdo->query("
    SELECT 
        d.*,
        GROUP_CONCAT(DISTINCT p.nome SEPARATOR ', ') as professores_nomes,
        COUNT(DISTINCT pt.turma_id) as total_turmas
    FROM disciplinas d
    LEFT JOIN professores p ON p.disciplina_id = d.id
    LEFT JOIN professor_turmas pt ON pt.disciplina_id = d.id
    GROUP BY d.id
    ORDER BY d.nome ASC
");
$disciplinas = $stmtDisc->fetchAll();

$pageTitle = 'Gestão da Matriz Curricular';
require_once __DIR__ . '/header.php';
?>

<div class="form-grid-2">
  <!-- Listagem de Disciplinas -->
  <div class="card">
    <div class="card-header">
      <h2>Disciplinas Cadastradas</h2>
      <span class="badge badge-aprovado"><?= count($disciplinas) ?> Matérias</span>
    </div>

    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Código</th>
            <th>Nome da Disciplina</th>
            <th>Professor(es) Responsável(eis)</th>
            <th class="text-center">Turmas</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($disciplinas as $d): ?>
            <tr>
              <td><strong style="color:var(--primary-orange);"><?= htmlspecialchars($d['codigo']) ?></strong></td>
              <td>
                <strong><?= htmlspecialchars($d['nome']) ?></strong>
                <?php if (!empty($d['descricao'])): ?>
                  <br><small style="color:var(--text-muted);"><?= htmlspecialchars($d['descricao']) ?></small>
                <?php endif; ?>
              </td>
              <td><?= !empty($d['professores_nomes']) ? htmlspecialchars($d['professores_nomes']) : '<span style="color:#9CA3AF;">Nenhum professor</span>' ?></td>
              <td class="text-center"><span class="badge" style="background:#E0F2FE; color:#0369A1;"><?= $d['total_turmas'] ?> turmas</span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Cadastro de Nova Disciplina -->
  <div class="card">
    <div class="card-header">
      <h2>Adicionar Nova Disciplina</h2>
    </div>

    <form method="POST" action="disciplinas.php?action=salvar">
      <div class="form-group">
        <label for="nome">Nome da Disciplina *</label>
        <input type="text" name="nome" id="nome" class="form-control" required placeholder="Ex: Física Quântica, Filosofia, Redação">
      </div>

      <div class="form-group">
        <label for="codigo">Código Curricular *</label>
        <input type="text" name="codigo" id="codigo" class="form-control" required placeholder="Ex: FIS-01, RED-02">
      </div>

      <div class="form-group">
        <label for="descricao">Ementa / Descrição</label>
        <textarea name="descricao" id="descricao" class="form-control" rows="4" placeholder="Breve descrição dos objetivos pedagógicos da disciplina..."></textarea>
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary btn-block">Salvar Disciplina</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
