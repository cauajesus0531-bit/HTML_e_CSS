<?php
/**
 * COLÉGIO CRISTAL NORTE - Mural de Comunicados Institucionais
 * Direção e Coordenação: publicam comunicados segmentados
 * Professores, Alunos e Responsáveis: visualizam notícias relevantes
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

$action = $_GET['action'] ?? 'listar';

// ==========================================
// AÇÃO: PUBLICAR COMUNICADO (Direção e Coordenação)
// ==========================================
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole(['diretor', 'coordenador']);

    $titulo = trim($_POST['titulo'] ?? '');
    $conteudo = trim($_POST['conteudo'] ?? '');
    $publicoAlvo = trim($_POST['publico_alvo'] ?? 'todos');
    $turmaId = ($publicoAlvo === 'turma') ? intval($_POST['turma_id'] ?? 0) : null;
    $dataPub = date('Y-m-d');

    if (empty($titulo) || empty($conteudo)) {
        flash('error', 'Por favor, informe o título e o conteúdo do comunicado.');
    } else {
        $stmtIns = $pdo->prepare("
            INSERT INTO comunicados (autor_id, titulo, conteudo, publico_alvo, turma_id, data_publicacao)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmtIns->execute([$user['id'], $titulo, $conteudo, $publicoAlvo, $turmaId, $dataPub]);
        flash('success', 'Comunicado institucional publicado com sucesso no mural!');
        header('Location: comunicados.php');
        exit;
    }
}

// Excluir Comunicado (Diretor)
if ($action === 'excluir') {
    requireRole('diretor');
    $id = intval($_GET['id'] ?? 0);
    $stmtDel = $pdo->prepare("DELETE FROM comunicados WHERE id = ?");
    $stmtDel->execute([$id]);
    flash('info', 'Comunicado removido do mural.');
    header('Location: comunicados.php');
    exit;
}

$pageTitle = 'Mural de Comunicados Oficiais';
require_once __DIR__ . '/header.php';
?>

<!-- FORMULÁRIO DE NOVO COMUNICADO -->
<?php if ($action === 'novo' && hasRole(['diretor', 'coordenador'])): ?>
  <?php
    $turmas = $pdo->query("SELECT id, nome, serie FROM turmas WHERE ano_letivo = 2026 ORDER BY serie, nome")->fetchAll();
  ?>
  <div class="card">
    <div class="card-header">
      <h2>Publicar Novo Comunicado Institucional</h2>
      <a href="comunicados.php" class="btn btn-secondary btn-sm">Voltar</a>
    </div>

    <form method="POST" action="comunicados.php?action=salvar">
      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="titulo">Título do Comunicado *</label>
          <input type="text" name="titulo" id="titulo" class="form-control" required placeholder="Ex: Cronograma de Provas Bimestrais e Reunião Geral">
        </div>

        <div class="form-group">
          <label for="publico_alvo">Público-Alvo *</label>
          <select name="publico_alvo" id="publico_alvo" class="form-control" required onchange="document.getElementById('boxTurma').style.display = this.value === 'turma' ? 'block' : 'none';">
            <option value="todos">Toda a Comunidade Escolar (Geral)</option>
            <option value="professores">Somente Professores</option>
            <option value="alunos">Somente Estudantes</option>
            <option value="responsaveis">Somente Pais e Responsáveis</option>
            <option value="turma">Turma Específica</option>
          </select>
        </div>

        <div class="form-group" id="boxTurma" style="display:none;">
          <label for="turma_id">Selecione a Turma *</label>
          <select name="turma_id" id="turma_id" class="form-control">
            <option value="">Selecione...</option>
            <?php foreach ($turmas as $t): ?>
              <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group col-span-2">
          <label for="conteudo">Mensagem / Texto do Comunicado *</label>
          <textarea name="conteudo" id="conteudo" class="form-control" rows="6" required placeholder="Escreva o texto completo do comunicado com datas, orientações e observações..."></textarea>
        </div>
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary" style="padding:12px 28px;">Publicar Comunicado</button>
      </div>
    </form>
  </div>
<?php endif; ?>

<!-- LISTAGEM DE COMUNICADOS -->
<?php
// Filtrar comunicados conforme perfil
if ($user['perfil'] === 'aluno') {
    $stmtAluno = $pdo->prepare("SELECT turma_id FROM alunos WHERE usuario_id = ?");
    $stmtAluno->execute([$user['id']]);
    $turmaId = $stmtAluno->fetchColumn();

    $stmtCom = $pdo->prepare("
        SELECT c.*, u.nome as autor_nome, t.nome as turma_nome
        FROM comunicados c
        JOIN usuarios u ON u.id = c.autor_id
        LEFT JOIN turmas t ON t.id = c.turma_id
        WHERE c.publico_alvo IN ('todos', 'alunos') OR (c.publico_alvo = 'turma' AND c.turma_id = ?)
        ORDER BY c.data_publicacao DESC
    ");
    $stmtCom->execute([$turmaId]);
} elseif ($user['perfil'] === 'responsavel') {
    $stmtResp = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
    $stmtResp->execute([$user['id']]);
    $respId = $stmtResp->fetchColumn();

    $stmtCom = $pdo->prepare("
        SELECT DISTINCT c.*, u.nome as autor_nome, t.nome as turma_nome
        FROM comunicados c
        JOIN usuarios u ON u.id = c.autor_id
        LEFT JOIN turmas t ON t.id = c.turma_id
        LEFT JOIN alunos al ON al.turma_id = c.turma_id
        LEFT JOIN alunos_responsaveis ar ON ar.aluno_id = al.id AND ar.responsavel_id = ?
        WHERE c.publico_alvo IN ('todos', 'responsaveis') OR (c.publico_alvo = 'turma' AND ar.id IS NOT NULL)
        ORDER BY c.data_publicacao DESC
    ");
    $stmtCom->execute([$respId]);
} elseif ($user['perfil'] === 'professor') {
    $stmtCom = $pdo->query("
        SELECT c.*, u.nome as autor_nome, t.nome as turma_nome
        FROM comunicados c
        JOIN usuarios u ON u.id = c.autor_id
        LEFT JOIN turmas t ON t.id = c.turma_id
        WHERE c.publico_alvo IN ('todos', 'professores')
        ORDER BY c.data_publicacao DESC
    ");
} else {
    // Diretor / Coordenador
    $stmtCom = $pdo->query("
        SELECT c.*, u.nome as autor_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM comunicados c
        JOIN usuarios u ON u.id = c.autor_id
        LEFT JOIN turmas t ON t.id = c.turma_id
        ORDER BY c.data_publicacao DESC
    ");
}
$comunicados = $stmtCom->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <h2>Mural de Comunicados Oficiais</h2>
    <?php if (hasRole(['diretor', 'coordenador'])): ?>
      <a href="comunicados.php?action=novo" class="btn btn-primary btn-sm">📢 Novo Comunicado</a>
    <?php endif; ?>
  </div>

  <?php if (empty($comunicados)): ?>
    <p style="color:var(--text-muted); font-style:italic;">Nenhum comunicado ativo no momento.</p>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap:20px;">
      <?php foreach ($comunicados as $c): ?>
        <div style="background:#FAF6EF; border:1px solid var(--border-color); border-radius:10px; padding:20px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; flex-wrap:wrap; gap:8px;">
            <div>
              <h3 style="margin:0; color:var(--primary-red); font-size:1.25rem;"><?= htmlspecialchars($c['titulo']) ?></h3>
              <small style="color:var(--text-muted);">
                Publicado por <strong><?= htmlspecialchars($c['autor_nome']) ?></strong> em <?= date('d/m/Y', strtotime($c['data_publicacao'])) ?>
              </small>
            </div>
            <div>
              <span class="badge" style="background:#E0E7FF; color:#3730A3;">
                Destino: <?= ucfirst($c['publico_alvo']) ?> <?= !empty($c['turma_nome']) ? ' (' . htmlspecialchars($c['turma_nome']) . ')' : '' ?>
              </span>
              <?php if (hasRole('diretor')): ?>
                <a href="comunicados.php?action=excluir&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir este comunicado?')" style="margin-left:8px; padding:3px 8px; font-size:0.75rem;">Excluir</a>
              <?php endif; ?>
            </div>
          </div>
          <p style="font-size:0.95rem; color:#374151; line-height:1.6; white-space:pre-line;"><?= htmlspecialchars($c['conteudo']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
