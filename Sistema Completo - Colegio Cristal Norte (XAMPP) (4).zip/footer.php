</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-content">
      <div class="footer-col">
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
          <img src="<?= LOGO_URL ?>" alt="Colégio Cristal Norte" style="height:48px; width:auto; border-radius:6px; background:#fff; padding:3px;">
          <div>
            <h4 style="margin:0; color:#fff;">COLÉGIO CRISTAL NORTE</h4>
            <small style="color:#94A3B8;">Educação & Inovação</small>
          </div>
        </div>
        <p>Formando cidadãos conscientes, críticos e preparados para os desafios do futuro através da excelência pedagógica e acolhimento humano.</p>
      </div>

      <div class="footer-col">
        <h4>Acesso Rápido</h4>
        <ul>
          <li><a href="index.php">Página Inicial</a></li>
          <li><a href="matricula.php">Matrículas 2026</a></li>
          <li><a href="login.php">Portal do Aluno e Responsável</a></li>
          <li><a href="login.php">Portal dos Professores e Equipe</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>Canais de Contato</h4>
        <p>📍 Av. Brasil, 2500 - Jardim Primavera</p>
        <p>📞 (11) 3456-7890 | WhatsApp: (11) 98765-4321</p>
        <p>✉️ contato@colegiocristalnorte.com.br</p>
        <p>🕒 Atendimento: Segunda a Sexta, das 07h30 às 18h30</p>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; <?= date('Y') ?> Colégio Cristal Norte. Todos os direitos reservados. Sistema de Gestão Escolar e Matrículas 2026.</p>
    </div>
  </div>
</footer>

<script src="script.js"></script>
</body>
</html>
