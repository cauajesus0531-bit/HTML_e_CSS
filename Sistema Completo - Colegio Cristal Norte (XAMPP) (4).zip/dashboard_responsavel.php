<?php
/**
 * COLÉGIO CRISTAL NORTE - Dashboard do Responsável
 * Visualização exclusiva dos estudantes vinculados à conta do responsável
 */
require_once __DIR__ . '/config.php';
requireRole('responsavel');

$user = currentUser();
$pdo = getDB();

// 1. Obter os dados do responsável a partir do usuario_id
$stmtResp = $pdo->prepare("SELECT * FROM responsaveis WHERE usuario_id = ? LIMIT 1");
$stmtResp->execute([$user['id']]);
$responsavel = $stmtResp->fetch();

if (!$responsavel) {
    die("Cadastro de responsável não encontrado para este usuário.");
}

$responsavelId = $responsavel['id'];

// 2. Obter TODOS os alunos vinculados a este responsável
$stmtAlunos = $pdo->prepare("
    SELECT a.*, t.nome as turma_nome, t.serie as turma_serie, ar.parentesco
    FROM alunos a
    JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
    JOIN turmas t ON t.id = a.turma_id
    WHERE ar.responsavel_id = ?
    ORDER BY a.nome ASC
");
$stmtAlunos->execute([$responsavelId]);
$filhosVinculados = $stmtAlunos->fetchAll();

if (empty($filhosVinculados)) {
    die("<div class='card text-center'><h2>Nenhum estudante vinculado</h2><p>Não há alunos vinculados a esta conta de responsável no momento.</p></div>");
}

// 3. Gerenciar seleção do aluno (se houver mais de um, permite alternar com validação estrita no backend)
$alunoSelecionadoId = isset($_GET['aluno_id']) ? intval($_GET['aluno_id']) : $filhosVinculados[0]['id'];

// Validação de segurança: o aluno selecionado REALMENTE pertence a este responsável?
$alunoAtual = null;
foreach ($filhosVinculados as $f) {
    if ((int)$f['id'] === $alunoSelecionadoId) {
        $alunoAtual = $f;
        break;
    }
}

if (!$alunoAtual) {
    // Se tentou acessar um ID não vinculado, redefine para o primeiro filho permitido e registra alerta
    $alunoAtual = $filhosVinculados[0];
    $alunoSelecionadoId = $alunoAtual['id'];
    flash('warning', 'Tentativa de acesso não autorizada: você só pode visualizar alunos sob sua responsabilidade.');
}

$alunoId = $alunoAtual['id'];
$turmaId = $alunoAtual['turma_id'];

// 4. Frequência e Faltas do Aluno Selecionado
$stmtFreq = $pdo->prepare("
    SELECT 
        COUNT(*) as total_aulas,
        SUM(CASE WHEN presente = 1 THEN 1 ELSE 0 END) as presencas,
        SUM(CASE WHEN presente = 0 THEN 1 ELSE 0 END) as faltas
    FROM frequencias
    WHERE aluno_id = ?
");
$stmtFreq->execute([$alunoId]);
$freqDados = $stmtFreq->fetch();
$totalAulas = (int)($freqDados['total_aulas'] ?? 0);
$presencas = (int)($freqDados['presencas'] ?? 0);
$faltas = (int)($freqDados['faltas'] ?? 0);
$taxaFrequencia = $totalAulas > 0 ? round(($presencas / $totalAulas) * 100, 1) : 100.0;

// 5. Boletim de Notas do Aluno Selecionado
$stmtNotas = $pdo->prepare("
    SELECT n.*, d.nome as disciplina_nome, p.nome as professor_nome
    FROM notas n
    JOIN disciplinas d ON d.id = n.disciplina_id
    JOIN professores p ON p.id = n.professor_id
    WHERE n.aluno_id = ?
    ORDER BY d.nome ASC
");
$stmtNotas->execute([$alunoId]);
$boletim = $stmtNotas->fetchAll();

$somaMedias = 0;
$countDisciplinas = 0;
foreach ($boletim as $b) {
    if ($b['media_final'] !== null) {
        $somaMedias += (float)$b['media_final'];
        $countDisciplinas++;
    }
}
$mediaGeral = $countDisciplinas > 0 ? round($somaMedias / $countDisciplinas, 2) : 0;

// 6. Atividades da Turma do Filho Selecionado
$stmtAtiv = $pdo->prepare("
    SELECT a.*, d.nome as disciplina_nome, p.nome as professor_nome
    FROM atividades a
    JOIN disciplinas d ON d.id = a.disciplina_id
    JOIN professores p ON p.id = a.professor_id
    WHERE a.turma_id = ?
    ORDER BY a.data_entrega ASC
");
$stmtAtiv->execute([$turmaId]);
$atividades = $stmtAtiv->fetchAll();

// 7. Ocorrências do Filho Selecionado
$stmtOco = $pdo->prepare("
    SELECT o.*, u.nome as autor_nome
    FROM ocorrencias o
    JOIN usuarios u ON u.id = o.autor_id
    WHERE o.aluno_id = ?
    ORDER BY o.data_ocorrencia DESC
");
$stmtOco->execute([$alunoId]);
$ocorrencias = $stmtOco->fetchAll();

// 8. Comunicados para Responsáveis ou para a Turma do Filho
$stmtCom = $pdo->prepare("
    SELECT c.*, u.nome as autor_nome
    FROM comunicados c
    JOIN usuarios u ON u.id = c.autor_id
    WHERE c.publico_alvo IN ('todos', 'responsaveis') OR (c.publico_alvo = 'turma' AND c.turma_id = ?)
    ORDER BY c.data_publicacao DESC
    LIMIT 5
");
$stmtCom->execute([$turmaId]);
$comunicados = $stmtCom->fetchAll();

$pageTitle = 'Portal da Família - ' . htmlspecialchars($responsavel['nome']);
require_once __DIR__ . '/header.php';
?>

<!-- Saudação ao Responsável -->
<div class="card" style="border-left: 6px solid var(--primary-orange);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h2 style="margin:0; font-size:1.5rem; color:var(--text-dark);">
        Olá, <?= htmlspecialchars($responsavel['nome']) ?>!
      </h2>
      <p style="color:var(--text-muted); margin:4px 0 0 0;">
        Portal da Família — Acompanhamento Acadêmico e Pedagógico em Tempo Real
      </p>
    </div>
    <div>
      <span class="badge badge-responsavel" style="font-size:0.9rem; padding:8px 16px;">
        <?= count($filhosVinculados) ?> Estudante(s) Vinculado(s)
      </span>
    </div>
  </div>
</div>

<!-- SELETOR DE ESTUDANTE (quando houver mais de um aluno ou para alternância rápida) -->
<div class="student-selector-box">
  <div style="display:flex; align-items:center; gap:12px;">
    <span style="font-size:1.5rem;">👨‍🎓</span>
    <div>
      <strong style="font-size:1.05rem; color:var(--primary-red);">Selecionar Estudante para Acompanhamento:</strong>
      <div style="font-size:0.85rem; color:var(--text-muted);">Alterne para visualizar notas, frequência e atividades de cada filho(a).</div>
    </div>
  </div>
  <form method="GET" action="dashboard.php" style="display:flex; align-items:center; gap:10px;">
    <select name="aluno_id" onchange="this.form.submit()" class="form-control" style="font-weight:600; min-width:260px;">
      <?php foreach ($filhosVinculados as $filho): ?>
        <option value="<?= $filho['id'] ?>" <?= (int)$filho['id'] === (int)$alunoSelecionadoId ? 'selected' : '' ?>>
          <?= htmlspecialchars($filho['nome']) ?> (<?= htmlspecialchars($filho['turma_serie']) ?>)
        </option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<!-- Ficha Resumida do Estudante Selecionado -->
<div class="card" style="background:#FFFDF9; border:1px solid #EFE4D2;">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h3 style="margin:0; color:var(--primary-red); font-size:1.35rem;"><?= htmlspecialchars($alunoAtual['nome']) ?></h3>
      <p style="margin:4px 0 0 0; color:#4B5563; font-size:0.92rem;">
        <strong>Matrícula:</strong> <span style="color:var(--primary-orange);"><?= htmlspecialchars($alunoAtual['matricula']) ?></span> | 
        <strong>Série/Turma:</strong> <?= htmlspecialchars($alunoAtual['turma_serie']) ?> — <?= htmlspecialchars($alunoAtual['turma_nome']) ?> | 
        <strong>Parentesco:</strong> <?= htmlspecialchars($alunoAtual['parentesco']) ?>
      </p>
    </div>
    <span class="badge badge-aprovado">Ano Letivo 2026</span>
  </div>
</div>

<!-- KPIs do Estudante Selecionado -->
<div class="kpi-grid">
  <div class="kpi-card">
    <span class="kpi-title">Média Acumulada</span>
    <span class="kpi-value" style="color: <?= $mediaGeral >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
      <?= number_format($mediaGeral, 2, ',', '.') ?>
    </span>
    <span class="kpi-sub"><?= $countDisciplinas ?> disciplina(s) avaliadas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Frequência Escolar</span>
    <span class="kpi-value" style="color: <?= $taxaFrequencia >= 75 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
      <?= $taxaFrequencia ?>%
    </span>
    <span class="kpi-sub"><?= $presencas ?> presenças de <?= $totalAulas ?> aulas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Total de Faltas</span>
    <span class="kpi-value" style="color: <?= $faltas > 5 ? 'var(--primary-red)' : 'var(--text-dark)' ?>;">
      <?= $faltas ?>
    </span>
    <span class="kpi-sub">Faltas acumuladas no período</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Ocorrências</span>
    <span class="kpi-value" style="color: <?= count($ocorrencias) > 0 ? 'var(--primary-red)' : 'var(--accent-green)' ?>;">
      <?= count($ocorrencias) ?>
    </span>
    <span class="kpi-sub"><?= count($ocorrencias) == 0 ? 'Nenhum registro' : 'Registros disciplinares' ?></span>
  </div>
</div>

<!-- Boletim de Notas do Filho Selecionado -->
<div class="card">
  <div class="card-header">
    <h2>Boletim Escolar de <?= htmlspecialchars($alunoAtual['nome']) ?></h2>
    <span class="badge" style="background:#E8F5E9; color:#2E7D32;">Atualizado Oficial</span>
  </div>

  <?php if (empty($boletim)): ?>
    <p style="color:var(--text-muted); font-style:italic;">Nenhuma nota lançada até o momento para este estudante.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Disciplina</th>
            <th>Professor(a)</th>
            <th class="text-center">1º Bimestre</th>
            <th class="text-center">2º Bimestre</th>
            <th class="text-center">3º Bimestre</th>
            <th class="text-center">4º Bimestre</th>
            <th class="text-center">Média</th>
            <th class="text-center">Situação</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($boletim as $n): ?>
            <tr>
              <td><strong><?= htmlspecialchars($n['disciplina_nome']) ?></strong></td>
              <td><?= htmlspecialchars($n['professor_nome']) ?></td>
              <td class="text-center"><?= $n['avaliacao1'] !== null ? number_format($n['avaliacao1'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao2'] !== null ? number_format($n['avaliacao2'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao3'] !== null ? number_format($n['avaliacao3'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao4'] !== null ? number_format($n['avaliacao4'], 1, ',', '.') : '-' ?></td>
              <td class="text-center" style="font-weight:700; color:<?= ($n['media_final'] ?? 0) >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
                <?= $n['media_final'] !== null ? number_format($n['media_final'], 2, ',', '.') : '-' ?>
              </td>
              <td class="text-center">
                <?php
                  $sitClass = 'badge-cursando';
                  if ($n['situacao'] === 'aprovado') $sitClass = 'badge-aprovado';
                  elseif ($n['situacao'] === 'recuperacao') $sitClass = 'badge-recuperacao';
                  elseif ($n['situacao'] === 'reprovado') $sitClass = 'badge-reprovado';
                ?>
                <span class="badge <?= $sitClass ?>"><?= ucfirst($n['situacao']) ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="form-grid-2">
  <!-- Atividades Previstas -->
  <div class="card">
    <div class="card-header">
      <h2>Atividades e Trabalhos da Turma</h2>
    </div>
    <?php if (empty($atividades)): ?>
      <p style="color:var(--text-muted);">Nenhuma atividade cadastrada no momento.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($atividades as $ativ): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border-left:4px solid <?= $ativ['status'] === 'aberta' ? 'var(--primary-orange)' : '#9E9E9E' ?>;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
              <h4 style="margin:0; font-size:1rem; color:var(--text-dark);"><?= htmlspecialchars($ativ['titulo']) ?></h4>
              <span class="badge" style="background:<?= $ativ['status'] === 'aberta' ? '#FFF3E0' : '#EEEEEE' ?>; color:<?= $ativ['status'] === 'aberta' ? '#E65100' : '#616161' ?>;">
                <?= ucfirst($ativ['status']) ?>
              </span>
            </div>
            <p style="font-size:0.85rem; color:#4B5563; margin:6px 0;"><?= htmlspecialchars($ativ['descricao']) ?></p>
            <div style="font-size:0.8rem; color:#6B7280; display:flex; justify-content:space-between;">
              <span><strong>Disciplina:</strong> <?= htmlspecialchars($ativ['disciplina_nome']) ?></span>
              <span><strong>Data de Entrega:</strong> <?= date('d/m/Y', strtotime($ativ['data_entrega'])) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Ocorrências e Comunicados -->
  <div>
    <!-- Ocorrências do Filho -->
    <div class="card">
      <div class="card-header">
        <h2>Ocorrências Disciplinares</h2>
      </div>
      <?php if (empty($ocorrencias)): ?>
        <p style="color:var(--accent-green); font-weight:600;">✓ Nenhuma ocorrência registrada para <?= htmlspecialchars($alunoAtual['nome']) ?>.</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:10px;">
          <?php foreach ($ocorrencias as $oco): ?>
            <div style="padding:12px; background:#FFF5F5; border-radius:8px; border-left:4px solid var(--primary-red);">
              <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;">
                <strong>Data: <?= date('d/m/Y', strtotime($oco['data_ocorrencia'])) ?></strong>
                <span class="badge" style="background:#FED7AA; color:#9A3412;"><?= ucfirst($oco['situacao']) ?></span>
              </div>
              <p style="font-size:0.88rem; color:#7F1D1D;"><?= htmlspecialchars($oco['descricao']) ?></p>
              <small style="color:#9CA3AF;">Registrado por: <?= htmlspecialchars($oco['autor_nome']) ?></small>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Comunicados da Escola -->
    <div class="card">
      <div class="card-header">
        <h2>Comunicados da Escola</h2>
      </div>
      <?php if (empty($comunicados)): ?>
        <p style="color:var(--text-muted);">Nenhum comunicado recente.</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:12px;">
          <?php foreach ($comunicados as $c): ?>
            <div style="padding:12px; background:#FAF6EF; border-radius:8px; border:1px solid var(--border-color);">
              <h4 style="margin:0 0 6px 0; font-size:0.98rem; color:var(--primary-red);"><?= htmlspecialchars($c['titulo']) ?></h4>
              <p style="font-size:0.88rem; color:#374151; margin-bottom:8px;"><?= nl2br(htmlspecialchars($c['conteudo'])) ?></p>
              <div style="font-size:0.78rem; color:#9CA3AF; display:flex; justify-content:space-between;">
                <span>Publicado por: <?= htmlspecialchars($c['autor_nome']) ?></span>
                <span><?= date('d/m/Y', strtotime($c['data_publicacao'])) ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
