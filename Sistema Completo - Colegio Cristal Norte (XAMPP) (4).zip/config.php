<?php
/**
 * COLÉGIO CRISTAL NORTE - Configuração Geral e Conexão PDO
 * Portal Acadêmico e de Matrículas Escolares - Ano Letivo 2026
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configurações do Banco de Dados MySQL
define('DB_HOST', 'localhost');
define('DB_NAME', 'cristal_norte');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', '3306');

// Configurações da Aplicação
define('APP_NAME', 'Colégio Cristal Norte');
define('APP_SLOGAN', 'Educação & Inovação — Ano Letivo 2026');
define('APP_URL', 'http://localhost/colegio_cristal_norte');

// Caminho do Logo Oficial
$localLogo = __DIR__ . '/assets/logo.jpg';
if (file_exists($localLogo)) {
    define('LOGO_URL', 'assets/logo.jpg');
} else {
    define('LOGO_URL', 'https://cristalconnect.agentceres.app/__assets/d0cde4c801dee349d6526b54410be5b9fac3f1b1f7afaa6a22b85eb822fae945.jpg');
}

/**
 * Retorna a conexão PDO com o MySQL
 */
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("<div style='font-family:sans-serif;padding:30px;background:#FFF3CD;border:1px solid #FFEEBA;color:#856404;border-radius:8px;max-width:700px;margin:50px auto;'>"
                . "<h2 style='color:#C62828;'>Erro de Conexão com o Banco de Dados</h2>"
                . "<p>Não foi possível conectar ao banco <strong>" . DB_NAME . "</strong> no MySQL.</p>"
                . "<p><strong>Verifique se:</strong></p>"
                . "<ul>"
                . "<li>O MySQL está iniciado no XAMPP Control Panel.</li>"
                . "<li>O banco de dados <strong>cristal_norte</strong> foi criado e importado via phpMyAdmin.</li>"
                . "</ul>"
                . "<p><small>Detalhes técnicos: " . htmlspecialchars($e->getMessage()) . "</small></p>"
                . "</div>");
        }
    }
    return $pdo;
}

/**
 * Sanitização de dados de entrada
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return trim(htmlspecialchars((string)$data, ENT_QUOTES, 'UTF-8'));
}

/**
 * Autenticação e Perfis
 */
function isLoggedIn() {
    return isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
}

function currentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    return [
        'id' => $_SESSION['usuario_id'],
        'nome' => $_SESSION['usuario_nome'] ?? 'Usuário',
        'email' => $_SESSION['usuario_email'] ?? '',
        'perfil' => $_SESSION['usuario_perfil'] ?? '',
        'detalhe_id' => $_SESSION['usuario_detalhe_id'] ?? null // ID na tabela específica (professor, aluno, etc.)
    ];
}

function hasRole($roles) {
    if (!isLoggedIn()) return false;
    if (is_string($roles)) $roles = [$roles];
    return in_array($_SESSION['usuario_perfil'], $roles);
}

function requireLogin() {
    if (!isLoggedIn()) {
        flash('error', 'Por favor, faça login para acessar esta página.');
        header('Location: login.php');
        exit;
    }
}

function requireRole($roles) {
    requireLogin();
    if (!hasRole($roles)) {
        flash('error', 'Acesso negado: seu perfil não tem permissão para visualizar esta página.');
        header('Location: dashboard.php');
        exit;
    }
}

/**
 * Mensagens Flash de Notificação
 */
function flash($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type, // 'success', 'error', 'warning', 'info'
        'message' => $message
    ];
}

function getFlash() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $msg;
    }
    return null;
}

/**
 * Cálculo preciso de idade usando data completa de nascimento
 */
function calcularIdade($dataNasc) {
    if (empty($dataNasc)) return 0;
    try {
        $nascimento = new DateTime($dataNasc);
        $hoje = new DateTime('now');
        $intervalo = $hoje->diff($nascimento);
        return $intervalo->y;
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Gerador de número de matrícula único no formato MAT-2026-XXXXX
 */
function gerarNumeroMatricula($pdo) {
    $ano = '2026';
    $maxTentativas = 50;
    for ($i = 0; $i < $maxTentativas; $i++) {
        $sufixo = str_pad(mt_rand(10000, 99999), 5, '0', STR_PAD_LEFT);
        $matricula = "MAT-{$ano}-{$sufixo}";
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM alunos WHERE matricula = ?");
        $stmt->execute([$matricula]);
        if ($stmt->fetchColumn() == 0) {
            return $matricula;
        }
    }
    return "MAT-{$ano}-" . time();
}
