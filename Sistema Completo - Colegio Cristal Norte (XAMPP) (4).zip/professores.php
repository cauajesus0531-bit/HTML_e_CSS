<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão Administrativa de Professores
 * Cadastro e visualização de docentes vinculados às suas disciplinas exclusivas
 */
require_once __DIR__ . '/config.php';
requireRole('diretor');

$pdo = getDB();
$action = $_GET['action'] ?? 'listar';

// Cadastrar Novo Professor
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $cpf = trim($_POST['cpf'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $disciplinaId = intval($_POST['disciplina_id'] ?? 0);

    if (empty($nome) || empty($email) || empty($senha) || empty($cpf) || empty($disciplinaId)) {
        flash('error', 'Por favor, preencha todos os campos obrigatórios.');
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Criar usuário no login
            $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
            $stmtU = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, perfil, ativo) VALUES (?, ?, ?, 'professor', 1)");
            $stmtU->execute([$nome, $email, $senhaHash]);
            $usuarioId = $pdo->lastInsertId();

            // 2. Criar cadastro do professor com a disciplina vinculada
            $stmtP = $pdo->prepare("INSERT INTO professores (usuario_id, nome, cpf, email, telefone, disciplina_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmtP->execute([$usuarioId, $nome, $cpf, $email, $telefone, $disciplinaId]);

            $pdo->commit();
            flash('success', "Professor {$nome} cadastrado com sucesso!");
            header('Location: professores.php');
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            flash('error', 'Erro ao cadastrar professor (verifique se e-mail ou CPF já existem): ' . $e->getMessage());
        }
    }
}

// Listagem de Professores
$stmtProfs = $pdo->query("
    SELECT 
        p.*, 
        d.nome as disciplina_nome,
        (SELECT COUNT(DISTINCT pt.turma_id) FROM professor_turmas pt WHERE pt.professor_id = p.id) as total_turmas
    FROM professores p
    JOIN disciplinas d ON d.id = p.disciplina_id
    ORDER BY p.nome ASC
");
$professores = $stmtProfs->fetchAll();

$disciplinas = $pdo->query("SELECT id, nome, codigo FROM disciplinas ORDER BY nome ASC")->fetchAll();

$pageTitle = 'Gestão do Corpo Docente';
require_once __DIR__ . '/header.php';
?>

<div class="form-grid-2">
  <!-- Listagem de Professores -->
  <div class="card">
    <div class="card-header">
      <h2>Corpo Docente Cadastrado</h2>
      <span class="badge badge-aprovado"><?= count($professores) ?> Professores</span>
    </div>

    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Disciplina Vinculada</th>
            <th>Contato</th>
            <th class="text-center">Turmas</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($professores as $p): ?>
            <tr>
              <td>
                <strong><?= htmlspecialchars($p['nome']) ?></strong>
                <br><small style="color:var(--text-muted);">CPF: <?= htmlspecialchars($p['cpf']) ?></small>
              </td>
              <td>
                <span class="badge" style="background:#E0F2FE; color:#0369A1; font-size:0.85rem;">
                  <?= htmlspecialchars($p['disciplina_nome']) ?>
                </span>
              </td>
              <td>
                <?= htmlspecialchars($p['email']) ?>
                <br><small style="color:var(--text-muted);"><?= htmlspecialchars($p['telefone'] ?? '-') ?></small>
              </td>
              <td class="text-center">
                <span class="badge badge-aprovado"><?= $p['total_turmas'] ?> turma(s)</span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Cadastro de Novo Professor -->
  <div class="card">
    <div class="card-header">
      <h2>Cadastrar Novo Professor</h2>
    </div>

    <form method="POST" action="professores.php?action=salvar">
      <div class="form-group">
        <label for="nome">Nome Completo do Professor *</label>
        <input type="text" name="nome" id="nome" class="form-control" required placeholder="Ex: Profa. Ana Clara Rezende">
      </div>

      <div class="form-group">
        <label for="disciplina_id">Disciplina de Atuação Exclusiva *</label>
        <select name="disciplina_id" id="disciplina_id" class="form-control" required>
          <option value="">Selecione a disciplina...</option>
          <?php foreach ($disciplinas as $d): ?>
            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nome']) ?> (<?= htmlspecialchars($d['codigo']) ?>)</option>
          <?php endforeach; ?>
        </select>
        <small style="color:var(--text-muted);">O professor terá acesso restrito exclusivamente a esta disciplina.</small>
      </div>

      <div class="form-group">
        <label for="cpf">CPF do Professor *</label>
        <input type="text" name="cpf" id="cpf" class="form-control mask-cpf" required placeholder="000.000.000-00">
      </div>

      <div class="form-group">
        <label for="telefone">Telefone de Contato</label>
        <input type="text" name="telefone" id="telefone" class="form-control mask-phone" placeholder="(00) 00000-0000">
      </div>

      <div class="form-group">
        <label for="email">E-mail Institucional (Login) *</label>
        <input type="email" name="email" id="email" class="form-control" required placeholder="professor@cristalnorte.com.br">
      </div>

      <div class="form-group">
        <label for="senha">Senha de Acesso Inicial *</label>
        <input type="password" name="senha" id="senha" class="form-control" required minlength="6" placeholder="Defina a senha inicial">
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary btn-block">Salvar e Criar Acesso do Professor</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
