<?php
/**
 * COLÉGIO CRISTAL NORTE - Dashboard do Aluno
 * Visualização exclusiva dos próprios dados do aluno logado
 */
require_once __DIR__ . '/config.php';
requireRole('aluno');

$user = currentUser();
$pdo = getDB();

// 1. Obter os dados do aluno logado estritamente pelo usuario_id da sessão
$stmtAluno = $pdo->prepare("
    SELECT a.*, t.nome as turma_nome, t.serie as turma_serie 
    FROM alunos a
    JOIN turmas t ON t.id = a.turma_id
    WHERE a.usuario_id = ?
    LIMIT 1
");
$stmtAluno->execute([$user['id']]);
$aluno = $stmtAluno->fetch();

if (!$aluno) {
    die("Registro de aluno não encontrado para este usuário.");
}

$alunoId = $aluno['id'];
$turmaId = $aluno['turma_id'];

// 2. Frequência Geral e Faltas do Aluno
$stmtFreq = $pdo->prepare("
    SELECT 
        COUNT(*) as total_aulas,
        SUM(CASE WHEN presente = 1 THEN 1 ELSE 0 END) as presencas,
        SUM(CASE WHEN presente = 0 THEN 1 ELSE 0 END) as faltas
    FROM frequencias
    WHERE aluno_id = ?
");
$stmtFreq->execute([$alunoId]);
$freqDados = $stmtFreq->fetch();
$totalAulas = (int)($freqDados['total_aulas'] ?? 0);
$presencas = (int)($freqDados['presencas'] ?? 0);
$faltas = (int)($freqDados['faltas'] ?? 0);
$taxaFrequencia = $totalAulas > 0 ? round(($presencas / $totalAulas) * 100, 1) : 100.0;

// 3. Boletim de Notas do Aluno
$stmtNotas = $pdo->prepare("
    SELECT n.*, d.nome as disciplina_nome, p.nome as professor_nome
    FROM notas n
    JOIN disciplinas d ON d.id = n.disciplina_id
    JOIN professores p ON p.id = n.professor_id
    WHERE n.aluno_id = ?
    ORDER BY d.nome ASC
");
$stmtNotas->execute([$alunoId]);
$boletim = $stmtNotas->fetchAll();

// Média geral do aluno
$somaMedias = 0;
$countDisciplinas = 0;
foreach ($boletim as $b) {
    if ($b['media_final'] !== null) {
        $somaMedias += (float)$b['media_final'];
        $countDisciplinas++;
    }
}
$mediaGeral = $countDisciplinas > 0 ? round($somaMedias / $countDisciplinas, 2) : 0;

// 4. Atividades da Turma do Aluno
$stmtAtiv = $pdo->prepare("
    SELECT a.*, d.nome as disciplina_nome, p.nome as professor_nome
    FROM atividades a
    JOIN disciplinas d ON d.id = a.disciplina_id
    JOIN professores p ON p.id = a.professor_id
    WHERE a.turma_id = ?
    ORDER BY a.data_entrega ASC
    LIMIT 6
");
$stmtAtiv->execute([$turmaId]);
$atividades = $stmtAtiv->fetchAll();

// 5. Ocorrências do Aluno
$stmtOcorrencias = $pdo->prepare("
    SELECT o.*, u.nome as autor_nome
    FROM ocorrencias o
    JOIN usuarios u ON u.id = o.autor_id
    WHERE o.aluno_id = ?
    ORDER BY o.data_ocorrencia DESC
");
$stmtOcorrencias->execute([$alunoId]);
$ocorrencias = $stmtOcorrencias->fetchAll();

// 6. Comunicados direcionados ao aluno ou sua turma
$stmtCom = $pdo->prepare("
    SELECT c.*, u.nome as autor_nome
    FROM comunicados c
    JOIN usuarios u ON u.id = c.autor_id
    WHERE c.publico_alvo IN ('todos', 'alunos') OR (c.publico_alvo = 'turma' AND c.turma_id = ?)
    ORDER BY c.data_publicacao DESC
    LIMIT 5
");
$stmtCom->execute([$turmaId]);
$comunicados = $stmtCom->fetchAll();

$pageTitle = 'Portal do Aluno - ' . htmlspecialchars($aluno['nome']);
require_once __DIR__ . '/header.php';
?>

<!-- Perfil do Aluno -->
<div class="card" style="border-left: 6px solid var(--primary-red);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div style="display:flex; align-items:center; gap:20px;">
      <div style="width:72px; height:72px; border-radius:50%; background:var(--bg-beige); border:2px solid var(--primary-orange); display:flex; align-items:center; justify-content:center; font-size:2rem; color:var(--primary-red);">
        👨‍🎓
      </div>
      <div>
        <h2 style="margin:0; font-size:1.6rem;"><?= htmlspecialchars($aluno['nome']) ?></h2>
        <p style="color:var(--text-muted); margin:4px 0 0 0;">
          <strong>Matrícula:</strong> <span style="color:var(--primary-orange); font-weight:700;"><?= htmlspecialchars($aluno['matricula']) ?></span> | 
          <strong>Série/Turma:</strong> <?= htmlspecialchars($aluno['turma_serie']) ?> — <?= htmlspecialchars($aluno['turma_nome']) ?> | 
          <strong>Ano Letivo:</strong> 2026
        </p>
      </div>
    </div>
    <div>
      <span class="badge badge-aprovado" style="font-size:0.9rem; padding:8px 16px;">Matrícula Ativa</span>
    </div>
  </div>
</div>

<!-- KPIs Acadêmicos do Aluno -->
<div class="kpi-grid">
  <div class="kpi-card">
    <span class="kpi-title">Média Geral Acumulada</span>
    <span class="kpi-value" style="color: <?= $mediaGeral >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
      <?= number_format($mediaGeral, 2, ',', '.') ?>
    </span>
    <span class="kpi-sub"><?= $countDisciplinas ?> disciplina(s) avaliada(s)</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Frequência Geral</span>
    <span class="kpi-value" style="color: <?= $taxaFrequencia >= 75 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
      <?= $taxaFrequencia ?>%
    </span>
    <span class="kpi-sub"><?= $presencas ?> presenças de <?= $totalAulas ?> aulas registradas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Total de Faltas</span>
    <span class="kpi-value" style="color: <?= $faltas > 5 ? 'var(--primary-red)' : 'var(--text-dark)' ?>;">
      <?= $faltas ?>
    </span>
    <span class="kpi-sub"><?= $faltas == 0 ? 'Excelente assiduidade' : 'Atenção ao limite de faltas' ?></span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Atividades Abertas</span>
    <span class="kpi-value" style="color: var(--primary-orange);">
      <?= count(array_filter($atividades, fn($a) => $a['status'] === 'aberta')) ?>
    </span>
    <span class="kpi-sub">Trabalhos e tarefas do período</span>
  </div>
</div>

<!-- Seção: Boletim de Notas do Aluno -->
<div class="card">
  <div class="card-header">
    <h2>Boletim Escolar Oficial</h2>
    <span class="badge" style="background:#E3F2FD; color:#1565C0;">Ano Letivo 2026</span>
  </div>

  <?php if (empty($boletim)): ?>
    <p style="color:var(--text-muted); font-style:italic;">Nenhuma nota lançada até o momento para este período letivo.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Disciplina</th>
            <th>Professor Responsável</th>
            <th class="text-center">1º Bimestre</th>
            <th class="text-center">2º Bimestre</th>
            <th class="text-center">3º Bimestre</th>
            <th class="text-center">4º Bimestre</th>
            <th class="text-center">Média Final</th>
            <th class="text-center">Situação</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($boletim as $n): ?>
            <tr>
              <td><strong><?= htmlspecialchars($n['disciplina_nome']) ?></strong></td>
              <td><?= htmlspecialchars($n['professor_nome']) ?></td>
              <td class="text-center"><?= $n['avaliacao1'] !== null ? number_format($n['avaliacao1'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao2'] !== null ? number_format($n['avaliacao2'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao3'] !== null ? number_format($n['avaliacao3'], 1, ',', '.') : '-' ?></td>
              <td class="text-center"><?= $n['avaliacao4'] !== null ? number_format($n['avaliacao4'], 1, ',', '.') : '-' ?></td>
              <td class="text-center" style="font-weight:700; font-size:1rem; color:<?= ($n['media_final'] ?? 0) >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
                <?= $n['media_final'] !== null ? number_format($n['media_final'], 2, ',', '.') : '-' ?>
              </td>
              <td class="text-center">
                <?php
                  $sitClass = 'badge-cursando';
                  if ($n['situacao'] === 'aprovado') $sitClass = 'badge-aprovado';
                  elseif ($n['situacao'] === 'recuperacao') $sitClass = 'badge-recuperacao';
                  elseif ($n['situacao'] === 'reprovado') $sitClass = 'badge-reprovado';
                ?>
                <span class="badge <?= $sitClass ?>"><?= ucfirst($n['situacao']) ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="form-grid-2">
  <!-- Atividades e Tarefas -->
  <div class="card">
    <div class="card-header">
      <h2>Minhas Atividades & Trabalhos</h2>
      <a href="atividades.php" class="btn btn-secondary btn-sm">Ver Todas</a>
    </div>
    <?php if (empty($atividades)): ?>
      <p style="color:var(--text-muted);">Nenhuma atividade cadastrada no momento.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($atividades as $ativ): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border-left:4px solid <?= $ativ['status'] === 'aberta' ? 'var(--primary-orange)' : '#9E9E9E' ?>;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
              <h4 style="margin:0; font-size:1rem; color:var(--text-dark);"><?= htmlspecialchars($ativ['titulo']) ?></h4>
              <span class="badge" style="background:<?= $ativ['status'] === 'aberta' ? '#FFF3E0' : '#EEEEEE' ?>; color:<?= $ativ['status'] === 'aberta' ? '#E65100' : '#616161' ?>;">
                <?= ucfirst($ativ['status']) ?>
              </span>
            </div>
            <p style="font-size:0.85rem; color:#4B5563; margin:6px 0;"><?= htmlspecialchars($ativ['descricao']) ?></p>
            <div style="font-size:0.8rem; color:#6B7280; display:flex; justify-content:space-between;">
              <span><strong>Disciplina:</strong> <?= htmlspecialchars($ativ['disciplina_nome']) ?></span>
              <span><strong>Entrega:</strong> <?= date('d/m/Y', strtotime($ativ['data_entrega'])) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Comunicados e Ocorrências -->
  <div>
    <!-- Comunicados -->
    <div class="card">
      <div class="card-header">
        <h2>Mural de Comunicados</h2>
      </div>
      <?php if (empty($comunicados)): ?>
        <p style="color:var(--text-muted);">Nenhum comunicado recente.</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:12px;">
          <?php foreach ($comunicados as $c): ?>
            <div style="padding:12px; background:#FAF6EF; border-radius:8px; border:1px solid var(--border-color);">
              <h4 style="margin:0 0 6px 0; font-size:0.98rem; color:var(--primary-red);"><?= htmlspecialchars($c['titulo']) ?></h4>
              <p style="font-size:0.88rem; color:#374151; margin-bottom:8px;"><?= nl2br(htmlspecialchars($c['conteudo'])) ?></p>
              <div style="font-size:0.78rem; color:#9CA3AF; display:flex; justify-content:space-between;">
                <span>Por: <?= htmlspecialchars($c['autor_nome']) ?></span>
                <span><?= date('d/m/Y', strtotime($c['data_publicacao'])) ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Ocorrências do Aluno -->
    <div class="card">
      <div class="card-header">
        <h2>Registro de Ocorrências</h2>
      </div>
      <?php if (empty($ocorrencias)): ?>
        <p style="color:var(--accent-green); font-weight:600;">✓ Nenhuma ocorrência disciplinar registrada. Excelente conduta!</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:10px;">
          <?php foreach ($ocorrencias as $oco): ?>
            <div style="padding:12px; background:#FFF5F5; border-radius:8px; border-left:4px solid var(--primary-red);">
              <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;">
                <strong>Data: <?= date('d/m/Y', strtotime($oco['data_ocorrencia'])) ?></strong>
                <span class="badge" style="background:#FED7AA; color:#9A3412;"><?= ucfirst($oco['situacao']) ?></span>
              </div>
              <p style="font-size:0.88rem; color:#7F1D1D;"><?= htmlspecialchars($oco['descricao']) ?></p>
              <small style="color:#9CA3AF;">Registrado por: <?= htmlspecialchars($oco['autor_nome']) ?></small>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
