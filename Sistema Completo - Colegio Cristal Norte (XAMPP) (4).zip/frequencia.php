<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão e Relatório de Frequência Escolar
 * Controle de Permissões:
 * - Aluno: somente seu próprio histórico
 * - Responsável: somente filhos vinculados
 * - Professor: somente suas turmas e sua disciplina
 * - Diretor/Coordenador: supervisão geral
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

// 1. PERFIL: ALUNO
if ($user['perfil'] === 'aluno') {
    $stmtAluno = $pdo->prepare("SELECT id, nome FROM alunos WHERE usuario_id = ?");
    $stmtAluno->execute([$user['id']]);
    $aluno = $stmtAluno->fetch();

    $stmtFreq = $pdo->prepare("
        SELECT f.*, d.nome as disciplina_nome, p.nome as professor_nome
        FROM frequencias f
        JOIN disciplinas d ON d.id = f.disciplina_id
        JOIN professores p ON p.id = f.professor_id
        WHERE f.aluno_id = ?
        ORDER BY f.data_aula DESC
    ");
    $stmtFreq->execute([$aluno['id']]);
    $historico = $stmtFreq->fetchAll();

    // Resumo de presença
    $total = count($historico);
    $presencas = count(array_filter($historico, fn($f) => $f['presente'] == 1));
    $faltas = $total - $presencas;
    $perc = $total > 0 ? round(($presencas / $total) * 100, 1) : 100;

    $pageTitle = 'Minha Frequência Escolar';
    require_once __DIR__ . '/header.php';
    ?>
    <div class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-title">Percentual de Frequência</span>
        <span class="kpi-value" style="color:<?= $perc >= 75 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;"><?= $perc ?>%</span>
        <span class="kpi-sub">Mínimo exigido: 75%</span>
      </div>
      <div class="kpi-card">
        <span class="kpi-title">Aulas Registradas</span>
        <span class="kpi-value"><?= $total ?></span>
        <span class="kpi-sub">Total no período</span>
      </div>
      <div class="kpi-card">
        <span class="kpi-title">Presenças</span>
        <span class="kpi-value" style="color:var(--accent-green);"><?= $presencas ?></span>
        <span class="kpi-sub">Aulas assistidas</span>
      </div>
      <div class="kpi-card">
        <span class="kpi-title">Faltas</span>
        <span class="kpi-value" style="color:<?= $faltas > 3 ? 'var(--primary-red)' : 'var(--text-dark)' ?>;"><?= $faltas ?></span>
        <span class="kpi-sub">Ausências registradas</span>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Histórico Detalhado de Frequência</h2>
      </div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Data da Aula</th>
              <th>Disciplina</th>
              <th>Professor</th>
              <th class="text-center">Status</th>
              <th>Observação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($historico as $h): ?>
              <tr>
                <td><strong><?= date('d/m/Y', strtotime($h['data_aula'])) ?></strong></td>
                <td><?= htmlspecialchars($h['disciplina_nome']) ?></td>
                <td><?= htmlspecialchars($h['professor_nome']) ?></td>
                <td class="text-center">
                  <span class="badge <?= $h['presente'] == 1 ? 'badge-presente' : 'badge-ausente' ?>">
                    <?= $h['presente'] == 1 ? 'Presente' : 'Ausente' ?>
                  </span>
                </td>
                <td><?= htmlspecialchars($h['observacao'] ?? '-') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 2. PERFIL: RESPONSÁVEL
if ($user['perfil'] === 'responsavel') {
    $stmtResp = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
    $stmtResp->execute([$user['id']]);
    $respId = $stmtResp->fetchColumn();

    $stmtFilhos = $pdo->prepare("
        SELECT a.id, a.nome, t.serie, t.nome as turma_nome
        FROM alunos a
        JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
        JOIN turmas t ON t.id = a.turma_id
        WHERE ar.responsavel_id = ?
    ");
    $stmtFilhos->execute([$respId]);
    $filhos = $stmtFilhos->fetchAll();

    $alunoId = isset($_GET['aluno_id']) ? intval($_GET['aluno_id']) : ($filhos[0]['id'] ?? 0);

    // Validação estrita
    $filhoAtual = null;
    foreach ($filhos as $f) {
        if ((int)$f['id'] === $alunoId) {
            $filhoAtual = $f;
            break;
        }
    }
    if (!$filhoAtual && !empty($filhos)) {
        $filhoAtual = $filhos[0];
        $alunoId = $filhoAtual['id'];
    }

    $stmtFreq = $pdo->prepare("
        SELECT f.*, d.nome as disciplina_nome, p.nome as professor_nome
        FROM frequencias f
        JOIN disciplinas d ON d.id = f.disciplina_id
        JOIN professores p ON p.id = f.professor_id
        WHERE f.aluno_id = ?
        ORDER BY f.data_aula DESC
    ");
    $stmtFreq->execute([$alunoId]);
    $historico = $stmtFreq->fetchAll();

    $total = count($historico);
    $presencas = count(array_filter($historico, fn($f) => $f['presente'] == 1));
    $faltas = $total - $presencas;
    $perc = $total > 0 ? round(($presencas / $total) * 100, 1) : 100;

    $pageTitle = 'Frequência Escolar do Aluno';
    require_once __DIR__ . '/header.php';
    ?>
    <div class="card">
      <div class="card-header">
        <h2>Frequência Escolar — <?= htmlspecialchars($filhoAtual['nome']) ?></h2>
        <?php if (count($filhos) > 1): ?>
          <form method="GET" action="frequencia.php">
            <select name="aluno_id" onchange="this.form.submit()" class="form-control" style="font-weight:600;">
              <?php foreach ($filhos as $f): ?>
                <option value="<?= $f['id'] ?>" <?= (int)$f['id'] === (int)$alunoId ? 'selected' : '' ?>>
                  <?= htmlspecialchars($f['nome']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>
        <?php endif; ?>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card">
          <span class="kpi-title">Percentual de Presença</span>
          <span class="kpi-value" style="color:<?= $perc >= 75 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;"><?= $perc ?>%</span>
          <span class="kpi-sub">Frequência global</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-title">Aulas Registradas</span>
          <span class="kpi-value"><?= $total ?></span>
          <span class="kpi-sub">Total de aulas</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-title">Total de Faltas</span>
          <span class="kpi-value" style="color:<?= $faltas > 3 ? 'var(--primary-red)' : 'var(--text-dark)' ?>;"><?= $faltas ?></span>
          <span class="kpi-sub">Faltas no período</span>
        </div>
      </div>

      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Data</th>
              <th>Disciplina</th>
              <th>Professor</th>
              <th class="text-center">Condição</th>
              <th>Observação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($historico as $h): ?>
              <tr>
                <td><strong><?= date('d/m/Y', strtotime($h['data_aula'])) ?></strong></td>
                <td><?= htmlspecialchars($h['disciplina_nome']) ?></td>
                <td><?= htmlspecialchars($h['professor_nome']) ?></td>
                <td class="text-center">
                  <span class="badge <?= $h['presente'] == 1 ? 'badge-presente' : 'badge-ausente' ?>">
                    <?= $h['presente'] == 1 ? 'Presente' : 'Ausente' ?>
                  </span>
                </td>
                <td><?= htmlspecialchars($h['observacao'] ?? '-') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 3. PERFIL: PROFESSOR (Redireciona para o diário de classe na aba frequência)
if ($user['perfil'] === 'professor') {
    $turmaId = isset($_GET['turma_id']) ? intval($_GET['turma_id']) : 0;
    if ($turmaId > 0) {
        header("Location: diario.php?turma_id={$turmaId}&tab=frequencia");
    } else {
        header("Location: diario.php?tab=frequencia");
    }
    exit;
}

// 4. PERFIL: DIRETOR / COORDENADOR (Supervisão Geral de Frequência por Turma)
requireRole(['diretor', 'coordenador']);

$turmaId = isset($_GET['turma_id']) ? intval($_GET['turma_id']) : 1;
$turmas = $pdo->query("SELECT id, nome, serie FROM turmas WHERE ano_letivo = 2026 ORDER BY serie, nome")->fetchAll();

$stmtFreqGeral = $pdo->prepare("
    SELECT 
        a.id as aluno_id, 
        a.nome as aluno_nome, 
        a.matricula,
        COUNT(f.id) as total_aulas,
        SUM(CASE WHEN f.presente = 1 THEN 1 ELSE 0 END) as presencas,
        SUM(CASE WHEN f.presente = 0 THEN 1 ELSE 0 END) as faltas
    FROM alunos a
    LEFT JOIN frequencias f ON f.aluno_id = a.id
    WHERE a.turma_id = ? AND a.status = 'ativo'
    GROUP BY a.id, a.nome, a.matricula
    ORDER BY a.nome ASC
");
$stmtFreqGeral->execute([$turmaId]);
$relatorioFreq = $stmtFreqGeral->fetchAll();

$pageTitle = 'Relatório Geral de Frequência';
require_once __DIR__ . '/header.php';
?>

<div class="card">
  <div class="card-header">
    <h2>Supervisão de Frequência e Assiduidade</h2>
    <form method="GET" action="frequencia.php">
      <select name="turma_id" onchange="this.form.submit()" class="form-control" style="font-weight:600;">
        <?php foreach ($turmas as $t): ?>
          <option value="<?= $t['id'] ?>" <?= (int)$t['id'] === (int)$turmaId ? 'selected' : '' ?>>
            <?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Estudante</th>
          <th class="text-center">Total de Aulas</th>
          <th class="text-center">Presenças</th>
          <th class="text-center">Faltas</th>
          <th class="text-center">% Frequência</th>
          <th class="text-center">Situação da Assiduidade</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($relatorioFreq as $rf): ?>
          <?php
            $tot = (int)$rf['total_aulas'];
            $pre = (int)$rf['presencas'];
            $fal = (int)$rf['faltas'];
            $pct = $tot > 0 ? round(($pre / $tot) * 100, 1) : 100.0;
          ?>
          <tr>
            <td>
              <strong><?= htmlspecialchars($rf['aluno_nome']) ?></strong>
              <br><small style="color:var(--text-muted);"><?= htmlspecialchars($rf['matricula']) ?></small>
            </td>
            <td class="text-center"><?= $tot ?></td>
            <td class="text-center" style="color:var(--accent-green); font-weight:700;"><?= $pre ?></td>
            <td class="text-center" style="color:<?= $fal > 3 ? 'var(--primary-red)' : 'var(--text-dark)' ?>; font-weight:700;"><?= $fal ?></td>
            <td class="text-center" style="font-weight:800; font-size:1.05rem; color:<?= $pct >= 75 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
              <?= $pct ?>%
            </td>
            <td class="text-center">
              <?php if ($pct >= 75): ?>
                <span class="badge badge-aprovado">Regular</span>
              <?php else: ?>
                <span class="badge badge-reprovado">Excesso de Faltas</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
