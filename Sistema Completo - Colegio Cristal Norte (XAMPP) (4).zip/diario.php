<?php
/**
 * COLÉGIO CRISTAL NORTE - Diário de Classe do Professor
 * Gestão Unificada de Alunos, Frequência, Notas, Atividades e Ocorrências
 * RESTRIÇÃO ESTRITA: Apenas turmas e disciplina vinculadas ao professor logado!
 */
require_once __DIR__ . '/config.php';
requireRole('professor');

$user = currentUser();
$pdo = getDB();

// 1. Obter cadastro do professor logado e sua disciplina
$stmtProf = $pdo->prepare("
    SELECT p.*, d.nome as disciplina_nome 
    FROM professores p 
    JOIN disciplinas d ON d.id = p.disciplina_id 
    WHERE p.usuario_id = ?
");
$stmtProf->execute([$user['id']]);
$prof = $stmtProf->fetch();

if (!$prof) {
    die("Cadastro de professor não encontrado.");
}

$professorId = $prof['id'];
$disciplinaId = $prof['disciplina_id'];

// 2. Obter turmas que este professor leciona na sua disciplina
$stmtTurmas = $pdo->prepare("
    SELECT t.* 
    FROM turmas t
    JOIN professor_turmas pt ON pt.turma_id = t.id
    WHERE pt.professor_id = ? AND pt.disciplina_id = ?
    ORDER BY t.serie ASC, t.nome ASC
");
$stmtTurmas->execute([$professorId, $disciplinaId]);
$turmas = $stmtTurmas->fetchAll();

if (empty($turmas)) {
    $pageTitle = 'Diário de Classe';
    require_once __DIR__ . '/header.php';
    echo "<div class='card text-center'><h2>Nenhuma turma vinculada</h2><p>Você ainda não possui turmas atribuídas para a disciplina {$prof['disciplina_nome']}.</p></div>";
    require_once __DIR__ . '/footer.php';
    exit;
}

// 3. Turma Selecionada com verificação estrita de segurança
$turmaId = isset($_GET['turma_id']) ? intval($_GET['turma_id']) : $turmas[0]['id'];

// Validação no BACKEND: Essa turma REALMENTE pertence a este professor nesta disciplina?
$turmaValida = false;
$turmaAtual = null;
foreach ($turmas as $t) {
    if ((int)$t['id'] === $turmaId) {
        $turmaValida = true;
        $turmaAtual = $t;
        break;
    }
}

if (!$turmaValida) {
    // Violação de segurança: bloqueia imediatamente!
    flash('error', 'Acesso negado: Você não leciona nesta turma ou disciplina.');
    header('Location: diario.php');
    exit;
}

// Ações do Diário via POST (Lançamento de Frequência, Notas ou Atividade)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Ação: Lançar Frequência da Aula
    if ($action === 'salvar_frequencia') {
        $dataAula = $_POST['data_aula'] ?? date('Y-m-d');
        $presencas = $_POST['presente'] ?? []; // Array com IDs dos alunos presentes

        // Obter todos os alunos ativos da turma
        $stmtAlunosTurma = $pdo->prepare("SELECT id FROM alunos WHERE turma_id = ? AND status = 'ativo'");
        $stmtAlunosTurma->execute([$turmaId]);
        $alunosIds = $stmtAlunosTurma->fetchAll(PDO::FETCH_COLUMN);

        $pdo->beginTransaction();
        try {
            foreach ($alunosIds as $aid) {
                $presente = isset($presencas[$aid]) ? 1 : 0;
                $stmtFreq = $pdo->prepare("
                    INSERT INTO frequencias (aluno_id, disciplina_id, professor_id, turma_id, data_aula, presente)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE presente = VALUES(presente), professor_id = VALUES(professor_id)
                ");
                $stmtFreq->execute([$aid, $disciplinaId, $professorId, $turmaId, $dataAula, $presente]);
            }
            $pdo->commit();
            flash('success', 'Frequência da aula de ' . date('d/m/Y', strtotime($dataAula)) . ' registrada com sucesso!');
        } catch (Exception $e) {
            $pdo->rollBack();
            flash('error', 'Erro ao salvar frequência: ' . $e->getMessage());
        }
        header("Location: diario.php?turma_id={$turmaId}&tab=frequencia");
        exit;
    }

    // Ação: Salvar Notas dos Alunos
    if ($action === 'salvar_notas') {
        $notasPost = $_POST['notas'] ?? []; // formato: [aluno_id => ['av1'=>..., 'av2'=>...]]
        
        $pdo->beginTransaction();
        try {
            foreach ($notasPost as $aid => $n) {
                $av1 = ($n['av1'] !== '' && is_numeric($n['av1'])) ? floatval($n['av1']) : null;
                $av2 = ($n['av2'] !== '' && is_numeric($n['av2'])) ? floatval($n['av2']) : null;
                $av3 = ($n['av3'] !== '' && is_numeric($n['av3'])) ? floatval($n['av3']) : null;
                $av4 = ($n['av4'] !== '' && is_numeric($n['av4'])) ? floatval($n['av4']) : null;

                // Calcular média aritmética das avaliações preenchidas
                $notasPreenchidas = array_filter([$av1, $av2, $av3, $av4], fn($v) => $v !== null);
                $media = null;
                $situacao = 'cursando';

                if (count($notasPreenchidas) > 0) {
                    $media = round(array_sum($notasPreenchidas) / count($notasPreenchidas), 2);
                    if (count($notasPreenchidas) === 4) {
                        if ($media >= 6.0) $situacao = 'aprovado';
                        elseif ($media >= 4.0) $situacao = 'recuperacao';
                        else $situacao = 'reprovado';
                    } else {
                        if ($media >= 6.0) $situacao = 'cursando';
                        elseif ($media < 4.0) $situacao = 'recuperacao';
                    }
                }

                $stmtUpsertNota = $pdo->prepare("
                    INSERT INTO notas (aluno_id, disciplina_id, professor_id, turma_id, avaliacao1, avaliacao2, avaliacao3, avaliacao4, media_final, situacao)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        avaliacao1 = VALUES(avaliacao1),
                        avaliacao2 = VALUES(avaliacao2),
                        avaliacao3 = VALUES(avaliacao3),
                        avaliacao4 = VALUES(avaliacao4),
                        media_final = VALUES(media_final),
                        situacao = VALUES(situacao),
                        professor_id = VALUES(professor_id)
                ");
                $stmtUpsertNota->execute([$aid, $disciplinaId, $professorId, $turmaId, $av1, $av2, $av3, $av4, $media, $situacao]);
            }
            $pdo->commit();
            flash('success', 'Notas atualizadas e médias recalculadas com sucesso!');
        } catch (Exception $e) {
            $pdo->rollBack();
            flash('error', 'Erro ao salvar notas: ' . $e->getMessage());
        }
        header("Location: diario.php?turma_id={$turmaId}&tab=notas");
        exit;
    }
}

// 4. Carregar Lista de Alunos da Turma Selecionada
$stmtAlunos = $pdo->prepare("
    SELECT a.*,
        n.avaliacao1, n.avaliacao2, n.avaliacao3, n.avaliacao4, n.media_final, n.situacao,
        (SELECT COUNT(*) FROM frequencias f WHERE f.aluno_id = a.id AND f.disciplina_id = ? AND f.presente = 0) as faltas
    FROM alunos a
    LEFT JOIN notas n ON n.aluno_id = a.id AND n.disciplina_id = ? AND n.turma_id = ?
    WHERE a.turma_id = ? AND a.status = 'ativo'
    ORDER BY a.nome ASC
");
$stmtAlunos->execute([$disciplinaId, $disciplinaId, $turmaId, $turmaId]);
$alunosTurma = $stmtAlunos->fetchAll();

$tab = $_GET['tab'] ?? 'alunos';

$pageTitle = 'Diário de Classe - ' . htmlspecialchars($prof['disciplina_nome']);
require_once __DIR__ . '/header.php';
?>

<!-- Seletor de Turma e Identificação da Disciplina -->
<div class="card" style="border-left: 6px solid var(--primary-orange);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h2 style="margin:0; font-size:1.5rem; color:var(--text-dark);">
        Diário de Classe — <?= htmlspecialchars($prof['disciplina_nome']) ?>
      </h2>
      <p style="color:var(--text-muted); margin:4px 0 0 0;">
        Turma selecionada: <strong><?= htmlspecialchars($turmaAtual['serie']) ?> — <?= htmlspecialchars($turmaAtual['nome']) ?></strong>
      </p>
    </div>

    <!-- Seletor Rápido de Turma (Apenas turmas do professor) -->
    <form method="GET" action="diario.php" style="display:flex; align-items:center; gap:8px;">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
      <label for="selTurma" style="font-weight:600; font-size:0.9rem;">Turma:</label>
      <select name="turma_id" id="selTurma" class="form-control" onchange="this.form.submit()" style="font-weight:600;">
        <?php foreach ($turmas as $t): ?>
          <option value="<?= $t['id'] ?>" <?= (int)$t['id'] === (int)$turmaId ? 'selected' : '' ?>>
            <?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <!-- Navegação por Abas do Diário -->
  <div style="display:flex; gap:10px; margin-top:20px; border-top:1px solid #E7DFD5; padding-top:14px; flex-wrap:wrap;">
    <a href="diario.php?turma_id=<?= $turmaId ?>&tab=alunos" class="btn <?= $tab === 'alunos' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
      👥 Lista de Alunos (<?= count($alunosTurma) ?>)
    </a>
    <a href="diario.php?turma_id=<?= $turmaId ?>&tab=frequencia" class="btn <?= $tab === 'frequencia' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
      📅 Lançar Frequência
    </a>
    <a href="diario.php?turma_id=<?= $turmaId ?>&tab=notas" class="btn <?= $tab === 'notas' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
      📝 Lançar Notas & Boletim
    </a>
    <a href="atividades.php?turma_id=<?= $turmaId ?>" class="btn btn-secondary btn-sm">
      📌 Atividades da Turma
    </a>
    <a href="ocorrencias.php?turma_id=<?= $turmaId ?>&action=nova" class="btn btn-secondary btn-sm">
      ⚠️ Registrar Ocorrência
    </a>
  </div>
</div>

<?php if ($tab === 'alunos'): ?>
  <!-- ABA 1: LISTA DE ALUNOS -->
  <div class="card">
    <div class="card-header">
      <h2>Estudantes da Turma — <?= htmlspecialchars($turmaAtual['nome']) ?></h2>
      <input type="text" class="form-control table-search-input" data-table="tblAlunos" placeholder="🔍 Filtrar aluno por nome..." style="max-width:280px;">
    </div>
    <div class="table-responsive">
      <table class="data-table" id="tblAlunos">
        <thead>
          <tr>
            <th>Matrícula</th>
            <th>Nome do Estudante</th>
            <th class="text-center">Faltas na Disciplina</th>
            <th class="text-center">Média Atual</th>
            <th class="text-center">Situação</th>
            <th class="text-center">Ações Rápidas</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($alunosTurma as $aluno): ?>
            <tr>
              <td><strong><?= htmlspecialchars($aluno['matricula']) ?></strong></td>
              <td><?= htmlspecialchars($aluno['nome']) ?></td>
              <td class="text-center" style="font-weight:700; color:<?= $aluno['faltas'] > 3 ? 'var(--primary-red)' : 'var(--text-dark)' ?>;">
                <?= $aluno['faltas'] ?> falta(s)
              </td>
              <td class="text-center" style="font-weight:700;">
                <?= $aluno['media_final'] !== null ? number_format($aluno['media_final'], 2, ',', '.') : '-' ?>
              </td>
              <td class="text-center">
                <?php
                  $st = $aluno['situacao'] ?? 'cursando';
                  $badge = 'badge-cursando';
                  if ($st === 'aprovado') $badge = 'badge-aprovado';
                  elseif ($st === 'recuperacao') $badge = 'badge-recuperacao';
                  elseif ($st === 'reprovado') $badge = 'badge-reprovado';
                ?>
                <span class="badge <?= $badge ?>"><?= ucfirst($st) ?></span>
              </td>
              <td class="text-center">
                <a href="ocorrencias.php?aluno_id=<?= $aluno['id'] ?>&action=nova" class="btn btn-secondary btn-sm" title="Registrar ocorrência">⚠️ Ocorrência</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

<?php elseif ($tab === 'frequencia'): ?>
  <!-- ABA 2: LANÇAMENTO DE FREQUÊNCIA -->
  <div class="card">
    <div class="card-header">
      <h2>Chamada / Lançamento de Frequência</h2>
      <span class="badge" style="background:#E0F2FE; color:#0369A1;">Disciplina: <?= htmlspecialchars($prof['disciplina_nome']) ?></span>
    </div>

    <form method="POST" action="diario.php?turma_id=<?= $turmaId ?>">
      <input type="hidden" name="action" value="salvar_frequencia">
      
      <div style="background:#FAF6EF; padding:16px; border-radius:8px; margin-bottom:20px; display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
        <div>
          <label for="data_aula" style="font-weight:700; font-size:0.9rem;">Data da Aula:</label>
          <input type="date" name="data_aula" id="data_aula" class="form-control" value="<?= date('Y-m-d') ?>" required style="max-width:200px;">
        </div>
        <div style="font-size:0.85rem; color:#6B7280;">
          Marque a caixa para indicar que o aluno estava <strong>Presente</strong>. Deixe desmarcado para computar <strong>Falta</strong>.
        </div>
      </div>

      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th style="width: 80px;" class="text-center">Presente</th>
              <th>Matrícula</th>
              <th>Nome do Aluno</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($alunosTurma as $aluno): ?>
              <tr>
                <td class="text-center">
                  <input type="checkbox" name="presente[<?= $aluno['id'] ?>]" value="1" checked style="width:20px; height:20px; accent-color:var(--accent-green); cursor:pointer;">
                </td>
                <td><strong><?= htmlspecialchars($aluno['matricula']) ?></strong></td>
                <td><?= htmlspecialchars($aluno['nome']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary" style="padding:12px 28px;">Salvar Frequência da Aula</button>
      </div>
    </form>
  </div>

<?php elseif ($tab === 'notas'): ?>
  <!-- ABA 3: LANÇAMENTO DE NOTAS -->
  <div class="card">
    <div class="card-header">
      <h2>Lançamento de Notas — <?= htmlspecialchars($prof['disciplina_nome']) ?></h2>
      <span class="badge" style="background:#FEF3C7; color:#92400E;">Cálculo Automático de Médias</span>
    </div>

    <form method="POST" action="diario.php?turma_id=<?= $turmaId ?>">
      <input type="hidden" name="action" value="salvar_notas">

      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Estudante</th>
              <th class="text-center" style="width:100px;">1º Bim</th>
              <th class="text-center" style="width:100px;">2º Bim</th>
              <th class="text-center" style="width:100px;">3º Bim</th>
              <th class="text-center" style="width:100px;">4º Bim</th>
              <th class="text-center" style="width:100px;">Média</th>
              <th class="text-center" style="width:120px;">Situação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($alunosTurma as $aluno): ?>
              <tr class="calcula-media-row">
                <td>
                  <strong><?= htmlspecialchars($aluno['nome']) ?></strong>
                  <br><small style="color:var(--text-muted);"><?= htmlspecialchars($aluno['matricula']) ?></small>
                </td>
                <td class="text-center">
                  <input type="number" step="0.1" min="0" max="10" name="notas[<?= $aluno['id'] ?>][av1]" value="<?= $aluno['avaliacao1'] ?? '' ?>" class="form-control nota-input nota-val">
                </td>
                <td class="text-center">
                  <input type="number" step="0.1" min="0" max="10" name="notas[<?= $aluno['id'] ?>][av2]" value="<?= $aluno['avaliacao2'] ?? '' ?>" class="form-control nota-input nota-val">
                </td>
                <td class="text-center">
                  <input type="number" step="0.1" min="0" max="10" name="notas[<?= $aluno['id'] ?>][av3]" value="<?= $aluno['avaliacao3'] ?? '' ?>" class="form-control nota-input nota-val">
                </td>
                <td class="text-center">
                  <input type="number" step="0.1" min="0" max="10" name="notas[<?= $aluno['id'] ?>][av4]" value="<?= $aluno['avaliacao4'] ?? '' ?>" class="form-control nota-input nota-val">
                </td>
                <td class="text-center" style="font-weight:700; font-size:1.05rem;">
                  <span class="media-val"><?= $aluno['media_final'] !== null ? number_format($aluno['media_final'], 2, ',', '.') : '-' ?></span>
                </td>
                <td class="text-center">
                  <?php
                    $st = $aluno['situacao'] ?? 'cursando';
                    $badge = 'badge-cursando';
                    if ($st === 'aprovado') $badge = 'badge-aprovado';
                    elseif ($st === 'recuperacao') $badge = 'badge-recuperacao';
                    elseif ($st === 'reprovado') $badge = 'badge-reprovado';
                  ?>
                  <span class="badge <?= $badge ?> situacao-badge"><?= ucfirst($st) ?></span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div style="margin-top:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap;">
        <span style="font-size:0.85rem; color:var(--text-muted);">
          * Notas de 0.0 a 10.0. Aprovado: média ≥ 6.0 | Recuperação: 4.0 a 5.9 | Reprovado: &lt; 4.0.
        </span>
        <button type="submit" class="btn btn-primary" style="padding:12px 28px;">Salvar Lançamentos de Notas</button>
      </div>
    </form>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
