-- ========================================================
-- BANCO DE DADOS: COLÉGIO CRISTAL NORTE
-- Sistema Escolar Completo e Integrado - Ano Letivo 2026
-- ========================================================

CREATE DATABASE IF NOT EXISTS `cristal_norte` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `cristal_norte`;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `comunicados`;
DROP TABLE IF EXISTS `ocorrencias`;
DROP TABLE IF EXISTS `atividades`;
DROP TABLE IF EXISTS `frequencias`;
DROP TABLE IF EXISTS `notas`;
DROP TABLE IF EXISTS `matriculas`;
DROP TABLE IF EXISTS `alunos_responsaveis`;
DROP TABLE IF EXISTS `alunos`;
DROP TABLE IF EXISTS `professor_turmas`;
DROP TABLE IF EXISTS `professores`;
DROP TABLE IF EXISTS `disciplinas`;
DROP TABLE IF EXISTS `turmas`;
DROP TABLE IF EXISTS `responsaveis`;
DROP TABLE IF EXISTS `coordenadores`;
DROP TABLE IF EXISTS `usuarios`;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. TABELA DE USUÁRIOS (Autenticação Unificada)
CREATE TABLE `usuarios` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(150) NOT NULL,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `senha` VARCHAR(255) NOT NULL,
  `perfil` ENUM('diretor', 'coordenador', 'professor', 'aluno', 'responsavel') NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. TABELA DE TURMAS (Sem opção de turno manhã/tarde/noite conforme regra 29)
CREATE TABLE `turmas` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `serie` VARCHAR(100) NOT NULL,
  `ano_letivo` INT NOT NULL DEFAULT 2026,
  `criada_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. TABELA DE DISCIPLINAS
CREATE TABLE `disciplinas` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `codigo` VARCHAR(20) NOT NULL UNIQUE,
  `descricao` TEXT NULL,
  `criada_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. TABELA DE COORDENADORES
CREATE TABLE `coordenadores` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` INT UNSIGNED NOT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `cpf` VARCHAR(20) NOT NULL UNIQUE,
  `email` VARCHAR(191) NOT NULL,
  `telefone` VARCHAR(25) NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_coord_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. TABELA DE PROFESSORES
CREATE TABLE `professores` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` INT UNSIGNED NOT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `cpf` VARCHAR(20) NOT NULL UNIQUE,
  `email` VARCHAR(191) NOT NULL,
  `telefone` VARCHAR(25) NULL,
  `disciplina_id` INT UNSIGNED NOT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_prof_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prof_disciplina` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. VÍNCULO PROFESSOR - TURMA - DISCIPLINA
CREATE TABLE `professor_turmas` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `professor_id` INT UNSIGNED NOT NULL,
  `turma_id` INT UNSIGNED NOT NULL,
  `disciplina_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prof_turma_disc` (`professor_id`, `turma_id`, `disciplina_id`),
  CONSTRAINT `fk_pt_professor` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pt_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pt_disciplina` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. TABELA DE RESPONSÁVEIS
CREATE TABLE `responsaveis` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` INT UNSIGNED NOT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `cpf` VARCHAR(20) NOT NULL UNIQUE,
  `rg` VARCHAR(20) NULL,
  `parentesco` VARCHAR(50) NOT NULL,
  `telefone` VARCHAR(25) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_resp_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. TABELA DE ALUNOS
CREATE TABLE `alunos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` INT UNSIGNED NOT NULL,
  `matricula` VARCHAR(30) NOT NULL UNIQUE,
  `nome` VARCHAR(150) NOT NULL,
  `data_nascimento` DATE NOT NULL,
  `cpf` VARCHAR(20) NOT NULL UNIQUE,
  `rg` VARCHAR(20) NULL,
  `sexo` ENUM('M', 'F', 'Outro') NOT NULL,
  `cep` VARCHAR(15) NULL,
  `endereco` VARCHAR(150) NULL,
  `numero` VARCHAR(20) NULL,
  `bairro` VARCHAR(80) NULL,
  `cidade` VARCHAR(80) NULL,
  `estado` VARCHAR(5) NULL,
  `telefone` VARCHAR(25) NULL,
  `email` VARCHAR(191) NULL,
  `turma_id` INT UNSIGNED NOT NULL,
  `status` ENUM('ativo', 'trancado', 'concluido') NOT NULL DEFAULT 'ativo',
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_aluno_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_aluno_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. VÍNCULO RESPONSÁVEL - ALUNO (Permite 1 responsável com vários filhos)
CREATE TABLE `alunos_responsaveis` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` INT UNSIGNED NOT NULL,
  `responsavel_id` INT UNSIGNED NOT NULL,
  `parentesco` VARCHAR(50) NOT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_aluno_resp` (`aluno_id`, `responsavel_id`),
  CONSTRAINT `fk_ar_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ar_responsavel` FOREIGN KEY (`responsavel_id`) REFERENCES `responsaveis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. TABELA DE MATRÍCULAS (Histórico Formal)
CREATE TABLE `matriculas` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` INT UNSIGNED NOT NULL,
  `numero_matricula` VARCHAR(30) NOT NULL UNIQUE,
  `ano_letivo` INT NOT NULL DEFAULT 2026,
  `status` ENUM('confirmada', 'pendente', 'cancelada') NOT NULL DEFAULT 'confirmada',
  `data_matricula` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_mat_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. TABELA DE NOTAS
CREATE TABLE `notas` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` INT UNSIGNED NOT NULL,
  `disciplina_id` INT UNSIGNED NOT NULL,
  `professor_id` INT UNSIGNED NOT NULL,
  `turma_id` INT UNSIGNED NOT NULL,
  `avaliacao1` DECIMAL(4,2) NULL DEFAULT NULL,
  `avaliacao2` DECIMAL(4,2) NULL DEFAULT NULL,
  `avaliacao3` DECIMAL(4,2) NULL DEFAULT NULL,
  `avaliacao4` DECIMAL(4,2) NULL DEFAULT NULL,
  `media_final` DECIMAL(4,2) NULL DEFAULT NULL,
  `situacao` ENUM('cursando', 'aprovado', 'recuperacao', 'reprovado') NOT NULL DEFAULT 'cursando',
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_aluno_disc_turma` (`aluno_id`, `disciplina_id`, `turma_id`),
  CONSTRAINT `fk_notas_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notas_disciplina` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_notas_professor` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_notas_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. TABELA DE FREQUÊNCIA
CREATE TABLE `frequencias` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` INT UNSIGNED NOT NULL,
  `disciplina_id` INT UNSIGNED NOT NULL,
  `professor_id` INT UNSIGNED NOT NULL,
  `turma_id` INT UNSIGNED NOT NULL,
  `data_aula` DATE NOT NULL,
  `presente` TINYINT(1) NOT NULL DEFAULT 1, -- 1=Presente, 0=Ausente
  `observacao` VARCHAR(255) NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_freq_aula` (`aluno_id`, `disciplina_id`, `data_aula`),
  CONSTRAINT `fk_freq_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_freq_disciplina` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_freq_professor` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_freq_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. TABELA DE ATIVIDADES
CREATE TABLE `atividades` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `disciplina_id` INT UNSIGNED NOT NULL,
  `professor_id` INT UNSIGNED NOT NULL,
  `turma_id` INT UNSIGNED NOT NULL,
  `titulo` VARCHAR(200) NOT NULL,
  `descricao` TEXT NOT NULL,
  `data_entrega` DATE NOT NULL,
  `status` ENUM('aberta', 'encerrada') NOT NULL DEFAULT 'aberta',
  `criada_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_ativ_disciplina` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ativ_professor` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ativ_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. TABELA DE OCORRÊNCIAS
CREATE TABLE `ocorrencias` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` INT UNSIGNED NOT NULL,
  `autor_id` INT UNSIGNED NOT NULL,
  `data_ocorrencia` DATE NOT NULL,
  `descricao` TEXT NOT NULL,
  `situacao` ENUM('pendente', 'em_analise', 'resolvida') NOT NULL DEFAULT 'pendente',
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_oco_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oco_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. TABELA DE COMUNICADOS
CREATE TABLE `comunicados` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `autor_id` INT UNSIGNED NOT NULL,
  `titulo` VARCHAR(200) NOT NULL,
  `conteudo` TEXT NOT NULL,
  `publico_alvo` ENUM('todos', 'turma', 'professores', 'alunos', 'responsaveis') NOT NULL DEFAULT 'todos',
  `turma_id` INT UNSIGNED NULL DEFAULT NULL,
  `data_publicacao` DATE NOT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_com_autor` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_com_turma` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================================
-- DADOS INICIAIS E CONTAS DE TESTE (Ano Letivo 2026)
-- ========================================================

-- Senhas geradas com password_hash() via BCRYPT ($2y$12$):
-- Diretor:       admin123  -> $2y$12$mFzMino5bpKvSsykvFn0i.L5x/s96M7HdN/lNXmyb0TXqem.8pfti
-- Coordenador:   coord123  -> $2y$12$6lw17vA7ApxMjnu2OGtJCObxSRSyipTLnHx/XeQLKgrf2wlMU4YgS
-- Professor:     prof123   -> $2y$12$4yar7bxa2xbZxstXWTWqE.riJW77IoYLGIvnomnRcwkW.gsJBqq7.
-- Aluno:         aluno123  -> $2y$12$UAHB8we.r0kJD0gSZyrCru1kLqiCEWpXSAMmKgPFalGpTEtZjil2a
-- Responsavel:   resp123   -> $2y$12$/.2/g21zPTfP0MHyIYrfY.Mb8p8.wwQ6..yvigkL95kJDHJBWxRIO

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `perfil`, `ativo`) VALUES
(1, 'Dr. Arnaldo Silveira', 'diretor@cristalnorte.com.br', '$2y$12$mFzMino5bpKvSsykvFn0i.L5x/s96M7HdN/lNXmyb0TXqem.8pfti', 'diretor', 1),
(2, 'Profa. Mariana Vasconcelos', 'coordenador@cristalnorte.com.br', '$2y$12$6lw17vA7ApxMjnu2OGtJCObxSRSyipTLnHx/XeQLKgrf2wlMU4YgS', 'coordenador', 1),
(3, 'Prof. Carlos Eduardo (Geografia)', 'professor.geografia@cristalnorte.com.br', '$2y$12$4yar7bxa2xbZxstXWTWqE.riJW77IoYLGIvnomnRcwkW.gsJBqq7.', 'professor', 1),
(4, 'Prof. Roberto Mendes (Matemática)', 'professor.matematica@cristalnorte.com.br', '$2y$12$4yar7bxa2xbZxstXWTWqE.riJW77IoYLGIvnomnRcwkW.gsJBqq7.', 'professor', 1),
(5, 'Lucas Albuquerque Souza', 'aluno@cristalnorte.com.br', '$2y$12$UAHB8we.r0kJD0gSZyrCru1kLqiCEWpXSAMmKgPFalGpTEtZjil2a', 'aluno', 1),
(6, 'Patrícia Albuquerque Souza', 'responsavel@cristalnorte.com.br', '$2y$12$/.2/g21zPTfP0MHyIYrfY.Mb8p8.wwQ6..yvigkL95kJDHJBWxRIO', 'responsavel', 1),
(7, 'Beatriz Albuquerque Souza', 'beatriz.aluno@cristalnorte.com.br', '$2y$12$UAHB8we.r0kJD0gSZyrCru1kLqiCEWpXSAMmKgPFalGpTEtZjil2a', 'aluno', 1);

-- Inserir Coordenador
INSERT INTO `coordenadores` (`id`, `usuario_id`, `nome`, `cpf`, `email`, `telefone`) VALUES
(1, 2, 'Profa. Mariana Vasconcelos', '111.222.333-44', 'coordenador@cristalnorte.com.br', '(11) 98765-4321');

-- Inserir Disciplinas
INSERT INTO `disciplinas` (`id`, `nome`, `codigo`, `descricao`) VALUES
(1, 'Geografia', 'GEO-01', 'Estudo geográfico, geopolítica e meio ambiente'),
(2, 'Matemática', 'MAT-01', 'Álgebra, geometria, trigonometria e funções'),
(3, 'Língua Portuguesa', 'PORT-01', 'Gramática, literatura e redação'),
(4, 'Biologia', 'BIO-01', 'Genética, ecologia e citologia'),
(5, 'História', 'HIST-01', 'História geral e do Brasil');

-- Inserir Professores vinculados a disciplinas exclusivas
INSERT INTO `professores` (`id`, `usuario_id`, `nome`, `cpf`, `email`, `telefone`, `disciplina_id`) VALUES
(1, 3, 'Prof. Carlos Eduardo', '222.333.444-55', 'professor.geografia@cristalnorte.com.br', '(11) 97654-3210', 1),
(2, 4, 'Prof. Roberto Mendes', '333.444.555-66', 'professor.matematica@cristalnorte.com.br', '(11) 96543-2109', 2);

-- Inserir Turmas (Sem opções de manhã/tarde/noite)
INSERT INTO `turmas` (`id`, `nome`, `serie`, `ano_letivo`) VALUES
(1, 'Turma 1º Ano A', '1º Ano do Ensino Médio', 2026),
(2, 'Turma 2º Ano A', '2º Ano do Ensino Médio', 2026),
(3, 'Turma 2º Ano B', '2º Ano do Ensino Médio', 2026),
(4, 'Turma 3º Ano A', '3º Ano do Ensino Médio', 2026);

-- Vínculo de Turmas para Professores:
-- Carlos Eduardo (Geografia): 2º Ano A (id:2) e 2º Ano B (id:3)
INSERT INTO `professor_turmas` (`professor_id`, `turma_id`, `disciplina_id`) VALUES
(1, 2, 1),
(1, 3, 1),
-- Roberto Mendes (Matemática): 1º Ano A (id:1) e 2º Ano A (id:2)
(2, 1, 2),
(2, 2, 2);

-- Inserir Responsável (Patrícia tem 2 filhos para demonstrar o seletor)
INSERT INTO `responsaveis` (`id`, `usuario_id`, `nome`, `cpf`, `rg`, `parentesco`, `telefone`, `email`) VALUES
(1, 6, 'Patrícia Albuquerque Souza', '444.555.666-77', '12.345.678-9', 'Mãe', '(11) 95432-1098', 'responsavel@cristalnorte.com.br');

-- Inserir Alunos (Idade entre 6 e 17 anos: Lucas tem 16 anos, Beatriz tem 14 anos)
INSERT INTO `alunos` (`id`, `usuario_id`, `matricula`, `nome`, `data_nascimento`, `cpf`, `rg`, `sexo`, `cep`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `telefone`, `email`, `turma_id`, `status`) VALUES
(1, 5, 'MAT-2026-10024', 'Lucas Albuquerque Souza', '2010-04-12', '555.666.777-88', '34.567.890-1', 'M', '01310-100', 'Avenida Paulista', '1500', 'Bela Vista', 'São Paulo', 'SP', '(11) 94321-0987', 'aluno@cristalnorte.com.br', 2, 'ativo'),
(2, 7, 'MAT-2026-10025', 'Beatriz Albuquerque Souza', '2012-08-20', '666.777.888-99', '45.678.901-2', 'F', '01310-100', 'Avenida Paulista', '1500', 'Bela Vista', 'São Paulo', 'SP', '(11) 94321-0988', 'beatriz.aluno@cristalnorte.com.br', 1, 'ativo');

-- Vínculo Aluno - Responsável
INSERT INTO `alunos_responsaveis` (`aluno_id`, `responsavel_id`, `parentesco`) VALUES
(1, 1, 'Mãe'),
(2, 1, 'Mãe');

-- Matrículas Formais
INSERT INTO `matriculas` (`aluno_id`, `numero_matricula`, `ano_letivo`, `status`, `data_matricula`) VALUES
(1, 'MAT-2026-10024', 2026, 'confirmada', '2026-01-15 10:30:00'),
(2, 'MAT-2026-10025', 2026, 'confirmada', '2026-01-15 10:45:00');

-- Notas do Lucas (2º Ano A)
-- Geografia (Prof. Carlos Eduardo):
INSERT INTO `notas` (`aluno_id`, `disciplina_id`, `professor_id`, `turma_id`, `avaliacao1`, `avaliacao2`, `avaliacao3`, `avaliacao4`, `media_final`, `situacao`) VALUES
(1, 1, 1, 2, 8.50, 9.00, 7.50, 8.00, 8.25, 'aprovado'),
(1, 2, 2, 2, 7.00, 6.50, 8.00, 7.50, 7.25, 'aprovado');

-- Frequência do Lucas (Geografia)
INSERT INTO `frequencias` (`aluno_id`, `disciplina_id`, `professor_id`, `turma_id`, `data_aula`, `presente`, `observacao`) VALUES
(1, 1, 1, 2, '2026-03-02', 1, 'Participativo na aula'),
(1, 1, 1, 2, '2026-03-09', 1, 'Presente'),
(1, 1, 1, 2, '2026-03-16', 0, 'Falta justificada por consulta médica'),
(1, 1, 1, 2, '2026-03-23', 1, 'Presente');

-- Atividades
INSERT INTO `atividades` (`id`, `disciplina_id`, `professor_id`, `turma_id`, `titulo`, `descricao`, `data_entrega`, `status`) VALUES
(1, 1, 1, 2, 'Seminário de Geopolítica Contemporânea', 'Apresentação em grupo de 15 minutos sobre os blocos econômicos globais.', '2026-04-15', 'aberta'),
(2, 1, 1, 2, 'Relatório de Impacto Ambiental Urbano', 'Elaboração de síntese analítica sobre impermeabilização do solo em grandes metrópoles.', '2026-03-20', 'encerrada'),
(3, 2, 2, 2, 'Lista de Exercícios: Trigonometria', 'Resolver os exercícios 1 a 20 da apostila páginas 42-45.', '2026-04-10', 'aberta');

-- Ocorrências
INSERT INTO `ocorrencias` (`id`, `aluno_id`, `autor_id`, `data_ocorrencia`, `descricao`, `situacao`) VALUES
(1, 1, 3, '2026-03-16', 'Aluno esqueceu material didático durante aula de campo.', 'resolvida');

-- Comunicados
INSERT INTO `comunicados` (`id`, `autor_id`, `titulo`, `conteudo`, `publico_alvo`, `turma_id`, `data_publicacao`) VALUES
(1, 1, 'Boas-Vindas ao Ano Letivo 2026', 'A direção do Colégio Cristal Norte dá as boas-vindas a todos os alunos, responsáveis e professores. Desejamos um ano de muitas conquistas acadêmicas.', 'todos', NULL, '2026-02-01'),
(2, 2, 'Reunião de Pais e Mestres do 2º Bimestre', 'Convidamos todos os responsáveis para a reunião pedagógica a ser realizada no auditório principal às 19h.', 'responsaveis', NULL, '2026-04-05'),
(3, 3, 'Orientações para o Simulado de Geografia', 'Caros alunos do 2º Ano, revisem os capítulos 3 e 4 sobre demografia e urbanização.', 'turma', 2, '2026-03-25');
