<?php
/**
 * COLÉGIO CRISTAL NORTE - Painel Administrativo do Diretor
 * Visão Geral Completa de Alunos, Professores, Turmas, Disciplinas e Matrículas
 */
require_once __DIR__ . '/config.php';
requireRole('diretor');

$user = currentUser();
$pdo = getDB();

// 1. Estatísticas Gerais do Sistema
$totAlunos = (int)$pdo->query("SELECT COUNT(*) FROM alunos WHERE status = 'ativo'")->fetchColumn();
$totProfessores = (int)$pdo->query("SELECT COUNT(*) FROM professores")->fetchColumn();
$totResponsaveis = (int)$pdo->query("SELECT COUNT(*) FROM responsaveis")->fetchColumn();
$totTurmas = (int)$pdo->query("SELECT COUNT(*) FROM turmas WHERE ano_letivo = 2026")->fetchColumn();
$totDisciplinas = (int)$pdo->query("SELECT COUNT(*) FROM disciplinas")->fetchColumn();
$totMatriculas = (int)$pdo->query("SELECT COUNT(*) FROM matriculas WHERE ano_letivo = 2026")->fetchColumn();

// 2. Últimas Matrículas Realizadas
$stmtUltMat = $pdo->query("
    SELECT m.*, a.nome as aluno_nome, a.matricula, t.nome as turma_nome, t.serie as turma_serie
    FROM matriculas m
    JOIN alunos a ON a.id = m.aluno_id
    JOIN turmas t ON t.id = a.turma_id
    ORDER BY m.data_matricula DESC
    LIMIT 6
");
$ultimasMatriculas = $stmtUltMat->fetchAll();

// 3. Resumo por Turma
$stmtTurmas = $pdo->query("
    SELECT 
        t.id, 
        t.nome, 
        t.serie, 
        (SELECT COUNT(*) FROM alunos a WHERE a.turma_id = t.id AND a.status = 'ativo') as qtd_alunos
    FROM turmas t
    WHERE t.ano_letivo = 2026
    ORDER BY t.serie ASC, t.nome ASC
");
$resumoTurmas = $stmtTurmas->fetchAll();

$pageTitle = 'Direção Geral - Painel Administrativo';
require_once __DIR__ . '/header.php';
?>

<!-- Boas-vindas da Direção Geral -->
<div class="card" style="border-left: 6px solid var(--primary-red);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h2 style="margin:0; font-size:1.6rem; color:var(--text-dark);">
        Direção Geral — Colégio Cristal Norte
      </h2>
      <p style="color:var(--text-muted); margin:4px 0 0 0;">
        Controle pedagógico, administrativo e gerencial unificado — Ano Letivo 2026.
      </p>
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
      <a href="matricula.php" class="btn btn-primary">➕ Nova Matrícula</a>
      <a href="alunos.php" class="btn btn-secondary">👨‍🎓 Alunos</a>
      <a href="professores.php" class="btn btn-secondary">👨‍🏫 Professores</a>
      <a href="turmas.php" class="btn btn-secondary">🏫 Turmas</a>
      <a href="disciplinas.php" class="btn btn-secondary">📚 Disciplinas</a>
    </div>
  </div>
</div>

<!-- KPIs da Escola -->
<div class="kpi-grid">
  <div class="kpi-card">
    <span class="kpi-title">Alunos Ativos</span>
    <span class="kpi-value" style="color:var(--accent-blue);"><?= $totAlunos ?></span>
    <span class="kpi-sub"><a href="alunos.php">Gerenciar estudantes</a></span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Professores</span>
    <span class="kpi-value" style="color:var(--primary-orange);"><?= $totProfessores ?></span>
    <span class="kpi-sub"><a href="professores.php">Gerenciar docentes</a></span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Responsáveis</span>
    <span class="kpi-value" style="color:var(--accent-green);"><?= $totResponsaveis ?></span>
    <span class="kpi-sub">Famílias cadastradas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Turmas Ativas</span>
    <span class="kpi-value" style="color:var(--primary-red);"><?= $totTurmas ?></span>
    <span class="kpi-sub"><a href="turmas.php">Gerenciar turmas</a></span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Disciplinas</span>
    <span class="kpi-value" style="color:var(--accent-yellow);"><?= $totDisciplinas ?></span>
    <span class="kpi-sub"><a href="disciplinas.php">Matriz curricular</a></span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Matrículas 2026</span>
    <span class="kpi-value" style="color:var(--accent-green);"><?= $totMatriculas ?></span>
    <span class="kpi-sub">Registros confirmados</span>
  </div>
</div>

<!-- Atalhos Rápidos de Gestão Administrativa -->
<div class="card">
  <div class="card-header">
    <h2>Módulos de Gestão Administrativa</h2>
  </div>
  <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:14px;">
    <a href="alunos.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">👨‍🎓</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Alunos</strong>
        <small style="color:var(--text-muted);">Cadastro, busca e ficha</small>
      </div>
    </a>
    <a href="professores.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">👨‍🏫</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Professores</strong>
        <small style="color:var(--text-muted);">Disciplinas e turmas</small>
      </div>
    </a>
    <a href="turmas.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">🏫</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Turmas</strong>
        <small style="color:var(--text-muted);">Séries e enturmação</small>
      </div>
    </a>
    <a href="disciplinas.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">📚</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Disciplinas</strong>
        <small style="color:var(--text-muted);">Carga horária e matriz</small>
      </div>
    </a>
    <a href="comunicados.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">📢</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Comunicados</strong>
        <small style="color:var(--text-muted);">Mural e notificações</small>
      </div>
    </a>
    <a href="ocorrencias.php" class="btn btn-secondary" style="justify-content:flex-start; padding:14px;">
      <span style="font-size:1.3rem;">⚠️</span>
      <div style="text-align:left;">
        <strong style="display:block; color:var(--text-dark);">Ocorrências</strong>
        <small style="color:var(--text-muted);">Disciplina e mediação</small>
      </div>
    </a>
  </div>
</div>

<div class="form-grid-2">
  <!-- Últimas Matrículas Emitidas -->
  <div class="card">
    <div class="card-header">
      <h2>Últimas Matrículas (Ano Letivo 2026)</h2>
      <a href="matricula.php" class="btn btn-primary btn-sm">Nova Matrícula</a>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Matrícula</th>
            <th>Estudante</th>
            <th>Série / Turma</th>
            <th>Data</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($ultimasMatriculas as $um): ?>
            <tr>
              <td><strong style="color:var(--primary-orange);"><?= htmlspecialchars($um['numero_matricula']) ?></strong></td>
              <td><?= htmlspecialchars($um['aluno_nome']) ?></td>
              <td><?= htmlspecialchars($um['turma_serie']) ?> (<?= htmlspecialchars($um['turma_nome']) ?>)</td>
              <td><?= date('d/m/Y', strtotime($um['data_matricula'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Ocupação por Turma -->
  <div class="card">
    <div class="card-header">
      <h2>Ocupação das Turmas (2026)</h2>
      <a href="turmas.php" class="btn btn-secondary btn-sm">Ver Detalhes</a>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Turma</th>
            <th>Série</th>
            <th class="text-center">Alunos Ativos</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($resumoTurmas as $rt): ?>
            <tr>
              <td><strong><?= htmlspecialchars($rt['nome']) ?></strong></td>
              <td><?= htmlspecialchars($rt['serie']) ?></td>
              <td class="text-center">
                <span class="badge badge-aprovado"><?= $rt['qtd_alunos'] ?> alunos</span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
