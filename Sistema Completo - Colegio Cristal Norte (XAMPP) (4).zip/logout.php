<?php
/**
 * COLÉGIO CRISTAL NORTE - Logout do Sistema
 */
require_once __DIR__ . '/config.php';

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

session_start();
flash('info', 'Você encerrou sua sessão com segurança. Até breve!');
header('Location: login.php');
exit;
