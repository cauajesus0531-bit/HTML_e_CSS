<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão Administrativa de Alunos
 * Visualização completa de perfil, dados de responsáveis, turmas e filtros
 */
require_once __DIR__ . '/config.php';
requireRole(['diretor', 'coordenador']);

$pdo = getDB();

$busca = trim($_GET['busca'] ?? '');
$turmaFiltro = intval($_GET['turma_id'] ?? 0);
$statusFiltro = trim($_GET['status'] ?? '');

$turmas = $pdo->query("SELECT id, nome, serie FROM turmas WHERE ano_letivo = 2026 ORDER BY serie, nome")->fetchAll();

// Montar query de listagem com filtros
$sql = "
    SELECT 
        a.*, 
        t.nome as turma_nome, 
        t.serie as turma_serie,
        r.nome as resp_nome,
        r.email as resp_email,
        r.telefone as resp_telefone,
        r.parentesco as resp_parentesco
    FROM alunos a
    JOIN turmas t ON t.id = a.turma_id
    LEFT JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
    LEFT JOIN responsaveis r ON r.id = ar.responsavel_id
    WHERE 1=1
";
$params = [];

if (!empty($busca)) {
    $sql .= " AND (a.nome LIKE ? OR a.matricula LIKE ? OR a.cpf LIKE ?)";
    $params[] = "%{$busca}%";
    $params[] = "%{$busca}%";
    $params[] = "%{$busca}%";
}

if ($turmaFiltro > 0) {
    $sql .= " AND a.turma_id = ?";
    $params[] = $turmaFiltro;
}

if (!empty($statusFiltro)) {
    $sql .= " AND a.status = ?";
    $params[] = $statusFiltro;
}

$sql .= " ORDER BY a.nome ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$alunos = $stmt->fetchAll();

// Visualização de Perfil Completo de Aluno Selecionado
$verAlunoId = intval($_GET['ver_id'] ?? 0);
$alunoDetalhes = null;
if ($verAlunoId > 0) {
    $stmtDet = $pdo->prepare("
        SELECT 
            a.*, 
            t.nome as turma_nome, 
            t.serie as turma_serie,
            r.nome as resp_nome, 
            r.cpf as resp_cpf,
            r.rg as resp_rg,
            r.telefone as resp_telefone, 
            r.email as resp_email, 
            ar.parentesco
        FROM alunos a
        JOIN turmas t ON t.id = a.turma_id
        LEFT JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
        LEFT JOIN responsaveis r ON r.id = ar.responsavel_id
        WHERE a.id = ?
        LIMIT 1
    ");
    $stmtDet->execute([$verAlunoId]);
    $alunoDetalhes = $stmtDet->fetch();
}

$pageTitle = 'Administração de Alunos';
require_once __DIR__ . '/header.php';
?>

<!-- MODAL / CARD DE VISUALIZAÇÃO COMPLETA DE PERFIL -->
<?php if ($alunoDetalhes): ?>
  <div class="card" style="border: 2px solid var(--primary-orange); background: #FFFDF9;">
    <div class="card-header">
      <h2 style="color:var(--primary-red);">Ficha Completa do Aluno — <?= htmlspecialchars($alunoDetalhes['nome']) ?></h2>
      <a href="alunos.php" class="btn btn-secondary btn-sm">Fechar Detalhes</a>
    </div>

    <div class="form-grid-2">
      <div>
        <h4 style="color:var(--primary-orange); margin-bottom:10px;">📋 Dados Pessoais & Escolares</h4>
        <p><strong>Nome:</strong> <?= htmlspecialchars($alunoDetalhes['nome']) ?></p>
        <p><strong>Número de Matrícula:</strong> <strong style="color:var(--primary-orange);"><?= htmlspecialchars($alunoDetalhes['matricula']) ?></strong></p>
        <p><strong>Data de Nascimento:</strong> <?= date('d/m/Y', strtotime($alunoDetalhes['data_nascimento'])) ?> (<?= calcularIdade($alunoDetalhes['data_nascimento']) ?> anos)</p>
        <p><strong>CPF:</strong> <?= htmlspecialchars($alunoDetalhes['cpf']) ?> | <strong>RG:</strong> <?= htmlspecialchars($alunoDetalhes['rg'] ?? '-') ?></p>
        <p><strong>Sexo:</strong> <?= htmlspecialchars($alunoDetalhes['sexo']) ?></p>
        <p><strong>Turma / Série:</strong> <?= htmlspecialchars($alunoDetalhes['turma_serie']) ?> — <?= htmlspecialchars($alunoDetalhes['turma_nome']) ?></p>
        <p><strong>Status:</strong> <span class="badge badge-aprovado"><?= ucfirst($alunoDetalhes['status']) ?></span></p>
      </div>

      <div>
        <h4 style="color:var(--primary-red); margin-bottom:10px;">👨‍👩‍👧 Responsável Legal</h4>
        <p><strong>Nome do Responsável:</strong> <?= htmlspecialchars($alunoDetalhes['resp_nome'] ?? 'Não informado') ?></p>
        <p><strong>Parentesco:</strong> <?= htmlspecialchars($alunoDetalhes['parentesco'] ?? '-') ?></p>
        <p><strong>CPF do Responsável:</strong> <?= htmlspecialchars($alunoDetalhes['resp_cpf'] ?? '-') ?></p>
        <p><strong>Telefone:</strong> <?= htmlspecialchars($alunoDetalhes['resp_telefone'] ?? '-') ?></p>
        <p><strong>E-mail de Acesso:</strong> <?= htmlspecialchars($alunoDetalhes['resp_email'] ?? '-') ?></p>
      </div>

      <div class="col-span-2" style="border-top:1px solid #E5E7EB; padding-top:12px; margin-top:10px;">
        <h4 style="color:var(--text-dark); margin-bottom:8px;">📍 Endereço Residencial</h4>
        <p>
          <?= htmlspecialchars($alunoDetalhes['endereco']) ?>, Nº <?= htmlspecialchars($alunoDetalhes['numero']) ?> - 
          <?= htmlspecialchars($alunoDetalhes['bairro']) ?>, <?= htmlspecialchars($alunoDetalhes['cidade']) ?>/<?= htmlspecialchars($alunoDetalhes['estado']) ?> - 
          CEP: <?= htmlspecialchars($alunoDetalhes['cep']) ?>
        </p>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- FILTROS E PESQUISA DE ALUNOS -->
<div class="card">
  <div class="card-header">
    <h2>Quadro Geral de Estudantes (<?= count($alunos) ?>)</h2>
    <a href="matricula.php" class="btn btn-primary btn-sm">➕ Nova Matrícula</a>
  </div>

  <form method="GET" action="alunos.php" style="background:#FAF6EF; padding:16px; border-radius:8px; margin-bottom:20px;">
    <div class="form-grid-3">
      <div class="form-group">
        <label for="busca">Pesquisar por Nome, Matrícula ou CPF:</label>
        <input type="text" name="busca" id="busca" class="form-control" placeholder="Digite para buscar..." value="<?= htmlspecialchars($busca) ?>">
      </div>

      <div class="form-group">
        <label for="turma_id">Filtrar por Turma:</label>
        <select name="turma_id" id="turma_id" class="form-control">
          <option value="">Todas as Turmas</option>
          <?php foreach ($turmas as $t): ?>
            <option value="<?= $t['id'] ?>" <?= $t['id'] == $turmaFiltro ? 'selected' : '' ?>>
              <?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="status">Status da Matrícula:</label>
        <select name="status" id="status" class="form-control">
          <option value="">Todos os Status</option>
          <option value="ativo" <?= $statusFiltro === 'ativo' ? 'selected' : '' ?>>Ativo</option>
          <option value="trancado" <?= $statusFiltro === 'trancado' ? 'selected' : '' ?>>Trancado</option>
          <option value="concluido" <?= $statusFiltro === 'concluido' ? 'selected' : '' ?>>Concluído</option>
        </select>
      </div>
    </div>

    <div style="text-align:right; margin-top:10px;">
      <a href="alunos.php" class="btn btn-secondary btn-sm">Limpar Filtros</a>
      <button type="submit" class="btn btn-primary btn-sm">Aplicar Filtros</button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Matrícula</th>
          <th>Nome Completo</th>
          <th>Idade / Nascimento</th>
          <th>Série / Turma</th>
          <th>Responsável Legal</th>
          <th>Contato Responsável</th>
          <th class="text-center">Status</th>
          <th class="text-center">Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($alunos)): ?>
          <tr><td colspan="8" class="text-center" style="padding:20px; color:var(--text-muted);">Nenhum aluno encontrado com os filtros selecionados.</td></tr>
        <?php else: ?>
          <?php foreach ($alunos as $a): ?>
            <tr>
              <td><strong style="color:var(--primary-orange);"><?= htmlspecialchars($a['matricula']) ?></strong></td>
              <td><strong><?= htmlspecialchars($a['nome']) ?></strong></td>
              <td><?= date('d/m/Y', strtotime($a['data_nascimento'])) ?> (<?= calcularIdade($a['data_nascimento']) ?> anos)</td>
              <td><?= htmlspecialchars($a['turma_serie']) ?> (<?= htmlspecialchars($a['turma_nome']) ?>)</td>
              <td><?= htmlspecialchars($a['resp_nome'] ?? '-') ?></td>
              <td><?= htmlspecialchars($a['resp_telefone'] ?? $a['resp_email'] ?? '-') ?></td>
              <td class="text-center">
                <span class="badge badge-<?= $a['status'] === 'ativo' ? 'aprovado' : 'recuperacao' ?>">
                  <?= ucfirst($a['status']) ?>
                </span>
              </td>
              <td class="text-center">
                <a href="alunos.php?ver_id=<?= $a['id'] ?>" class="btn btn-secondary btn-sm" title="Ver ficha completa">👁️ Ver Perfil</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
