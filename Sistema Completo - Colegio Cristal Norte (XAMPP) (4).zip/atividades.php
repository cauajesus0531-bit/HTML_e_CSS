<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão e Visualização de Atividades
 * Professores: cadastram e gerenciam atividades de sua disciplina e turmas
 * Alunos e Responsáveis: visualizam atividades e prazos
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

$action = $_GET['action'] ?? 'listar';

// ==========================================
// AÇÃO: CRIAR NOVA ATIVIDADE (Apenas Professores)
// ==========================================
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('professor');

    // Obter professor e sua disciplina
    $stmtProf = $pdo->prepare("SELECT id, disciplina_id FROM professores WHERE usuario_id = ?");
    $stmtProf->execute([$user['id']]);
    $prof = $stmtProf->fetch();

    $professorId = $prof['id'];
    $disciplinaId = $prof['disciplina_id'];

    $turmaId = intval($_POST['turma_id'] ?? 0);
    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $dataEntrega = trim($_POST['data_entrega'] ?? '');

    // Validação de segurança: a turma informada pertence a este professor?
    $stmtCheckTurma = $pdo->prepare("
        SELECT COUNT(*) FROM professor_turmas 
        WHERE professor_id = ? AND turma_id = ? AND disciplina_id = ?
    ");
    $stmtCheckTurma->execute([$professorId, $turmaId, $disciplinaId]);
    if ($stmtCheckTurma->fetchColumn() == 0) {
        flash('error', 'Acesso negado: Você não pode criar atividades para turmas ou disciplinas que não leciona.');
        header('Location: atividades.php');
        exit;
    }

    if (empty($titulo) || empty($descricao) || empty($dataEntrega)) {
        flash('error', 'Por favor, preencha todos os campos da atividade.');
    } else {
        $stmtIns = $pdo->prepare("
            INSERT INTO atividades (disciplina_id, professor_id, turma_id, titulo, descricao, data_entrega, status)
            VALUES (?, ?, ?, ?, ?, ?, 'aberta')
        ");
        $stmtIns->execute([$disciplinaId, $professorId, $turmaId, $titulo, $descricao, $dataEntrega]);
        flash('success', 'Atividade pedagógica criada e publicada para os alunos!');
        header('Location: atividades.php');
        exit;
    }
}

// Alterar Status (Apenas Professor proprietário)
if ($action === 'toggle_status') {
    requireRole('professor');
    $id = intval($_GET['id'] ?? 0);
    
    $stmtProf = $pdo->prepare("SELECT id FROM professores WHERE usuario_id = ?");
    $stmtProf->execute([$user['id']]);
    $profId = $stmtProf->fetchColumn();

    $stmtCheck = $pdo->prepare("SELECT status FROM atividades WHERE id = ? AND professor_id = ?");
    $stmtCheck->execute([$id, $profId]);
    $statusAtual = $stmtCheck->fetchColumn();

    if ($statusAtual) {
        $novoStatus = $statusAtual === 'aberta' ? 'encerrada' : 'aberta';
        $stmtUp = $pdo->prepare("UPDATE atividades SET status = ? WHERE id = ?");
        $stmtUp->execute([$novoStatus, $id]);
        flash('success', "Status da atividade alterado para {$novoStatus}.");
    }
    header('Location: atividades.php');
    exit;
}

$pageTitle = 'Atividades e Tarefas Pedagógicas';
require_once __DIR__ . '/header.php';
?>

<!-- FORMULÁRIO DE NOVA ATIVIDADE (Para Professores) -->
<?php if ($action === 'nova' && hasRole('professor')): ?>
  <?php
    $stmtProf = $pdo->prepare("SELECT id, disciplina_id FROM professores WHERE usuario_id = ?");
    $stmtProf->execute([$user['id']]);
    $prof = $stmtProf->fetch();

    $stmtTurmas = $pdo->prepare("
        SELECT t.id, t.nome, t.serie 
        FROM turmas t
        JOIN professor_turmas pt ON pt.turma_id = t.id
        WHERE pt.professor_id = ? AND pt.disciplina_id = ?
        ORDER BY t.serie, t.nome
    ");
    $stmtTurmas->execute([$prof['id'], $prof['disciplina_id']]);
    $turmasProf = $stmtTurmas->fetchAll();
  ?>
  <div class="card">
    <div class="card-header">
      <h2>Cadastrar Nova Atividade / Trabalho</h2>
      <a href="atividades.php" class="btn btn-secondary btn-sm">Voltar à Lista</a>
    </div>

    <form method="POST" action="atividades.php?action=salvar">
      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="titulo">Título da Atividade *</label>
          <input type="text" name="titulo" id="titulo" class="form-control" required placeholder="Ex: Trabalho de Pesquisa - Capítulo 4">
        </div>

        <div class="form-group">
          <label for="turma_id">Turma Destinatária *</label>
          <select name="turma_id" id="turma_id" class="form-control" required>
            <option value="">Selecione uma de suas turmas...</option>
            <?php foreach ($turmasProf as $t): ?>
              <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="data_entrega">Data Limite de Entrega *</label>
          <input type="date" name="data_entrega" id="data_entrega" class="form-control" required value="<?= date('Y-m-d', strtotime('+7 days')) ?>">
        </div>

        <div class="form-group col-span-2">
          <label for="descricao">Descrição / Orientações *</label>
          <textarea name="descricao" id="descricao" class="form-control" rows="5" required placeholder="Descreva os objetivos, referências e formato de entrega da atividade..."></textarea>
        </div>
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary" style="padding:12px 28px;">Publicar Atividade para os Alunos</button>
      </div>
    </form>
  </div>
<?php endif; ?>

<!-- LISTAGEM DE ATIVIDADES CONFORME O PERFIL -->
<?php
// Carregar atividades de acordo com o papel
if ($user['perfil'] === 'professor') {
    $stmtProf = $pdo->prepare("SELECT id, disciplina_id FROM professores WHERE usuario_id = ?");
    $stmtProf->execute([$user['id']]);
    $prof = $stmtProf->fetch();

    $stmtAtiv = $pdo->prepare("
        SELECT a.*, d.nome as disciplina_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM atividades a
        JOIN disciplinas d ON d.id = a.disciplina_id
        JOIN turmas t ON t.id = a.turma_id
        WHERE a.professor_id = ? AND a.disciplina_id = ?
        ORDER BY a.data_entrega DESC
    ");
    $stmtAtiv->execute([$prof['id'], $prof['disciplina_id']]);
} elseif ($user['perfil'] === 'aluno') {
    $stmtAluno = $pdo->prepare("SELECT turma_id FROM alunos WHERE usuario_id = ?");
    $stmtAluno->execute([$user['id']]);
    $turmaId = $stmtAluno->fetchColumn();

    $stmtAtiv = $pdo->prepare("
        SELECT a.*, d.nome as disciplina_nome, p.nome as professor_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM atividades a
        JOIN disciplinas d ON d.id = a.disciplina_id
        JOIN professores p ON p.id = a.professor_id
        JOIN turmas t ON t.id = a.turma_id
        WHERE a.turma_id = ?
        ORDER BY a.data_entrega ASC
    ");
    $stmtAtiv->execute([$turmaId]);
} elseif ($user['perfil'] === 'responsavel') {
    $stmtResp = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
    $stmtResp->execute([$user['id']]);
    $respId = $stmtResp->fetchColumn();

    $stmtAtiv = $pdo->prepare("
        SELECT DISTINCT a.*, d.nome as disciplina_nome, p.nome as professor_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM atividades a
        JOIN disciplinas d ON d.id = a.disciplina_id
        JOIN professores p ON p.id = a.professor_id
        JOIN turmas t ON t.id = a.turma_id
        JOIN alunos al ON al.turma_id = t.id
        JOIN alunos_responsaveis ar ON ar.aluno_id = al.id
        WHERE ar.responsavel_id = ?
        ORDER BY a.data_entrega ASC
    ");
    $stmtAtiv->execute([$respId]);
} else {
    // Coordenador / Diretor
    $stmtAtiv = $pdo->query("
        SELECT a.*, d.nome as disciplina_nome, p.nome as professor_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM atividades a
        JOIN disciplinas d ON d.id = a.disciplina_id
        JOIN professores p ON p.id = a.professor_id
        JOIN turmas t ON t.id = a.turma_id
        ORDER BY a.data_entrega DESC
    ");
}
$atividades = $stmtAtiv->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <h2>Mural de Atividades e Tarefas</h2>
    <?php if (hasRole('professor')): ?>
      <a href="atividades.php?action=nova" class="btn btn-primary btn-sm">➕ Criar Nova Atividade</a>
    <?php endif; ?>
  </div>

  <?php if (empty($atividades)): ?>
    <p style="color:var(--text-muted); font-style:italic;">Nenhuma atividade cadastrada no momento.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Título da Atividade</th>
            <th>Disciplina</th>
            <th>Turma</th>
            <th>Data de Entrega</th>
            <th class="text-center">Status</th>
            <?php if (hasRole('professor')): ?>
              <th class="text-center">Ações</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($atividades as $ativ): ?>
            <tr>
              <td>
                <strong><?= htmlspecialchars($ativ['titulo']) ?></strong>
                <p style="font-size:0.85rem; color:#4B5563; margin:4px 0 0 0;"><?= htmlspecialchars($ativ['descricao']) ?></p>
              </td>
              <td><?= htmlspecialchars($ativ['disciplina_nome']) ?></td>
              <td><?= htmlspecialchars($ativ['turma_serie']) ?> — <?= htmlspecialchars($ativ['turma_nome']) ?></td>
              <td><strong><?= date('d/m/Y', strtotime($ativ['data_entrega'])) ?></strong></td>
              <td class="text-center">
                <span class="badge" style="background:<?= $ativ['status'] === 'aberta' ? '#DCFCE7' : '#F3F4F6' ?>; color:<?= $ativ['status'] === 'aberta' ? '#166534' : '#4B5563' ?>;">
                  <?= ucfirst($ativ['status']) ?>
                </span>
              </td>
              <?php if (hasRole('professor') && (int)$ativ['professor_id'] === (int)($_SESSION['usuario_detalhe_id'] ?? 0)): ?>
                <td class="text-center">
                  <a href="atividades.php?action=toggle_status&id=<?= $ativ['id'] ?>" class="btn btn-secondary btn-sm" onclick="return confirm('Alterar status desta atividade?')">
                    <?= $ativ['status'] === 'aberta' ? 'Encerrar' : 'Reabrir' ?>
                  </a>
                </td>
              <?php elseif (hasRole('professor')): ?>
                <td class="text-center">-</td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
