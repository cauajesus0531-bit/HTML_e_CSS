<?php
/**
 * COLÉGIO CRISTAL NORTE - Dashboard do Professor
 * Restrição estrita no backend e banco de dados: apenas a disciplina do professor e suas turmas
 */
require_once __DIR__ . '/config.php';
requireRole('professor');

$user = currentUser();
$pdo = getDB();

// 1. Obter cadastro do professor logado e sua disciplina vinculada
$stmtProf = $pdo->prepare("
    SELECT p.*, d.nome as disciplina_nome, d.codigo as disciplina_codigo
    FROM professores p
    JOIN disciplinas d ON d.id = p.disciplina_id
    WHERE p.usuario_id = ?
    LIMIT 1
");
$stmtProf->execute([$user['id']]);
$professor = $stmtProf->fetch();

if (!$professor) {
    die("Cadastro de professor não encontrado para este usuário.");
}

$professorId = $professor['id'];
$disciplinaId = $professor['disciplina_id'];

// 2. Obter SOMENTE as turmas vinculadas a este professor e sua disciplina
$stmtTurmas = $pdo->prepare("
    SELECT 
        t.id, 
        t.nome, 
        t.serie, 
        t.ano_letivo,
        (SELECT COUNT(*) FROM alunos a WHERE a.turma_id = t.id AND a.status = 'ativo') as total_alunos
    FROM turmas t
    JOIN professor_turmas pt ON pt.turma_id = t.id
    WHERE pt.professor_id = ? AND pt.disciplina_id = ?
    ORDER BY t.serie ASC, t.nome ASC
");
$stmtTurmas->execute([$professorId, $disciplinaId]);
$turmasProfessor = $stmtTurmas->fetchAll();

$turmaIds = array_column($turmasProfessor, 'id');
$totalAlunosGeral = array_sum(array_column($turmasProfessor, 'total_alunos'));

// 3. Atividades criadas por este professor (estritamente sua disciplina)
$stmtAtiv = $pdo->prepare("
    SELECT a.*, t.nome as turma_nome, t.serie as turma_serie
    FROM atividades a
    JOIN turmas t ON t.id = a.turma_id
    WHERE a.professor_id = ? AND a.disciplina_id = ?
    ORDER BY a.data_entrega DESC
    LIMIT 5
");
$stmtAtiv->execute([$professorId, $disciplinaId]);
$atividades = $stmtAtiv->fetchAll();

// 4. Últimos lançamentos de notas deste professor
$stmtUltimasNotas = $pdo->prepare("
    SELECT n.*, a.nome as aluno_nome, t.nome as turma_nome
    FROM notas n
    JOIN alunos a ON a.id = n.aluno_id
    JOIN turmas t ON t.id = n.turma_id
    WHERE n.professor_id = ? AND n.disciplina_id = ?
    ORDER BY n.atualizado_em DESC
    LIMIT 5
");
$stmtUltimasNotas->execute([$professorId, $disciplinaId]);
$ultimasNotas = $stmtUltimasNotas->fetchAll();

// 5. Comunicados para professores ou gerais
$stmtCom = $pdo->query("
    SELECT c.*, u.nome as autor_nome
    FROM comunicados c
    JOIN usuarios u ON u.id = c.autor_id
    WHERE c.publico_alvo IN ('todos', 'professores')
    ORDER BY c.data_publicacao DESC
    LIMIT 4
");
$comunicados = $stmtCom->fetchAll();

$pageTitle = 'Painel do Docente - ' . htmlspecialchars($professor['nome']);
require_once __DIR__ . '/header.php';
?>

<!-- Identificação do Professor e Disciplina Exclusiva -->
<div class="card" style="border-left: 6px solid var(--accent-blue);">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
    <div>
      <h2 style="margin:0; font-size:1.6rem; color:var(--text-dark);">
        <?= htmlspecialchars($professor['nome']) ?>
      </h2>
      <p style="color:var(--text-muted); margin:6px 0 0 0; font-size:0.95rem;">
        <strong>Disciplina Atribuída:</strong> 
        <span class="badge" style="background:#E0F2FE; color:#0369A1; font-size:0.88rem; padding:6px 12px;">
          <?= htmlspecialchars($professor['disciplina_nome']) ?> (<?= htmlspecialchars($professor['disciplina_codigo']) ?>)
        </span>
        | <strong>Ano Letivo:</strong> 2026
      </p>
    </div>
    <div style="display:flex; gap:10px;">
      <a href="diario.php" class="btn btn-primary">📖 Abrir Diário de Classe</a>
      <a href="atividades.php?action=nova" class="btn btn-secondary">➕ Nova Atividade</a>
    </div>
  </div>
</div>

<!-- KPIs do Professor -->
<div class="kpi-grid">
  <div class="kpi-card">
    <span class="kpi-title">Minha Disciplina</span>
    <span class="kpi-value" style="font-size:1.6rem; color:var(--accent-blue);">
      <?= htmlspecialchars($professor['disciplina_nome']) ?>
    </span>
    <span class="kpi-sub">Acesso restrito e exclusivo</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Minhas Turmas</span>
    <span class="kpi-value" style="color:var(--primary-orange);">
      <?= count($turmasProfessor) ?>
    </span>
    <span class="kpi-sub">Turmas sob sua responsabilidade</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Total de Estudantes</span>
    <span class="kpi-value" style="color:var(--primary-red);">
      <?= $totalAlunosGeral ?>
    </span>
    <span class="kpi-sub">Alunos ativos em suas turmas</span>
  </div>

  <div class="kpi-card">
    <span class="kpi-title">Atividades Criadas</span>
    <span class="kpi-value" style="color:var(--accent-green);">
      <?= count($atividades) ?>
    </span>
    <span class="kpi-sub">Tarefas e avaliações registradas</span>
  </div>
</div>

<!-- Suas Turmas Atribuídas -->
<div class="card">
  <div class="card-header">
    <h2>Suas Turmas — Disciplina: <?= htmlspecialchars($professor['disciplina_nome']) ?></h2>
    <span class="badge" style="background:#FEF3C7; color:#92400E;">Permissão Restrita</span>
  </div>

  <?php if (empty($turmasProfessor)): ?>
    <p style="color:var(--text-muted);">Nenhuma turma atribuída a este professor no momento. Entre em contato com a coordenação.</p>
  <?php else: ?>
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:18px;">
      <?php foreach ($turmasProfessor as $turma): ?>
        <div style="background:#FAF6EF; border:1px solid var(--border-color); border-radius:10px; padding:18px; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
              <h3 style="margin:0; font-size:1.2rem; color:var(--primary-red);"><?= htmlspecialchars($turma['nome']) ?></h3>
              <span class="badge" style="background:#E8F5E9; color:#2E7D32;"><?= $turma['total_alunos'] ?> Alunos</span>
            </div>
            <p style="color:#4B5563; font-size:0.9rem; margin-bottom:14px;">
              <?= htmlspecialchars($turma['serie']) ?> • Ano <?= $turma['ano_letivo'] ?>
            </p>
          </div>

          <div style="display:flex; gap:8px; flex-wrap:wrap; border-top:1px solid #E7DFD5; padding-top:12px;">
            <a href="diario.php?turma_id=<?= $turma['id'] ?>" class="btn btn-primary btn-sm">Diário Completo</a>
            <a href="frequencia.php?turma_id=<?= $turma['id'] ?>" class="btn btn-secondary btn-sm">Frequência</a>
            <a href="notas.php?turma_id=<?= $turma['id'] ?>" class="btn btn-secondary btn-sm">Notas</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<div class="form-grid-2">
  <!-- Atividades Recentes do Professor -->
  <div class="card">
    <div class="card-header">
      <h2>Atividades da Disciplina</h2>
      <a href="atividades.php" class="btn btn-secondary btn-sm">Gerenciar</a>
    </div>
    <?php if (empty($atividades)): ?>
      <p style="color:var(--text-muted);">Nenhuma atividade cadastrada.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($atividades as $ativ): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border-left:4px solid var(--primary-orange);">
            <div style="display:flex; justify-content:space-between;">
              <strong><?= htmlspecialchars($ativ['titulo']) ?></strong>
              <span class="badge" style="background:#FFF3E0; color:#E65100;"><?= ucfirst($ativ['status']) ?></span>
            </div>
            <p style="font-size:0.85rem; color:#4B5563; margin:4px 0;"><?= htmlspecialchars($ativ['descricao']) ?></p>
            <div style="font-size:0.8rem; color:#6B7280; display:flex; justify-content:space-between;">
              <span><?= htmlspecialchars($ativ['turma_serie']) ?> — <?= htmlspecialchars($ativ['turma_nome']) ?></span>
              <span>Entrega: <?= date('d/m/Y', strtotime($ativ['data_entrega'])) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Mural de Comunicados da Escola -->
  <div class="card">
    <div class="card-header">
      <h2>Comunicados Institucionais</h2>
    </div>
    <?php if (empty($comunicados)): ?>
      <p style="color:var(--text-muted);">Nenhum comunicado recente.</p>
    <?php else: ?>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <?php foreach ($comunicados as $c): ?>
          <div style="padding:12px; background:#FAF6EF; border-radius:8px; border:1px solid var(--border-color);">
            <h4 style="margin:0 0 6px 0; color:var(--primary-red);"><?= htmlspecialchars($c['titulo']) ?></h4>
            <p style="font-size:0.88rem; color:#374151; margin-bottom:6px;"><?= nl2br(htmlspecialchars($c['conteudo'])) ?></p>
            <small style="color:#9CA3AF;">Publicado por <?= htmlspecialchars($c['autor_nome']) ?> em <?= date('d/m/Y', strtotime($c['data_publicacao'])) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
