<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão de Ocorrências Escolares
 * Controle de Permissões:
 * - Aluno: somente suas ocorrências
 * - Responsável: somente seus filhos
 * - Professor: registra e visualiza para alunos de suas turmas
 * - Diretor / Coordenador: controle total e mediação
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

$action = $_GET['action'] ?? 'listar';

// ==========================================
// AÇÃO: REGISTRAR NOVA OCORRÊNCIA (Professor, Coordenador ou Diretor)
// ==========================================
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole(['professor', 'coordenador', 'diretor']);

    $alunoId = intval($_POST['aluno_id'] ?? 0);
    $dataOco = trim($_POST['data_ocorrencia'] ?? date('Y-m-d'));
    $descricao = trim($_POST['descricao'] ?? '');

    // Se for professor, valida se o aluno pertence a uma de suas turmas
    if ($user['perfil'] === 'professor') {
        $stmtProf = $pdo->prepare("SELECT id FROM professores WHERE usuario_id = ?");
        $stmtProf->execute([$user['id']]);
        $profId = $stmtProf->fetchColumn();

        $stmtCheck = $pdo->prepare("
            SELECT COUNT(*) 
            FROM alunos a
            JOIN professor_turmas pt ON pt.turma_id = a.turma_id
            WHERE a.id = ? AND pt.professor_id = ?
        ");
        $stmtCheck->execute([$alunoId, $profId]);
        if ($stmtCheck->fetchColumn() == 0) {
            flash('error', 'Acesso negado: Você não pode registrar ocorrência para alunos de turmas que não leciona.');
            header('Location: ocorrencias.php');
            exit;
        }
    }

    if (empty($alunoId) || empty($descricao)) {
        flash('error', 'Por favor, selecione o aluno e informe a descrição da ocorrência.');
    } else {
        $stmtIns = $pdo->prepare("
            INSERT INTO ocorrencias (aluno_id, autor_id, data_ocorrencia, descricao, situacao)
            VALUES (?, ?, ?, ?, 'pendente')
        ");
        $stmtIns->execute([$alunoId, $user['id'], $dataOco, $descricao]);
        flash('success', 'Ocorrência disciplinar registrada com sucesso.');
        header('Location: ocorrencias.php');
        exit;
    }
}

// Alterar Situação da Ocorrência (Diretor / Coordenador)
if ($action === 'mudar_situacao') {
    requireRole(['coordenador', 'diretor']);
    $id = intval($_GET['id'] ?? 0);
    $novaSit = trim($_GET['situacao'] ?? 'resolvida');

    if (in_array($novaSit, ['pendente', 'em_analise', 'resolvida'])) {
        $stmtUp = $pdo->prepare("UPDATE ocorrencias SET situacao = ? WHERE id = ?");
        $stmtUp->execute([$novaSit, $id]);
        flash('success', 'Situação da ocorrência atualizada com sucesso.');
    }
    header('Location: ocorrencias.php');
    exit;
}

$pageTitle = 'Registro de Ocorrências Escolares';
require_once __DIR__ . '/header.php';
?>

<!-- FORMULÁRIO DE NOVA OCORRÊNCIA -->
<?php if ($action === 'nova' && hasRole(['professor', 'coordenador', 'diretor'])): ?>
  <?php
    if ($user['perfil'] === 'professor') {
        $stmtProf = $pdo->prepare("SELECT id FROM professores WHERE usuario_id = ?");
        $stmtProf->execute([$user['id']]);
        $profId = $stmtProf->fetchColumn();

        $stmtAlunos = $pdo->prepare("
            SELECT DISTINCT a.id, a.nome, a.matricula, t.nome as turma_nome, t.serie as turma_serie
            FROM alunos a
            JOIN turmas t ON t.id = a.turma_id
            JOIN professor_turmas pt ON pt.turma_id = t.id
            WHERE pt.professor_id = ? AND a.status = 'ativo'
            ORDER BY a.nome ASC
        ");
        $stmtAlunos->execute([$profId]);
    } else {
        $stmtAlunos = $pdo->query("
            SELECT a.id, a.nome, a.matricula, t.nome as turma_nome, t.serie as turma_serie
            FROM alunos a
            JOIN turmas t ON t.id = a.turma_id
            WHERE a.status = 'ativo'
            ORDER BY a.nome ASC
        ");
    }
    $listaAlunos = $stmtAlunos->fetchAll();
    $alunoPreSel = intval($_GET['aluno_id'] ?? 0);
  ?>
  <div class="card">
    <div class="card-header">
      <h2>Registrar Ocorrência Disciplinar</h2>
      <a href="ocorrencias.php" class="btn btn-secondary btn-sm">Voltar</a>
    </div>

    <form method="POST" action="ocorrencias.php?action=salvar">
      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="aluno_id">Selecione o Estudante *</label>
          <select name="aluno_id" id="aluno_id" class="form-control" required>
            <option value="">Selecione o aluno...</option>
            <?php foreach ($listaAlunos as $al): ?>
              <option value="<?= $al['id'] ?>" <?= $al['id'] == $alunoPreSel ? 'selected' : '' ?>>
                <?= htmlspecialchars($al['nome']) ?> (<?= htmlspecialchars($al['turma_serie']) ?> — <?= htmlspecialchars($al['turma_nome']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="data_ocorrencia">Data do Fato *</label>
          <input type="date" name="data_ocorrencia" id="data_ocorrencia" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>

        <div class="form-group col-span-2">
          <label for="descricao">Relato Detalhado da Ocorrência *</label>
          <textarea name="descricao" id="descricao" class="form-control" rows="5" required placeholder="Descreva os fatos ocorridos com clareza, pontuando condutas e medidas adotadas..."></textarea>
        </div>
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-danger" style="padding:12px 28px;">Salvar Registro de Ocorrência</button>
      </div>
    </form>
  </div>
<?php endif; ?>

<!-- LISTAGEM DE OCORRÊNCIAS -->
<?php
if ($user['perfil'] === 'aluno') {
    $stmtOco = $pdo->prepare("
        SELECT o.*, a.nome as aluno_nome, a.matricula, u.nome as autor_nome, t.nome as turma_nome
        FROM ocorrencias o
        JOIN alunos a ON a.id = o.aluno_id
        JOIN usuarios u ON u.id = o.autor_id
        JOIN turmas t ON t.id = a.turma_id
        WHERE a.usuario_id = ?
        ORDER BY o.data_ocorrencia DESC
    ");
    $stmtOco->execute([$user['id']]);
} elseif ($user['perfil'] === 'responsavel') {
    $stmtResp = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
    $stmtResp->execute([$user['id']]);
    $respId = $stmtResp->fetchColumn();

    $stmtOco = $pdo->prepare("
        SELECT o.*, a.nome as aluno_nome, a.matricula, u.nome as autor_nome, t.nome as turma_nome
        FROM ocorrencias o
        JOIN alunos a ON a.id = o.aluno_id
        JOIN usuarios u ON u.id = o.autor_id
        JOIN turmas t ON t.id = a.turma_id
        JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
        WHERE ar.responsavel_id = ?
        ORDER BY o.data_ocorrencia DESC
    ");
    $stmtOco->execute([$respId]);
} else {
    // Professor / Coordenador / Diretor
    $stmtOco = $pdo->query("
        SELECT o.*, a.nome as aluno_nome, a.matricula, u.nome as autor_nome, t.nome as turma_nome, t.serie as turma_serie
        FROM ocorrencias o
        JOIN alunos a ON a.id = o.aluno_id
        JOIN usuarios u ON u.id = o.autor_id
        JOIN turmas t ON t.id = a.turma_id
        ORDER BY o.data_ocorrencia DESC
    ");
}
$ocorrencias = $stmtOco->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <h2>Registro Geral de Ocorrências</h2>
    <?php if (hasRole(['professor', 'coordenador', 'diretor'])): ?>
      <a href="ocorrencias.php?action=nova" class="btn btn-danger btn-sm">➕ Registrar Ocorrência</a>
    <?php endif; ?>
  </div>

  <?php if (empty($ocorrencias)): ?>
    <p style="color:var(--accent-green); font-weight:600;">✓ Nenhuma ocorrência disciplinar cadastrada no momento.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>Estudante</th>
            <th>Relato / Descrição</th>
            <th>Registrado Por</th>
            <th class="text-center">Situação</th>
            <?php if (hasRole(['coordenador', 'diretor'])): ?>
              <th class="text-center">Mediação</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($ocorrencias as $oco): ?>
            <tr>
              <td><strong><?= date('d/m/Y', strtotime($oco['data_ocorrencia'])) ?></strong></td>
              <td>
                <strong><?= htmlspecialchars($oco['aluno_nome']) ?></strong>
                <br><small style="color:var(--text-muted);"><?= htmlspecialchars($oco['matricula']) ?> (<?= htmlspecialchars($oco['turma_nome']) ?>)</small>
              </td>
              <td><?= nl2br(htmlspecialchars($oco['descricao'])) ?></td>
              <td><?= htmlspecialchars($oco['autor_nome']) ?></td>
              <td class="text-center">
                <?php
                  $st = $oco['situacao'];
                  $badgeColor = '#FEE2E2; color:#991B1B';
                  if ($st === 'resolvida') $badgeColor = '#DCFCE7; color:#166534';
                  elseif ($st === 'em_analise') $badgeColor = '#FEF3C7; color:#92400E';
                ?>
                <span class="badge" style="background:<?= $badgeColor ?>;"><?= ucfirst(str_replace('_', ' ', $st)) ?></span>
              </td>
              <?php if (hasRole(['coordenador', 'diretor'])): ?>
                <td class="text-center">
                  <?php if ($oco['situacao'] !== 'resolvida'): ?>
                    <a href="ocorrencias.php?action=mudar_situacao&id=<?= $oco['id'] ?>&situacao=resolvida" class="btn btn-success btn-sm">Marcar Resolvida</a>
                  <?php else: ?>
                    <a href="ocorrencias.php?action=mudar_situacao&id=<?= $oco['id'] ?>&situacao=em_analise" class="btn btn-secondary btn-sm">Reabrir</a>
                  <?php endif; ?>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
