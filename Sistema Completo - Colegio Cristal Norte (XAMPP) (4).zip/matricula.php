<?php
/**
 * COLÉGIO CRISTAL NORTE - Matrícula de Novos Alunos
 * Portal Acadêmico e de Matrículas Escolares — Ano Letivo 2026
 */
require_once __DIR__ . '/config.php';

$pdo = getDB();
$erro = '';
$sucessoMatricula = null;

// Buscar turmas disponíveis para o ano letivo 2026
$stmtTurmas = $pdo->query("SELECT id, nome, serie FROM turmas WHERE ano_letivo = 2026 ORDER BY serie ASC, nome ASC");
$turmasDisponiveis = $stmtTurmas->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Dados do Aluno
    $aluno_nome = trim($_POST['aluno_nome'] ?? '');
    $aluno_nascimento = trim($_POST['aluno_nascimento'] ?? '');
    $aluno_cpf = trim($_POST['aluno_cpf'] ?? '');
    $aluno_rg = trim($_POST['aluno_rg'] ?? '');
    $aluno_sexo = trim($_POST['aluno_sexo'] ?? '');
    $aluno_cep = trim($_POST['aluno_cep'] ?? '');
    $aluno_endereco = trim($_POST['aluno_endereco'] ?? '');
    $aluno_numero = trim($_POST['aluno_numero'] ?? '');
    $aluno_bairro = trim($_POST['aluno_bairro'] ?? '');
    $aluno_cidade = trim($_POST['aluno_cidade'] ?? '');
    $aluno_estado = trim($_POST['aluno_estado'] ?? '');
    $aluno_telefone = trim($_POST['aluno_telefone'] ?? '');
    $aluno_email = trim($_POST['aluno_email'] ?? '');

    // 2. Dados do Responsável
    $resp_nome = trim($_POST['resp_nome'] ?? '');
    $resp_cpf = trim($_POST['resp_cpf'] ?? '');
    $resp_rg = trim($_POST['resp_rg'] ?? '');
    $resp_parentesco = trim($_POST['resp_parentesco'] ?? '');
    $resp_telefone = trim($_POST['resp_telefone'] ?? '');
    $resp_email = trim($_POST['resp_email'] ?? '');
    $resp_senha = $_POST['resp_senha'] ?? '';

    // 3. Dados Escolares
    $turma_id = intval($_POST['turma_id'] ?? 0);
    $ano_letivo = 2026;

    // ==========================================
    // VALIDAÇÃO RIGOROSA NO BACKEND
    // ==========================================
    if (empty($aluno_nome) || empty($aluno_nascimento) || empty($aluno_cpf) || empty($aluno_sexo) ||
        empty($resp_nome) || empty($resp_cpf) || empty($resp_parentesco) || empty($resp_telefone) ||
        empty($resp_email) || empty($resp_senha) || empty($turma_id)) {
        $erro = 'Por favor, preencha todos os campos obrigatórios assinalados com (*).';
    } else {
        // Validação da REGRA DE IDADE (6 a 17 anos completos)
        $idade = calcularIdade($aluno_nascimento);
        if ($idade < 6) {
            $erro = "Regra de Idade Violada: O estudante tem {$idade} anos. A escola aceita apenas estudantes com no mínimo 6 anos completos.";
        } elseif ($idade >= 18) {
            $erro = "Regra de Idade Violada: O estudante tem {$idade} anos. A escola aceita apenas estudantes com até 17 anos (menores de 18 anos).";
        } else {
            // Verificar se o CPF do aluno já existe
            $stmtCpf = $pdo->prepare("SELECT id FROM alunos WHERE cpf = ?");
            $stmtCpf->execute([$aluno_cpf]);
            if ($stmtCpf->fetch()) {
                $erro = "O CPF do estudante informado já está cadastrado em nosso sistema.";
            } else {
                try {
                    $pdo->beginTransaction();

                    // Passo 1: Verificar se o responsável já possui conta de usuário ou criar nova
                    $stmtCheckResp = $pdo->prepare("SELECT u.id as usuario_id, r.id as responsavel_id FROM usuarios u LEFT JOIN responsaveis r ON r.usuario_id = u.id WHERE u.email = ?");
                    $stmtCheckResp->execute([$resp_email]);
                    $respExistente = $stmtCheckResp->fetch();

                    if ($respExistente) {
                        $usuarioRespId = $respExistente['usuario_id'];
                        $responsavelId = $respExistente['responsavel_id'];

                        // Se existe o usuário mas não na tabela responsaveis, insere
                        if (!$responsavelId) {
                            $stmtInsResp = $pdo->prepare("INSERT INTO responsaveis (usuario_id, nome, cpf, rg, parentesco, telefone, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
                            $stmtInsResp->execute([$usuarioRespId, $resp_nome, $resp_cpf, $resp_rg, $resp_parentesco, $resp_telefone, $resp_email]);
                            $responsavelId = $pdo->lastInsertId();
                        }
                    } else {
                        // Criar conta de usuário para o responsável com a senha informada
                        $senhaHashResp = password_hash($resp_senha, PASSWORD_DEFAULT);
                        $stmtInsUser = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, perfil, ativo) VALUES (?, ?, ?, 'responsavel', 1)");
                        $stmtInsUser->execute([$resp_nome, $resp_email, $senhaHashResp]);
                        $usuarioRespId = $pdo->lastInsertId();

                        // Criar perfil na tabela responsaveis
                        $stmtInsResp = $pdo->prepare("INSERT INTO responsaveis (usuario_id, nome, cpf, rg, parentesco, telefone, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmtInsResp->execute([$usuarioRespId, $resp_nome, $resp_cpf, $resp_rg, $resp_parentesco, $resp_telefone, $resp_email]);
                        $responsavelId = $pdo->lastInsertId();
                    }

                    // Passo 2: Gerar Número Oficial de Matrícula (MAT-2026-XXXXX)
                    $numeroMatricula = gerarNumeroMatricula($pdo);

                    // Passo 3: Criar conta de usuário para o aluno (login usando email ou matricula gerada)
                    $emailAlunoEfetivo = !empty($aluno_email) ? $aluno_email : strtolower($numeroMatricula) . '@aluno.cristalnorte.com.br';
                    $senhaHashAluno = password_hash('aluno123', PASSWORD_DEFAULT); // Senha padrão inicial para o aluno

                    // Checa se email do aluno já existe
                    $stmtCheckAlunoUser = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
                    $stmtCheckAlunoUser->execute([$emailAlunoEfetivo]);
                    $userAlunoId = $stmtCheckAlunoUser->fetchColumn();

                    if (!$userAlunoId) {
                        $stmtInsUserAluno = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, perfil, ativo) VALUES (?, ?, ?, 'aluno', 1)");
                        $stmtInsUserAluno->execute([$aluno_nome, $emailAlunoEfetivo, $senhaHashAluno]);
                        $userAlunoId = $pdo->lastInsertId();
                    }

                    // Passo 4: Salvar cadastro do aluno
                    $stmtInsAluno = $pdo->prepare("INSERT INTO alunos 
                        (usuario_id, matricula, nome, data_nascimento, cpf, rg, sexo, cep, endereco, numero, bairro, cidade, estado, telefone, email, turma_id, status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ativo')");
                    $stmtInsAluno->execute([
                        $userAlunoId, $numeroMatricula, $aluno_nome, $aluno_nascimento, $aluno_cpf, $aluno_rg, $aluno_sexo,
                        $aluno_cep, $aluno_endereco, $aluno_numero, $aluno_bairro, $aluno_cidade, $aluno_estado,
                        $aluno_telefone, $emailAlunoEfetivo, $turma_id
                    ]);
                    $alunoId = $pdo->lastInsertId();

                    // Passo 5: Criar Vínculo entre Responsável e Aluno
                    $stmtVinculo = $pdo->prepare("INSERT INTO alunos_responsaveis (aluno_id, responsavel_id, parentesco) VALUES (?, ?, ?)");
                    $stmtVinculo->execute([$alunoId, $responsavelId, $resp_parentesco]);

                    // Passo 6: Registrar na tabela formal de matrículas
                    $stmtMat = $pdo->prepare("INSERT INTO matriculas (aluno_id, numero_matricula, ano_letivo, status) VALUES (?, ?, ?, 'confirmada')");
                    $stmtMat->execute([$alunoId, $numeroMatricula, $ano_letivo]);

                    $pdo->commit();

                    // Obter dados da turma para exibição
                    $stmtTurmaInfo = $pdo->prepare("SELECT nome, serie FROM turmas WHERE id = ?");
                    $stmtTurmaInfo->execute([$turma_id]);
                    $turmaInfo = $stmtTurmaInfo->fetch();

                    $sucessoMatricula = [
                        'matricula' => $numeroMatricula,
                        'aluno_nome' => $aluno_nome,
                        'idade' => $idade,
                        'turma' => ($turmaInfo['serie'] ?? '') . ' — ' . ($turmaInfo['nome'] ?? ''),
                        'resp_nome' => $resp_nome,
                        'resp_email' => $resp_email,
                        'aluno_email' => $emailAlunoEfetivo
                    ];

                } catch (Exception $e) {
                    $pdo->rollBack();
                    $erro = 'Erro ao processar matrícula: ' . $e->getMessage();
                }
            }
        }
    }
}

$pageTitle = 'Cadastro e Matrícula de Aluno - Ano Letivo 2026';
require_once __DIR__ . '/header.php';
?>

<div class="card">
  <div style="text-align: center; margin-bottom: 24px;">
    <img src="<?= LOGO_URL ?>" alt="Colégio Cristal Norte" style="max-height: 80px; width: auto; background: #fff; padding: 4px; border-radius: 8px;">
    <h1 style="color: var(--primary-red); font-size: 1.8rem; margin-top: 10px;">Cadastro e Matrícula de Aluno</h1>
    <p style="color: #4B5563; font-size: 1.05rem;">
      Preencha os dados do estudante e do responsável para emitir sua matrícula no <strong>Colégio Cristal Norte</strong>.
    </p>
    <div style="margin-top: 10px;">
      <span class="badge" style="background: var(--accent-green); color: #fff; padding: 6px 16px; border-radius: 20px;">
        Ano Letivo 2026 • Faixa Etária: 6 a 17 Anos
      </span>
    </div>
  </div>

  <?php if (!empty($erro)): ?>
    <div class="alert alert-error">
      <span><?= htmlspecialchars($erro) ?></span>
    </div>
  <?php endif; ?>

  <?php if ($sucessoMatricula): ?>
    <!-- Confirmação de Matrícula Realizada com Sucesso -->
    <div style="background: #E8F5E9; border: 2px solid #81C784; border-radius: 12px; padding: 30px; text-align: center; margin: 20px 0;">
      <div style="font-size: 3rem; color: #2E7D32; margin-bottom: 10px;">✓</div>
      <h2 style="color: #2E7D32; font-size: 1.6rem; margin-bottom: 12px;">Matrícula Concluída com Sucesso!</h2>
      <p style="font-size: 1.1rem; color: #1B5E20; margin-bottom: 20px;">
        Parabéns! O registro escolar foi confirmado no Colégio Cristal Norte.
      </p>

      <div style="background: #FFFFFF; border: 2px dashed #4CAF50; border-radius: 8px; padding: 20px; display: inline-block; margin-bottom: 24px;">
        <span style="font-size: 0.95rem; color: #4B5563; display: block;">Número Oficial da Matrícula:</span>
        <strong style="font-size: 2rem; color: var(--primary-red); letter-spacing: 1px;">
          Matrícula Gerada: <?= htmlspecialchars($sucessoMatricula['matricula']) ?>
        </strong>
      </div>

      <div style="max-width: 600px; margin: 0 auto; text-align: left; background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #C8E6C9;">
        <h4 style="color: #2E7D32; border-bottom: 1px solid #E0E0E0; padding-bottom: 6px; margin-bottom: 12px;">Resumo do Cadastro:</h4>
        <p><strong>Estudante:</strong> <?= htmlspecialchars($sucessoMatricula['aluno_nome']) ?> (<?= $sucessoMatricula['idade'] ?> anos)</p>
        <p><strong>Turma Vinculada:</strong> <?= htmlspecialchars($sucessoMatricula['turma']) ?></p>
        <p><strong>Responsável:</strong> <?= htmlspecialchars($sucessoMatricula['resp_nome']) ?></p>
        <p><strong>E-mail de Acesso do Responsável:</strong> <?= htmlspecialchars($sucessoMatricula['resp_email']) ?></p>
        <p><strong>Login do Aluno (Portal):</strong> <?= htmlspecialchars($sucessoMatricula['aluno_email']) ?></p>
        <div style="margin-top: 14px; padding: 10px; background: #FFF8E1; border-radius: 6px; font-size: 0.88rem; color: #795548;">
          💡 <strong>Importante:</strong> A conta do responsável já foi criada e vinculada automaticamente. Você já pode acessar o sistema utilizando o e-mail e a senha cadastrados sem necessidade de nenhum cadastro adicional.
        </div>
      </div>

      <div style="margin-top: 24px; display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
        <a href="login.php" class="btn btn-primary" style="padding: 12px 24px;">Acessar Portal Agora</a>
        <a href="matricula.php" class="btn btn-secondary" style="padding: 12px 24px;">Matricular Outro Aluno</a>
      </div>
    </div>
  <?php else: ?>

    <form method="POST" action="matricula.php" id="formMatricula">
      <!-- 1. DADOS DO ALUNO -->
      <div class="form-section-title">1. Dados do Estudante (Idade entre 6 e 17 anos)</div>
      
      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="aluno_nome">Nome Completo do Aluno *</label>
          <input type="text" name="aluno_nome" id="aluno_nome" class="form-control" required value="<?= htmlspecialchars($_POST['aluno_nome'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_data_nascimento">Data de Nascimento Completa *</label>
          <input type="date" name="aluno_nascimento" id="aluno_data_nascimento" class="form-control" required value="<?= htmlspecialchars($_POST['aluno_nascimento'] ?? '') ?>">
          <div id="idadeFeedback" class="mt-1" style="font-size: 0.85rem;"></div>
        </div>

        <div class="form-group">
          <label for="aluno_sexo">Sexo *</label>
          <select name="aluno_sexo" id="aluno_sexo" class="form-control" required>
            <option value="">Selecione...</option>
            <option value="M" <?= (isset($_POST['aluno_sexo']) && $_POST['aluno_sexo'] === 'M') ? 'selected' : '' ?>>Masculino</option>
            <option value="F" <?= (isset($_POST['aluno_sexo']) && $_POST['aluno_sexo'] === 'F') ? 'selected' : '' ?>>Feminino</option>
            <option value="Outro" <?= (isset($_POST['aluno_sexo']) && $_POST['aluno_sexo'] === 'Outro') ? 'selected' : '' ?>>Outro</option>
          </select>
        </div>

        <div class="form-group">
          <label for="aluno_cpf">CPF do Aluno *</label>
          <input type="text" name="aluno_cpf" id="aluno_cpf" class="form-control mask-cpf" placeholder="000.000.000-00" required value="<?= htmlspecialchars($_POST['aluno_cpf'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_rg">RG do Aluno</label>
          <input type="text" name="aluno_rg" id="aluno_rg" class="form-control" value="<?= htmlspecialchars($_POST['aluno_rg'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_telefone">Telefone / Celular do Aluno</label>
          <input type="text" name="aluno_telefone" id="aluno_telefone" class="form-control mask-phone" placeholder="(00) 00000-0000" value="<?= htmlspecialchars($_POST['aluno_telefone'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_email">E-mail do Aluno (quando possuir)</label>
          <input type="email" name="aluno_email" id="aluno_email" class="form-control" placeholder="aluno@exemplo.com" value="<?= htmlspecialchars($_POST['aluno_email'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_cep">CEP</label>
          <input type="text" name="aluno_cep" id="aluno_cep" class="form-control mask-cep" placeholder="00000-000" value="<?= htmlspecialchars($_POST['aluno_cep'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_endereco">Endereço (Rua/Avenida)</label>
          <input type="text" name="aluno_endereco" id="aluno_endereco" class="form-control" value="<?= htmlspecialchars($_POST['aluno_endereco'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_numero">Número</label>
          <input type="text" name="aluno_numero" id="aluno_numero" class="form-control" value="<?= htmlspecialchars($_POST['aluno_numero'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_bairro">Bairro</label>
          <input type="text" name="aluno_bairro" id="aluno_bairro" class="form-control" value="<?= htmlspecialchars($_POST['aluno_bairro'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_cidade">Cidade</label>
          <input type="text" name="aluno_cidade" id="aluno_cidade" class="form-control" value="<?= htmlspecialchars($_POST['aluno_cidade'] ?? 'São Paulo') ?>">
        </div>

        <div class="form-group">
          <label for="aluno_estado">Estado (UF)</label>
          <input type="text" name="aluno_estado" id="aluno_estado" class="form-control" maxlength="2" value="<?= htmlspecialchars($_POST['aluno_estado'] ?? 'SP') ?>">
        </div>
      </div>

      <!-- 2. DADOS DO RESPONSÁVEL -->
      <div class="form-section-title">2. Dados do Responsável Legal (Acesso Automático ao Portal)</div>
      
      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="resp_nome">Nome Completo do Responsável *</label>
          <input type="text" name="resp_nome" id="resp_nome" class="form-control" required value="<?= htmlspecialchars($_POST['resp_nome'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="resp_cpf">CPF do Responsável *</label>
          <input type="text" name="resp_cpf" id="resp_cpf" class="form-control mask-cpf" placeholder="000.000.000-00" required value="<?= htmlspecialchars($_POST['resp_cpf'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="resp_rg">RG do Responsável</label>
          <input type="text" name="resp_rg" id="resp_rg" class="form-control" value="<?= htmlspecialchars($_POST['resp_rg'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="resp_parentesco">Grau de Parentesco *</label>
          <select name="resp_parentesco" id="resp_parentesco" class="form-control" required>
            <option value="">Selecione...</option>
            <option value="Mãe" <?= (isset($_POST['resp_parentesco']) && $_POST['resp_parentesco'] === 'Mãe') ? 'selected' : '' ?>>Mãe</option>
            <option value="Pai" <?= (isset($_POST['resp_parentesco']) && $_POST['resp_parentesco'] === 'Pai') ? 'selected' : '' ?>>Pai</option>
            <option value="Avô / Avó" <?= (isset($_POST['resp_parentesco']) && $_POST['resp_parentesco'] === 'Avô / Avó') ? 'selected' : '' ?>>Avô / Avó</option>
            <option value="Tio / Tia" <?= (isset($_POST['resp_parentesco']) && $_POST['resp_parentesco'] === 'Tio / Tia') ? 'selected' : '' ?>>Tio / Tia</option>
            <option value="Tutor Legal" <?= (isset($_POST['resp_parentesco']) && $_POST['resp_parentesco'] === 'Tutor Legal') ? 'selected' : '' ?>>Tutor Legal</option>
          </select>
        </div>

        <div class="form-group">
          <label for="resp_telefone">Telefone de Contato do Responsável *</label>
          <input type="text" name="resp_telefone" id="resp_telefone" class="form-control mask-phone" placeholder="(00) 00000-0000" required value="<?= htmlspecialchars($_POST['resp_telefone'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="resp_email">E-mail do Responsável (Login do Portal) *</label>
          <input type="email" name="resp_email" id="resp_email" class="form-control" placeholder="responsavel@exemplo.com" required value="<?= htmlspecialchars($_POST['resp_email'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label for="resp_senha">Senha para Acesso ao Portal *</label>
          <input type="password" name="resp_senha" id="resp_senha" class="form-control" placeholder="Crie uma senha de acesso" required minlength="6">
          <small style="color: #6B7280;">Esta senha será utilizada pelo responsável para entrar no portal.</small>
        </div>
      </div>

      <!-- 3. DADOS ESCOLARES -->
      <div class="form-section-title">3. Dados Escolares (Ano Letivo 2026)</div>

      <div class="form-grid-2">
        <div class="form-group col-span-2">
          <label for="turma_id">Selecione a Série e Turma Desejada *</label>
          <select name="turma_id" id="turma_id" class="form-control" required>
            <option value="">Selecione uma turma...</option>
            <?php foreach ($turmasDisponiveis as $t): ?>
              <option value="<?= $t['id'] ?>" <?= (isset($_POST['turma_id']) && $_POST['turma_id'] == $t['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?> (Ano Letivo 2026)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div style="margin-top: 30px; text-align: center;">
        <button type="submit" class="btn btn-primary" style="padding: 14px 36px; font-size: 1.1rem;">
          Concluir e Emitir Matrícula 2026
        </button>
      </div>
    </form>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
