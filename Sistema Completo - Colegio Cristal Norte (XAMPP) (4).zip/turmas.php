<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão de Turmas
 * Cadastro de turmas, enturmação de estudantes e vinculação docente
 * NOTA: Sem opções de turno (manhã/tarde/noite) conforme regra expressa 29.
 */
require_once __DIR__ . '/config.php';
requireRole(['diretor', 'coordenador']);

$pdo = getDB();
$action = $_GET['action'] ?? 'listar';

// Cadastrar Nova Turma
if ($action === 'salvar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $serie = trim($_POST['serie'] ?? '');
    $anoLetivo = intval($_POST['ano_letivo'] ?? 2026);

    if (empty($nome) || empty($serie)) {
        flash('error', 'Por favor, informe o nome e a série da turma.');
    } else {
        $stmtIns = $pdo->prepare("INSERT INTO turmas (nome, serie, ano_letivo) VALUES (?, ?, ?)");
        $stmtIns->execute([$nome, $serie, $anoLetivo]);
        flash('success', 'Nova turma cadastrada com sucesso!');
        header('Location: turmas.php');
        exit;
    }
}

// Vincular Professor e Disciplina à Turma
if ($action === 'vincular_prof' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $turmaId = intval($_POST['turma_id'] ?? 0);
    $profId = intval($_POST['professor_id'] ?? 0);

    // Obter disciplina do professor
    $stmtP = $pdo->prepare("SELECT disciplina_id FROM professores WHERE id = ?");
    $stmtP->execute([$profId]);
    $discId = $stmtP->fetchColumn();

    if ($turmaId && $profId && $discId) {
        $stmtVinculo = $pdo->prepare("
            INSERT INTO professor_turmas (professor_id, turma_id, disciplina_id)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE disciplina_id = VALUES(disciplina_id)
        ");
        $stmtVinculo->execute([$profId, $turmaId, $discId]);
        flash('success', 'Professor vinculado à turma com sucesso!');
    }
    header("Location: turmas.php?ver_id={$turmaId}");
    exit;
}

// Visualizar Detalhes da Turma
$verTurmaId = intval($_GET['ver_id'] ?? 0);
$turmaDetalhes = null;
$alunosDaTurma = [];
$professoresDaTurma = [];
if ($verTurmaId > 0) {
    $stmtT = $pdo->prepare("SELECT * FROM turmas WHERE id = ?");
    $stmtT->execute([$verTurmaId]);
    $turmaDetalhes = $stmtT->fetch();

    if ($turmaDetalhes) {
        $stmtA = $pdo->prepare("SELECT id, matricula, nome, cpf, data_nascimento, status FROM alunos WHERE turma_id = ? ORDER BY nome ASC");
        $stmtA->execute([$verTurmaId]);
        $alunosDaTurma = $stmtA->fetchAll();

        $stmtP = $pdo->prepare("
            SELECT p.id, p.nome as prof_nome, d.nome as disc_nome
            FROM professor_turmas pt
            JOIN professores p ON p.id = pt.professor_id
            JOIN disciplinas d ON d.id = pt.disciplina_id
            WHERE pt.turma_id = ?
        ");
        $stmtP->execute([$verTurmaId]);
        $professoresDaTurma = $stmtP->fetchAll();
    }
}

// Lista Geral de Turmas
$stmtTurmas = $pdo->query("
    SELECT 
        t.*,
        (SELECT COUNT(*) FROM alunos a WHERE a.turma_id = t.id AND a.status = 'ativo') as qtd_alunos,
        (SELECT COUNT(DISTINCT pt.professor_id) FROM professor_turmas pt WHERE pt.turma_id = t.id) as qtd_profs
    FROM turmas t
    WHERE t.ano_letivo = 2026
    ORDER BY t.serie ASC, t.nome ASC
");
$turmas = $stmtTurmas->fetchAll();

// Professores para seleção de vínculo
$todosProfessores = $pdo->query("SELECT p.id, p.nome, d.nome as disciplina_nome FROM professores p JOIN disciplinas d ON d.id = p.disciplina_id ORDER BY p.nome ASC")->fetchAll();

$pageTitle = 'Gestão de Turmas';
require_once __DIR__ . '/header.php';
?>

<!-- MODAL / CARD DE DETALHES DA TURMA -->
<?php if ($turmaDetalhes): ?>
  <div class="card" style="border: 2px solid var(--primary-red); background:#FFFDF9;">
    <div class="card-header">
      <h2>Detalhes da Turma: <?= htmlspecialchars($turmaDetalhes['serie']) ?> — <?= htmlspecialchars($turmaDetalhes['nome']) ?></h2>
      <a href="turmas.php" class="btn btn-secondary btn-sm">Fechar Detalhes</a>
    </div>

    <div class="form-grid-2">
      <!-- Estudantes Matriculados -->
      <div>
        <h4 style="color:var(--primary-red); margin-bottom:12px;">👥 Alunos Matriculados (<?= count($alunosDaTurma) ?>)</h4>
        <?php if (empty($alunosDaTurma)): ?>
          <p style="color:var(--text-muted);">Nenhum estudante matriculado nesta turma ainda.</p>
        <?php else: ?>
          <div class="table-responsive" style="max-height:300px; overflow-y:auto;">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Matrícula</th>
                  <th>Nome do Estudante</th>
                  <th>Idade</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($alunosDaTurma as $al): ?>
                  <tr>
                    <td><strong><?= htmlspecialchars($al['matricula']) ?></strong></td>
                    <td><?= htmlspecialchars($al['nome']) ?></td>
                    <td><?= calcularIdade($al['data_nascimento']) ?> anos</td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

      <!-- Professores e Disciplinas Vinculadas -->
      <div>
        <h4 style="color:var(--primary-orange); margin-bottom:12px;">👨‍🏫 Professores e Disciplinas Vinculadas</h4>
        <?php if (empty($professoresDaTurma)): ?>
          <p style="color:var(--text-muted);">Nenhum professor vinculado a esta turma ainda.</p>
        <?php else: ?>
          <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:8px;">
            <?php foreach ($professoresDaTurma as $pt): ?>
              <li style="padding:10px; background:#FAF6EF; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                <strong><?= htmlspecialchars($pt['prof_nome']) ?></strong>
                <span class="badge" style="background:#E0F2FE; color:#0369A1;"><?= htmlspecialchars($pt['disc_nome']) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>

        <!-- Formulário para vincular professor à turma -->
        <div style="margin-top:20px; padding:14px; background:#F4EBE1; border-radius:8px;">
          <h5 style="margin:0 0 10px 0; color:var(--text-dark);">➕ Vincular Professor a esta Turma:</h5>
          <form method="POST" action="turmas.php?action=vincular_prof" style="display:flex; gap:10px;">
            <input type="hidden" name="turma_id" value="<?= $turmaDetalhes['id'] ?>">
            <select name="professor_id" class="form-control" required style="font-size:0.88rem;">
              <option value="">Selecione o professor...</option>
              <?php foreach ($todosProfessores as $tp): ?>
                <option value="<?= $tp['id'] ?>"><?= htmlspecialchars($tp['nome']) ?> (<?= htmlspecialchars($tp['disciplina_nome']) ?>)</option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Vincular</button>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- QUADRO GERAL E CADASTRO DE TURMAS -->
<div class="form-grid-2">
  <!-- Listagem de Turmas -->
  <div class="card">
    <div class="card-header">
      <h2>Turmas Cadastradas — Ano Letivo 2026</h2>
      <span class="badge badge-aprovado"><?= count($turmas) ?> Turmas</span>
    </div>

    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Nome da Turma</th>
            <th>Série</th>
            <th class="text-center">Alunos</th>
            <th class="text-center">Professores</th>
            <th class="text-center">Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($turmas as $t): ?>
            <tr>
              <td><strong><?= htmlspecialchars($t['nome']) ?></strong></td>
              <td><?= htmlspecialchars($t['serie']) ?></td>
              <td class="text-center"><span class="badge badge-aprovado"><?= $t['qtd_alunos'] ?></span></td>
              <td class="text-center"><span class="badge" style="background:#E0F2FE; color:#0369A1;"><?= $t['qtd_profs'] ?></span></td>
              <td class="text-center">
                <a href="turmas.php?ver_id=<?= $t['id'] ?>" class="btn btn-secondary btn-sm">Detalhes</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Cadastro de Nova Turma -->
  <div class="card">
    <div class="card-header">
      <h2>Cadastrar Nova Turma</h2>
    </div>

    <form method="POST" action="turmas.php?action=salvar">
      <div class="form-group">
        <label for="nome">Nome / Identificação da Turma *</label>
        <input type="text" name="nome" id="nome" class="form-control" required placeholder="Ex: Turma A, Turma B, Sala 102">
      </div>

      <div class="form-group">
        <label for="serie">Série / Grau Escolar *</label>
        <select name="serie" id="serie" class="form-control" required>
          <option value="">Selecione o ano/série...</option>
          <option value="1º Ano do Ensino Fundamental">1º Ano do Ensino Fundamental</option>
          <option value="2º Ano do Ensino Fundamental">2º Ano do Ensino Fundamental</option>
          <option value="3º Ano do Ensino Fundamental">3º Ano do Ensino Fundamental</option>
          <option value="4º Ano do Ensino Fundamental">4º Ano do Ensino Fundamental</option>
          <option value="5º Ano do Ensino Fundamental">5º Ano do Ensino Fundamental</option>
          <option value="6º Ano do Ensino Fundamental">6º Ano do Ensino Fundamental</option>
          <option value="7º Ano do Ensino Fundamental">7º Ano do Ensino Fundamental</option>
          <option value="8º Ano do Ensino Fundamental">8º Ano do Ensino Fundamental</option>
          <option value="9º Ano do Ensino Fundamental">9º Ano do Ensino Fundamental</option>
          <option value="1º Ano do Ensino Médio">1º Ano do Ensino Médio</option>
          <option value="2º Ano do Ensino Médio">2º Ano do Ensino Médio</option>
          <option value="3º Ano do Ensino Médio">3º Ano do Ensino Médio</option>
        </select>
      </div>

      <div class="form-group">
        <label for="ano_letivo">Ano Letivo *</label>
        <input type="number" name="ano_letivo" id="ano_letivo" class="form-control" value="2026" required readonly style="background:#F3F4F6;">
      </div>

      <div style="margin-top:20px; text-align:right;">
        <button type="submit" class="btn btn-primary btn-block">Salvar Nova Turma</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
