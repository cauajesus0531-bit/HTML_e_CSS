/**
 * COLÉGIO CRISTAL NORTE - SCRIPTS DO SISTEMA
 * Validações, Máscaras e Comportamentos Dinâmicos
 */

document.addEventListener('DOMContentLoaded', function () {
  
  // 1. Menu Mobile Toggle
  const mobileToggle = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');
  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', function () {
      navMenu.classList.toggle('open');
    });
  }

  // 2. Validação da Regra de Idade (Entre 6 e 17 anos completos)
  const dataNascimentoInput = document.getElementById('aluno_data_nascimento');
  const idadeFeedback = document.getElementById('idadeFeedback');
  const formMatricula = document.getElementById('formMatricula');

  function calcularIdadeExata(dataString) {
    if (!dataString) return null;
    const parts = dataString.split('-');
    if (parts.length !== 3) return null;
    
    const ano = parseInt(parts[0], 10);
    const mes = parseInt(parts[1], 10) - 1;
    const dia = parseInt(parts[2], 10);
    
    const hoje = new Date();
    const nasc = new Date(ano, mes, dia);
    
    let idade = hoje.getFullYear() - nasc.getFullYear();
    const m = hoje.getMonth() - nasc.getMonth();
    if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) {
      idade--;
    }
    return idade;
  }

  if (dataNascimentoInput && idadeFeedback) {
    dataNascimentoInput.addEventListener('change', function () {
      const idade = calcularIdadeExata(this.value);
      if (idade === null || isNaN(idade)) {
        idadeFeedback.innerHTML = '';
        return;
      }

      if (idade < 6) {
        idadeFeedback.innerHTML = `<span style="color: #C62828; font-weight: bold;">❌ Idade: ${idade} anos. A escola aceita apenas estudantes a partir de 6 anos completos.</span>`;
        dataNascimentoInput.setCustomValidity('Estudante deve ter no mínimo 6 anos.');
      } else if (idade >= 18) {
        idadeFeedback.innerHTML = `<span style="color: #C62828; font-weight: bold;">❌ Idade: ${idade} anos. A escola aceita estudantes de até 17 anos. Estudantes com 18 anos ou mais não podem ser matriculados.</span>`;
        dataNascimentoInput.setCustomValidity('Estudante deve ter menos de 18 anos.');
      } else {
        idadeFeedback.innerHTML = `<span style="color: #2E7D32; font-weight: bold;">✓ Idade válida: ${idade} anos (Permitida: 6 a 17 anos).</span>`;
        dataNascimentoInput.setCustomValidity('');
      }
    });
  }

  if (formMatricula && dataNascimentoInput) {
    formMatricula.addEventListener('submit', function (e) {
      const idade = calcularIdadeExata(dataNascimentoInput.value);
      if (idade === null || idade < 6 || idade >= 18) {
        e.preventDefault();
        alert('Atenção: A matrícula só é permitida para estudantes com idade entre 6 e 17 anos completos.');
        dataNascimentoInput.focus();
        return false;
      }
    });
  }

  // 3. Máscaras de Campos (CPF, Telefone, CEP)
  function aplicarMascara(input, mascaraFn) {
    if (!input) return;
    input.addEventListener('input', function () {
      this.value = mascaraFn(this.value);
    });
  }

  const maskCPF = val => {
    return val
      .replace(/\D/g, '')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})/, '$1-$2')
      .substring(0, 14);
  };

  const maskPhone = val => {
    let r = val.replace(/\D/g, '');
    if (r.length > 10) {
      return r.replace(/^(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
    } else if (r.length > 5) {
      return r.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, '($1) $2-$3');
    } else if (r.length > 2) {
      return r.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
    } else if (r.length > 0) {
      return r.replace(/^(\d*)/, '($1');
    }
    return r;
  };

  const maskCEP = val => {
    return val
      .replace(/\D/g, '')
      .replace(/^(\d{5})(\d)/, '$1-$2')
      .substring(0, 9);
  };

  document.querySelectorAll('.mask-cpf').forEach(el => aplicarMascara(el, maskCPF));
  document.querySelectorAll('.mask-phone').forEach(el => aplicarMascara(el, maskPhone));
  document.querySelectorAll('.mask-cep').forEach(el => aplicarMascara(el, maskCEP));

  // 4. Busca Dinâmica em Tabelas
  const searchInputs = document.querySelectorAll('.table-search-input');
  searchInputs.forEach(input => {
    const targetTableId = input.getAttribute('data-table');
    const table = document.getElementById(targetTableId);
    if (table) {
      input.addEventListener('keyup', function () {
        const term = this.value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
          const text = row.innerText.toLowerCase();
          row.style.display = text.indexOf(term) > -1 ? '' : 'none';
        });
      });
    }
  });

  // 5. Cálculo Dinâmico de Média em Notas
  const notasInputs = document.querySelectorAll('.calcula-media-row');
  notasInputs.forEach(row => {
    const inputs = row.querySelectorAll('.nota-val');
    const mediaDisplay = row.querySelector('.media-val');
    const situacaoDisplay = row.querySelector('.situacao-badge');

    inputs.forEach(inp => {
      inp.addEventListener('input', function () {
        let soma = 0;
        let count = 0;
        inputs.forEach(i => {
          const v = parseFloat(i.value);
          if (!isNaN(v) && v >= 0 && v <= 10) {
            soma += v;
            count++;
          }
        });

        if (count > 0 && mediaDisplay) {
          const media = (soma / count).toFixed(2);
          mediaDisplay.textContent = media;

          if (situacaoDisplay) {
            if (media >= 6.0) {
              situacaoDisplay.textContent = 'Aprovado';
              situacaoDisplay.className = 'badge badge-aprovado situacao-badge';
            } else if (media >= 4.0) {
              situacaoDisplay.textContent = 'Recuperação';
              situacaoDisplay.className = 'badge badge-recuperacao situacao-badge';
            } else {
              situacaoDisplay.textContent = 'Reprovado';
              situacaoDisplay.className = 'badge badge-reprovado situacao-badge';
            }
          }
        }
      });
    });
  });

});

// Funções globais para Modais
function abrirModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('active');
}

function fecharModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('active');
}

// Fechar modal ao clicar fora
window.addEventListener('click', function (e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('active');
  }
});
