<?php
/**
 * COLÉGIO CRISTAL NORTE - Cabeçalho Comum e Navegação
 */
require_once __DIR__ . '/config.php';
$user = currentUser();
$flash = getFlash();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - ' : '' ?>Colégio Cristal Norte</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Faixa Superior Institucional -->
<div class="top-notice">
  <div class="container" style="display:flex; justify-content:space-between; align-items:center; width:100%;">
    <div>
      <strong>COLÉGIO CRISTAL NORTE</strong> — Portal Acadêmico e de Matrículas Escolares — Ano Letivo 2026
    </div>
    <div>
      <span class="badge-matriculas">MATRÍCULAS ABERTAS 2026</span>
    </div>
  </div>
</div>

<!-- Cabeçalho Principal com Logo Oficial -->
<header class="site-header">
  <div class="container nav-container">
    <div class="brand-wrapper">
      <a href="index.php" style="display: flex; align-items: center; gap: 12px; text-decoration: none;">
        <img src="<?= LOGO_URL ?>" alt="Colégio Cristal Norte — Educação & Inovação" class="site-logo">
        <div class="brand-title">
          <h1>COLÉGIO CRISTAL NORTE</h1>
          <span>EDUCAÇÃO & INOVAÇÃO</span>
        </div>
      </a>
    </div>

    <button class="mobile-toggle" id="mobileToggle" aria-label="Abrir menu">☰</button>

    <nav>
      <ul class="nav-menu" id="navMenu">
        <?php if (!$user): ?>
          <li><a href="index.php" class="nav-link <?= $currentPage == 'index.php' ? 'active' : '' ?>">Início</a></li>
          <li><a href="matricula.php" class="nav-link <?= $currentPage == 'matricula.php' ? 'active' : '' ?>">Solicitar Matrícula</a></li>
          <li><a href="login.php" class="btn btn-primary btn-sm">Entrar</a></li>
        <?php else: ?>
          <li><a href="dashboard.php" class="nav-link <?= $currentPage == 'dashboard.php' ? 'active' : '' ?>">Dashboard</a></li>

          <?php if ($user['perfil'] === 'diretor'): ?>
            <li><a href="alunos.php" class="nav-link <?= $currentPage == 'alunos.php' ? 'active' : '' ?>">Alunos</a></li>
            <li><a href="professores.php" class="nav-link <?= $currentPage == 'professores.php' ? 'active' : '' ?>">Professores</a></li>
            <li><a href="turmas.php" class="nav-link <?= $currentPage == 'turmas.php' ? 'active' : '' ?>">Turmas</a></li>
            <li><a href="disciplinas.php" class="nav-link <?= $currentPage == 'disciplinas.php' ? 'active' : '' ?>">Disciplinas</a></li>
            <li><a href="comunicados.php" class="nav-link <?= $currentPage == 'comunicados.php' ? 'active' : '' ?>">Comunicados</a></li>
            <li><a href="ocorrencias.php" class="nav-link <?= $currentPage == 'ocorrencias.php' ? 'active' : '' ?>">Ocorrências</a></li>
          <?php elseif ($user['perfil'] === 'coordenador'): ?>
            <li><a href="alunos.php" class="nav-link <?= $currentPage == 'alunos.php' ? 'active' : '' ?>">Alunos</a></li>
            <li><a href="turmas.php" class="nav-link <?= $currentPage == 'turmas.php' ? 'active' : '' ?>">Turmas</a></li>
            <li><a href="frequencia.php" class="nav-link <?= $currentPage == 'frequencia.php' ? 'active' : '' ?>">Frequência</a></li>
            <li><a href="notas.php" class="nav-link <?= $currentPage == 'notas.php' ? 'active' : '' ?>">Notas</a></li>
            <li><a href="comunicados.php" class="nav-link <?= $currentPage == 'comunicados.php' ? 'active' : '' ?>">Comunicados</a></li>
            <li><a href="ocorrencias.php" class="nav-link <?= $currentPage == 'ocorrencias.php' ? 'active' : '' ?>">Ocorrências</a></li>
          <?php elseif ($user['perfil'] === 'professor'): ?>
            <li><a href="diario.php" class="nav-link <?= $currentPage == 'diario.php' ? 'active' : '' ?>">Diário de Classe</a></li>
            <li><a href="frequencia.php" class="nav-link <?= $currentPage == 'frequencia.php' ? 'active' : '' ?>">Frequência</a></li>
            <li><a href="notas.php" class="nav-link <?= $currentPage == 'notas.php' ? 'active' : '' ?>">Notas</a></li>
            <li><a href="atividades.php" class="nav-link <?= $currentPage == 'atividades.php' ? 'active' : '' ?>">Atividades</a></li>
            <li><a href="ocorrencias.php" class="nav-link <?= $currentPage == 'ocorrencias.php' ? 'active' : '' ?>">Ocorrências</a></li>
          <?php elseif ($user['perfil'] === 'aluno'): ?>
            <li><a href="notas.php" class="nav-link <?= $currentPage == 'notas.php' ? 'active' : '' ?>">Minhas Notas</a></li>
            <li><a href="frequencia.php" class="nav-link <?= $currentPage == 'frequencia.php' ? 'active' : '' ?>">Frequência</a></li>
            <li><a href="atividades.php" class="nav-link <?= $currentPage == 'atividades.php' ? 'active' : '' ?>">Atividades</a></li>
            <li><a href="comunicados.php" class="nav-link <?= $currentPage == 'comunicados.php' ? 'active' : '' ?>">Comunicados</a></li>
          <?php elseif ($user['perfil'] === 'responsavel'): ?>
            <li><a href="notas.php" class="nav-link <?= $currentPage == 'notas.php' ? 'active' : '' ?>">Notas do Aluno</a></li>
            <li><a href="frequencia.php" class="nav-link <?= $currentPage == 'frequencia.php' ? 'active' : '' ?>">Frequência</a></li>
            <li><a href="atividades.php" class="nav-link <?= $currentPage == 'atividades.php' ? 'active' : '' ?>">Atividades</a></li>
            <li><a href="comunicados.php" class="nav-link <?= $currentPage == 'comunicados.php' ? 'active' : '' ?>">Comunicados</a></li>
          <?php endif; ?>

          <li>
            <div class="user-badge">
              <span class="badge badge-<?= $user['perfil'] ?>"><?= strtoupper($user['perfil']) ?></span>
              <strong><?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?></strong>
            </div>
          </li>
          <li><a href="logout.php" class="btn btn-secondary btn-sm">Sair</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<main class="container mt-3 mb-4">
  <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : ($flash['type'] === 'warning' ? 'warning' : 'success') ?>">
      <span><?= htmlspecialchars($flash['message']) ?></span>
    </div>
  <?php endif; ?>
