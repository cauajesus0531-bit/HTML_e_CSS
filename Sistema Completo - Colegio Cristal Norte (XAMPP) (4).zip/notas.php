<?php
/**
 * COLÉGIO CRISTAL NORTE - Gestão e Consulta de Notas Escolares
 * Controle de Permissões:
 * - Aluno: somente seu próprio boletim
 * - Responsável: somente filhos vinculados
 * - Professor: somente sua disciplina e turmas atribuídas
 * - Diretor/Coordenador: supervisão geral de todas as turmas
 */
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser();
$pdo = getDB();

// 1. PERFIL: ALUNO
if ($user['perfil'] === 'aluno') {
    $stmtAluno = $pdo->prepare("SELECT id, nome, turma_id FROM alunos WHERE usuario_id = ?");
    $stmtAluno->execute([$user['id']]);
    $aluno = $stmtAluno->fetch();

    $stmtNotas = $pdo->prepare("
        SELECT n.*, d.nome as disciplina_nome, p.nome as professor_nome
        FROM notas n
        JOIN disciplinas d ON d.id = n.disciplina_id
        JOIN professores p ON p.id = n.professor_id
        WHERE n.aluno_id = ?
        ORDER BY d.nome ASC
    ");
    $stmtNotas->execute([$aluno['id']]);
    $boletim = $stmtNotas->fetchAll();

    $pageTitle = 'Minhas Notas - Boletim';
    require_once __DIR__ . '/header.php';
    ?>
    <div class="card">
      <div class="card-header">
        <h2>Boletim Escolar Oficial — <?= htmlspecialchars($aluno['nome']) ?></h2>
        <span class="badge badge-aprovado">Ano Letivo 2026</span>
      </div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Disciplina</th>
              <th>Professor</th>
              <th class="text-center">1º Bim</th>
              <th class="text-center">2º Bim</th>
              <th class="text-center">3º Bim</th>
              <th class="text-center">4º Bim</th>
              <th class="text-center">Média</th>
              <th class="text-center">Situação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($boletim as $n): ?>
              <tr>
                <td><strong><?= htmlspecialchars($n['disciplina_nome']) ?></strong></td>
                <td><?= htmlspecialchars($n['professor_nome']) ?></td>
                <td class="text-center"><?= $n['avaliacao1'] !== null ? number_format($n['avaliacao1'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao2'] !== null ? number_format($n['avaliacao2'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao3'] !== null ? number_format($n['avaliacao3'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao4'] !== null ? number_format($n['avaliacao4'], 1, ',', '.') : '-' ?></td>
                <td class="text-center" style="font-weight:700; color:<?= ($n['media_final'] ?? 0) >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
                  <?= $n['media_final'] !== null ? number_format($n['media_final'], 2, ',', '.') : '-' ?>
                </td>
                <td class="text-center">
                  <span class="badge badge-<?= $n['situacao'] ?>"><?= ucfirst($n['situacao']) ?></span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 2. PERFIL: RESPONSÁVEL
if ($user['perfil'] === 'responsavel') {
    $stmtResp = $pdo->prepare("SELECT id FROM responsaveis WHERE usuario_id = ?");
    $stmtResp->execute([$user['id']]);
    $respId = $stmtResp->fetchColumn();

    $stmtFilhos = $pdo->prepare("
        SELECT a.id, a.nome, t.serie, t.nome as turma_nome
        FROM alunos a
        JOIN alunos_responsaveis ar ON ar.aluno_id = a.id
        JOIN turmas t ON t.id = a.turma_id
        WHERE ar.responsavel_id = ?
    ");
    $stmtFilhos->execute([$respId]);
    $filhos = $stmtFilhos->fetchAll();

    $alunoId = isset($_GET['aluno_id']) ? intval($_GET['aluno_id']) : ($filhos[0]['id'] ?? 0);

    // Validação: filho pertence ao responsável?
    $filhoValido = false;
    $filhoAtual = null;
    foreach ($filhos as $f) {
        if ((int)$f['id'] === $alunoId) {
            $filhoValido = true;
            $filhoAtual = $f;
            break;
        }
    }
    if (!$filhoValido && !empty($filhos)) {
        $filhoAtual = $filhos[0];
        $alunoId = $filhoAtual['id'];
    }

    $stmtNotas = $pdo->prepare("
        SELECT n.*, d.nome as disciplina_nome, p.nome as professor_nome
        FROM notas n
        JOIN disciplinas d ON d.id = n.disciplina_id
        JOIN professores p ON p.id = n.professor_id
        WHERE n.aluno_id = ?
        ORDER BY d.nome ASC
    ");
    $stmtNotas->execute([$alunoId]);
    $boletim = $stmtNotas->fetchAll();

    $pageTitle = 'Boletim do Estudante';
    require_once __DIR__ . '/header.php';
    ?>
    <div class="card">
      <div class="card-header">
        <h2>Boletim Escolar — <?= htmlspecialchars($filhoAtual['nome']) ?></h2>
        <?php if (count($filhos) > 1): ?>
          <form method="GET" action="notas.php" style="display:inline-block;">
            <select name="aluno_id" onchange="this.form.submit()" class="form-control" style="font-weight:600;">
              <?php foreach ($filhos as $f): ?>
                <option value="<?= $f['id'] ?>" <?= (int)$f['id'] === (int)$alunoId ? 'selected' : '' ?>>
                  <?= htmlspecialchars($f['nome']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Disciplina</th>
              <th>Professor</th>
              <th class="text-center">1º Bim</th>
              <th class="text-center">2º Bim</th>
              <th class="text-center">3º Bim</th>
              <th class="text-center">4º Bim</th>
              <th class="text-center">Média</th>
              <th class="text-center">Situação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($boletim as $n): ?>
              <tr>
                <td><strong><?= htmlspecialchars($n['disciplina_nome']) ?></strong></td>
                <td><?= htmlspecialchars($n['professor_nome']) ?></td>
                <td class="text-center"><?= $n['avaliacao1'] !== null ? number_format($n['avaliacao1'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao2'] !== null ? number_format($n['avaliacao2'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao3'] !== null ? number_format($n['avaliacao3'], 1, ',', '.') : '-' ?></td>
                <td class="text-center"><?= $n['avaliacao4'] !== null ? number_format($n['avaliacao4'], 1, ',', '.') : '-' ?></td>
                <td class="text-center" style="font-weight:700; color:<?= ($n['media_final'] ?? 0) >= 6.0 ? 'var(--accent-green)' : 'var(--primary-red)' ?>;">
                  <?= $n['media_final'] !== null ? number_format($n['media_final'], 2, ',', '.') : '-' ?>
                </td>
                <td class="text-center">
                  <span class="badge badge-<?= $n['situacao'] ?>"><?= ucfirst($n['situacao']) ?></span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 3. PERFIL: PROFESSOR (Redireciona para o diário com aba de notas, garantindo as travas de disciplina e turmas)
if ($user['perfil'] === 'professor') {
    $turmaId = isset($_GET['turma_id']) ? intval($_GET['turma_id']) : 0;
    if ($turmaId > 0) {
        header("Location: diario.php?turma_id={$turmaId}&tab=notas");
    } else {
        header("Location: diario.php?tab=notas");
    }
    exit;
}

// 4. PERFIL: COORDENADOR OU DIRETOR (Visualização global por turma e disciplina)
requireRole(['diretor', 'coordenador']);

$turmaId = isset($_GET['turma_id']) ? intval($_GET['turma_id']) : 1;
$turmas = $pdo->query("SELECT id, nome, serie FROM turmas WHERE ano_letivo = 2026 ORDER BY serie, nome")->fetchAll();

$stmtNotasGeral = $pdo->prepare("
    SELECT a.nome as aluno_nome, a.matricula, d.nome as disciplina_nome, n.avaliacao1, n.avaliacao2, n.avaliacao3, n.avaliacao4, n.media_final, n.situacao
    FROM alunos a
    JOIN turmas t ON t.id = a.turma_id
    CROSS JOIN disciplinas d
    LEFT JOIN notas n ON n.aluno_id = a.id AND n.disciplina_id = d.id AND n.turma_id = a.turma_id
    WHERE a.turma_id = ? AND a.status = 'ativo'
    ORDER BY a.nome ASC, d.nome ASC
");
$stmtNotasGeral->execute([$turmaId]);
$relatorio = $stmtNotasGeral->fetchAll();

$pageTitle = 'Quadro Geral de Notas e Rendimento';
require_once __DIR__ . '/header.php';
?>

<div class="card">
  <div class="card-header">
    <h2>Supervisão de Notas por Turma</h2>
    <form method="GET" action="notas.php" style="display:flex; align-items:center; gap:8px;">
      <label for="selTurma" style="font-weight:600;">Turma:</label>
      <select name="turma_id" id="selTurma" class="form-control" onchange="this.form.submit()">
        <?php foreach ($turmas as $t): ?>
          <option value="<?= $t['id'] ?>" <?= (int)$t['id'] === (int)$turmaId ? 'selected' : '' ?>>
            <?= htmlspecialchars($t['serie']) ?> — <?= htmlspecialchars($t['nome']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Estudante</th>
          <th>Disciplina</th>
          <th class="text-center">1º Bim</th>
          <th class="text-center">2º Bim</th>
          <th class="text-center">3º Bim</th>
          <th class="text-center">4º Bim</th>
          <th class="text-center">Média</th>
          <th class="text-center">Situação</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($relatorio as $r): ?>
          <tr>
            <td>
              <strong><?= htmlspecialchars($r['aluno_nome']) ?></strong>
              <br><small style="color:var(--text-muted);"><?= htmlspecialchars($r['matricula']) ?></small>
            </td>
            <td><?= htmlspecialchars($r['disciplina_nome']) ?></td>
            <td class="text-center"><?= $r['avaliacao1'] !== null ? number_format($r['avaliacao1'], 1, ',', '.') : '-' ?></td>
            <td class="text-center"><?= $r['avaliacao2'] !== null ? number_format($r['avaliacao2'], 1, ',', '.') : '-' ?></td>
            <td class="text-center"><?= $r['avaliacao3'] !== null ? number_format($r['avaliacao3'], 1, ',', '.') : '-' ?></td>
            <td class="text-center"><?= $r['avaliacao4'] !== null ? number_format($r['avaliacao4'], 1, ',', '.') : '-' ?></td>
            <td class="text-center" style="font-weight:700;">
              <?= $r['media_final'] !== null ? number_format($r['media_final'], 2, ',', '.') : '-' ?>
            </td>
            <td class="text-center">
              <?php $st = $r['situacao'] ?? 'cursando'; ?>
              <span class="badge badge-<?= $st ?>"><?= ucfirst($st) ?></span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
