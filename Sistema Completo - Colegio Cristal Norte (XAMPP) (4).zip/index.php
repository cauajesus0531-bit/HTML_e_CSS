<?php
/**
 * COLÉGIO CRISTAL NORTE - Página Inicial Institucional
 * Portal Acadêmico e de Matrículas Escolares — Ano Letivo 2026
 */
$pageTitle = 'Página Inicial - Educação & Inovação';
require_once __DIR__ . '/header.php';
?>

<!-- Seção Hero Principal -->
<section class="card text-center" style="background: linear-gradient(135deg, #FAF6EF 0%, #F5EBE1 100%); padding: 50px 24px; border: 2px solid var(--border-color);">
  <div>
    <span class="badge" style="background: var(--accent-green); color: #fff; padding: 8px 20px; font-size: 0.95rem; margin-bottom: 20px; border-radius: 30px;">
      ✨ MATRÍCULAS ABERTAS 2026
    </span>
  </div>

  <div style="margin: 20px 0;">
    <img src="<?= LOGO_URL ?>" alt="Colégio Cristal Norte" style="max-height: 120px; width: auto; object-fit: contain; border-radius: 12px; background: #fff; padding: 8px; box-shadow: var(--shadow-md);">
  </div>

  <h1 style="font-size: 2.5rem; margin-bottom: 12px; color: var(--primary-red);">COLÉGIO CRISTAL NORTE</h1>
  <p style="font-size: 1.25rem; font-weight: 600; color: var(--primary-orange); margin-bottom: 16px;">
    Portal Acadêmico e de Matrículas Escolares — Ano Letivo 2026
  </p>
  <p style="max-width: 760px; margin: 0 auto 30px; font-size: 1.05rem; color: #4B5563;">
    Tradição no ensino, pioneirismo em inovação e compromisso integral com o desenvolvimento cognitivo e emocional de nossos estudantes dos 6 aos 17 anos.
  </p>

  <div style="display: flex; justify-content: center; gap: 16px; flex-wrap: wrap;">
    <a href="matricula.php" class="btn btn-primary" style="padding: 14px 28px; font-size: 1.05rem;">
      📝 Solicitar Matrícula 2026
    </a>
    <a href="login.php" class="btn btn-dark" style="padding: 14px 28px; font-size: 1.05rem;">
      🔐 Entrar no Portal
    </a>
  </div>
</section>

<!-- Pilares Institucionais -->
<div class="kpi-grid mt-4">
  <div class="card" style="margin-bottom:0;">
    <h3 style="font-size:1.15rem; margin-bottom:10px; color:var(--primary-red);">🔬 Ensino & Tecnologia</h3>
    <p style="color:#6B7280; font-size:0.92rem;">Laboratórios modernos, metodologia investigativa e suporte pedagógico de última geração para potencializar o raciocínio crítico.</p>
  </div>
  <div class="card" style="margin-bottom:0;">
    <h3 style="font-size:1.15rem; margin-bottom:10px; color:var(--primary-orange);">📚 Corpo Docente Qualificado</h3>
    <p style="color:#6B7280; font-size:0.92rem;">Professores especialistas e mestres dedicados ao acompanhamento contínuo e individualizado de cada estudante.</p>
  </div>
  <div class="card" style="margin-bottom:0;">
    <h3 style="font-size:1.15rem; margin-bottom:10px; color:var(--accent-green);">🌱 Formação Integral</h3>
    <p style="color:#6B7280; font-size:0.92rem;">Desenvolvimento de competências socioemocionais, ética, empatia e cidadania alinhados às diretrizes educacionais nacionais.</p>
  </div>
  <div class="card" style="margin-bottom:0;">
    <h3 style="font-size:1.15rem; margin-bottom:10px; color:var(--primary-red);">🤝 Família & Escola</h3>
    <p style="color:#6B7280; font-size:0.92rem;">Comunicação transparente em tempo real: boletins, frequência, ocorrências e comunicados pelo Portal da Família.</p>
  </div>
</div>

<!-- Níveis de Ensino e Proposta -->
<div class="card mt-4">
  <div class="card-header">
    <h2>Nossa Proposta Pedagógica — Ano Letivo 2026</h2>
    <span class="badge badge-aprovado">Estudantes de 6 a 17 Anos</span>
  </div>
  <div class="form-grid-2">
    <div style="background: #FAF6EF; padding: 20px; border-radius: var(--border-radius-sm); border-left: 4px solid var(--primary-orange);">
      <h3 style="color: var(--primary-orange); margin-bottom: 8px;">Ensino Fundamental (Anos Iniciais e Finais)</h3>
      <p style="font-size: 0.95rem; color: #4B5563;">
        Estímulo à alfabetização sólida, interpretação de texto, desenvolvimento lógico-matemático e integração científica com projetos práticos e acolhimento contínuo.
      </p>
    </div>
    <div style="background: #FAF6EF; padding: 20px; border-radius: var(--border-radius-sm); border-left: 4px solid var(--primary-red);">
      <h3 style="color: var(--primary-red); margin-bottom: 8px;">Ensino Médio e Preparação Superior</h3>
      <p style="font-size: 0.95rem; color: #4B5563;">
        Foco nos principais vestibulares do país e no ENEM, itinerários formativos enriquecidos, simulados bimestrais e orientação profissional personalizada.
      </p>
    </div>
  </div>
</div>

<!-- Área de Acesso ao Sistema e Informativos -->
<div class="form-grid-2 mt-3">
  <!-- Card Informativo de Matrícula -->
  <div class="card">
    <div class="card-header">
      <h2>Processo de Matrícula 2026</h2>
      <span class="badge" style="background:#E8F5E9; color:#2E7D32;">Online & Rápido</span>
    </div>
    <p style="margin-bottom: 16px; color:#4B5563;">
      O processo de matrícula no <strong>Colégio Cristal Norte</strong> é 100% digital e integrado. Em poucos minutos, os dados do estudante e do responsável são validados e a vaga é reservada com número oficial de matrícula.
    </p>
    <ul style="margin-left: 20px; margin-bottom: 20px; color:#4B5563; font-size:0.95rem;">
      <li>Cálculo e validação automática de faixa etária (6 a 17 anos).</li>
      <li>Criação simultânea da conta do responsável.</li>
      <li>Emissão imediata do número de matrícula (ex: <code>MAT-2026-XXXXX</code>).</li>
    </ul>
    <a href="matricula.php" class="btn btn-primary btn-block">Iniciar Solicitação de Matrícula</a>
  </div>

  <!-- Card de Acesso aos Portais -->
  <div class="card" style="background: var(--bg-dark); color: #fff; border-color: #334155;">
    <div class="card-header" style="border-color: #334155;">
      <h2 style="color: #fff;">Acesso ao Portal Acadêmico</h2>
      <span class="badge" style="background: #3B82F6; color: #fff;">Ambiente Seguro</span>
    </div>
    <p style="color: #94A3B8; margin-bottom: 16px;">
      Ambiente unificado para alunos, responsáveis, professores, coordenação e equipe diretiva.
    </p>
    <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:20px;">
      <div style="background:#334155; padding:10px 14px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
        <span>👨‍🎓 Alunos & 👨‍👩‍👧 Responsáveis</span>
        <span style="font-size:0.8rem; color:#A7F3D0;">Boletins e Presenças</span>
      </div>
      <div style="background:#334155; padding:10px 14px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
        <span>👨‍🏫 Corpo Docente</span>
        <span style="font-size:0.8rem; color:#FED7AA;">Diário & Lançamentos</span>
      </div>
      <div style="background:#334155; padding:10px 14px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
        <span>🏛️ Coordenação & Direção</span>
        <span style="font-size:0.8rem; color:#DDD6FE;">Gestão Integrada</span>
      </div>
    </div>
    <a href="login.php" class="btn btn-primary btn-block" style="background: var(--primary-orange);">Acessar Sistema com Login</a>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
